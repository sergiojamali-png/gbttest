# Saboos POS Galaxy View test candidate

> **TEST ONLY — not production, not launch-ready, and not physically accepted on a Galaxy View.**

## APK

- File: `saboos-pos-galaxy-view-api22-debug-test.apk`
- SHA-256: `27b3a132899a1c3d78ae59ae511becc970ab0e93ba7d091eaae8edcb1e6f0084`
- Size: `60,815` bytes
- Package ID: `ca.saboos.pos.testshell.debug`
- Version: `0.1.0-test-debug` (`versionCode` 1)
- Android API: minimum 22 (Android 5.1), target 36
- Display: landscape activity; large and xlarge screens are supported
- Signing: Android debug certificate; APK Signature Schemes v1 and v2 verify

The APK metadata above was read from the copied artifact. The filename describes its intended API-22/Galaxy-View test target; it is **not** a claim of physical Galaxy View acceptance or optimization.

## Server behavior

This debug shell opens `http://192.168.1.240:3003` and blocks navigation outside that exact HTTP origin. The tablet must be on a LAN that can reach that address. This bundle does not start, configure, or deploy the server.

The web/backend release candidate bound below has **not been deployed to staging**:

- Release candidate commit: `1f69c25ec7d5a22f3a49f8a27c349d18248e2b2c`
- Release candidate tree: `8a04bf3c6e9274166ec4ecf9c6ca25e60ff10a75`
- Android shell commit: `3b462154352b7c6a7c7eb0a53c2dae0bd86ac279`
- Android shell tree: `6d6a0b7dbb9b4ad717b67357b518976402aa5603`

## Install for testing

With Android debugging enabled, the tablet connected by a data-capable USB cable, and its RSA prompt accepted:

```powershell
adb devices -l
adb install -r .\saboos-pos-galaxy-view-api22-debug-test.apk
```

The device needs Android System WebView based on Chromium 87 or newer. Stock Android 5.1 WebView is too old and the shell intentionally fails closed until WebView is updated.

## Open gates

- Debug-signed and debuggable; there is no production release signing.
- Uses cleartext HTTP on the local network; there is no HTTPS/TLS protection.
- No physical Galaxy View installation, display, touch, reconnect, or endurance acceptance has been completed.
- No real receipt-printer driver or physical printing has been configured or accepted.
- The bound web/backend candidate is not deployed to staging.

See `manifest.json` for machine-readable bindings and `SHA256SUMS.txt` for checksum verification.
