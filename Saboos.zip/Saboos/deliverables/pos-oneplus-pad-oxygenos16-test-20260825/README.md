# Saboos POS — OnePlus Pad / OxygenOS 16 test APK

The APK in this folder is a separate, test-only build for the original OnePlus Pad on
OxygenOS 16 / Android 16 (API 36). It does not replace the Galaxy View APK: it uses a
different Android application ID, so both test shells can be installed at the same time.

## APK

- File: `saboos-pos-oneplus-pad-oxygenos16-api36-debug-test.apk`
- Application ID: `ca.saboos.pos.onepluspad.testshell.debug`
- App name: `Saboos POS OnePlus Pad TEST`
- Version: `0.2.0-oneplus-pad-oxygenos16-test-debug` (`versionCode` 2)
- Minimum/target SDK: 36 / 36
- Supported screen classes: large and xlarge
- Start URL: `http://192.168.1.240:3003`
- SHA-256: `c037e63411850e016b38e59bcc86876869ae7aa2eeec8cda4e470baccd350ee0`

This is an Android debug-signed APK. APK Signature Scheme v2 verification passes. It is
not release-signed, not for an app store, and not approved for production use.

## OnePlus Pad changes

- Separate package identity; the Galaxy View app and APK are not overwritten.
- API 36-only build for OxygenOS 16 / Android 16.
- Responsive portrait, landscape, split-screen, and resizable-window behavior instead of
  relying on a legacy landscape lock.
- Android 16 edge-to-edge, system-bar, display-cutout, and keyboard-inset handling.
- WebView history/session state preservation across configuration changes.
- CSS scale 1 for the POS page's `width=device-width` viewport, 100% text zoom, disabled
  page zoom/overscroll, hardware acceleration, safe browsing, and the screen-awake flag.
- Existing exact-origin restrictions and permanent test-only identity remain enabled.

## Install on the Pad

Using O+ Connect, send the APK file to the OnePlus Pad, open it from Files, and approve
installation from that source if OxygenOS asks. If USB debugging is enabled and approved,
the equivalent command is:

```powershell
adb install "saboos-pos-oneplus-pad-oxygenos16-api36-debug-test.apk"
```

The app needs access to the same authorized LAN as `192.168.1.240:3003`. A red banner is
always visible to identify the APK as a non-production test shell.

## Verification status

See `VERIFICATION.md` for exact build, test, signing, metadata, and Android 16 emulator
results. The physical OnePlus Pad was visible in O+ Connect but was not ADB-authorized, so
physical-device launch, touch, printer, and sustained-use acceptance remain to be done on
the Pad itself.

