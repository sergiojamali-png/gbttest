# Verification record

Generated: 2026-08-25T11:13:20-07:00

## Source binding

- Worktree: `D:\codex-worktrees\saboos-pos-android-oneplus-pad`
- Branch: `codex/pos-android-oneplus-pad`
- Commit: `e38caa93df66f7f22d0e7d9e2c861995de71d1e4`
- Source base: Galaxy View shell commit `3b462154352b7c6a7c7eb0a53c2dae0bd86ac279`
- Source worktree status after commit: clean

## Build gates

Command:

```powershell
.\gradlew.bat clean testDebugUnitTest lintDebug assembleDebug verifyReleaseNoLanResidue --console=plain
```

Result: `BUILD SUCCESSFUL`

- JUnit suites: 2
- Tests: 22
- Failures: 0
- Errors: 0
- Skipped: 0
- Android lint errors: 0
- Android lint warnings: 0
- Release LAN-residue verification: passed
- Release artifact permissions: no `android.permission.INTERNET`

The release build is fail-closed and was generated only to exercise the LAN-residue gate;
it is unsigned and is not included in this deliverable.

## APK metadata and signing

Read independently with Android Build Tools 36.0.0:

- Package: `ca.saboos.pos.onepluspad.testshell.debug`
- Version code: 2
- Version name: `0.2.0-oneplus-pad-oxygenos16-test-debug`
- Compile/minimum/target SDK: 36 / 36 / 36
- Screen classes: large, xlarge
- Permission: `android.permission.INTERNET`
- Launch activity: `ca.saboos.pos.testshell.MainActivity`
- Debuggable: yes
- APK Signature Scheme v1: false
- APK Signature Scheme v2: true
- APK Signature Scheme v3/v3.1/v4: false
- Signers: 1 Android debug certificate
- `apksigner verify` exit: 0
- APK bytes: 46,200
- SHA-256: `c037e63411850e016b38e59bcc86876869ae7aa2eeec8cda4e470baccd350ee0`

## Android 16 runtime gate

Runtime profile:

- Android: 16 / API 36
- Display: 2800x2000, 7:5, xlarge
- Android System WebView: 133.0.6943.137
- APK install result: `Success`
- Cold launch result: `Status: ok`
- Foreground activity: `ca.saboos.pos.testshell.MainActivity`
- App process remained running and resumed
- Crash buffer after accepted run: empty

Landscape WebView result:

- URL: `http://192.168.1.240:3003/`
- Title: `SABOOS POS`
- Document state: `complete`
- CSS viewport: 1400x963
- Document width: 1400 (no horizontal overflow)

Portrait rotation result:

- Activity remained resumed and preserved the same process ID
- Document state: `complete`
- CSS viewport: 1000x1363
- Document width: 1000 (no horizontal overflow)
- Returned to landscape without a crash

The runtime gate initially detected a startup crash caused by requesting the window-insets
controller before view attachment. The source was corrected, rebuilt from clean, and the
full build plus runtime gates above were rerun successfully.

## Preserved Galaxy View artifact

The existing file remains present and unchanged:

- File: `..\pos-test-candidate-20260825\saboos-pos-galaxy-view-api22-debug-test.apk`
- SHA-256 before and after this work:
  `27b3a132899a1c3d78ae59ae511becc970ab0e93ba7d091eaae8edcb1e6f0084`

## Remaining physical-device acceptance

The connected OnePlus Pad did not expose an ADB-authorized device. The following items are
therefore not claimed as complete: installation on the physical Pad, real OxygenOS system
bar behavior, touch ergonomics, printer behavior, network roaming/recovery, and sustained
operation. These need one acceptance pass on the actual Pad.

