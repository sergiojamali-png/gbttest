#!/usr/bin/env bash
# Saboos Staff B0: protected logical backup plus two disposable restore proofs.
#
# Intended invocation boundary:
#   ssh saboos 'bash -s' < staff-b0-backup-restore-execute-20260825.sh
#
# This script is intentionally pinned to the inspected Staff staging database.
# It creates one new run directory, one retained custom-format dump, and two
# sequential --rm PostgreSQL containers whose writable state is tmpfs-only.
# It never writes to the live database, restarts a live service, changes a live
# volume, deletes an old backup, or removes a Docker volume.

set -Eeuo pipefail
set -o noclobber
umask 077
IFS=$'\n\t'
export LC_ALL=C

readonly EXPECTED_HOST="funkshway"
readonly EXPECTED_USER="coochie"
readonly EXPECTED_UID="1000"
readonly EXPECTED_GID="1000"
readonly BACKUP_PARENT="/srv/saboos-storage/backups/staff-staging"
readonly EXPECTED_BACKUP_PARENT_MODE="775"
readonly DEPLOYMENT_DIR="/srv/saboos-storage/apps/saboos-staff-staging"
readonly COMPOSE_FILE="/srv/saboos-storage/apps/saboos-staff-staging/docker-compose.yml"
readonly EXPECTED_COMPOSE_SHA256="3d11e1c1a6148455760104ac6b5d7d9dcf522c6a92bc3a8551fc06f9f93f7afc"
readonly EXPECTED_COMPOSE_PROJECT="saboos-staff-staging"
readonly EXPECTED_COMPOSE_SERVICE="db"
readonly LIVE_DB_NAME="/saboos-staff-staging-db-1"
readonly LIVE_DB_ID="ef908e59bb598368d33eb045434e2ec0d8ca9d27916aae2c84c6c349b73c0db3"
readonly POSTGRES_IMAGE_ID="sha256:57c72fd2a128e416c7fcc499958864df5301e940bca0a56f58fddf30ffc07777"
readonly EXPECTED_IMAGE_OS="linux"
readonly EXPECTED_IMAGE_ARCH="amd64"
readonly LIVE_VOLUME_NAME="saboos-staff-staging-db"
readonly PG_SOCKET="/var/run/postgresql"
readonly PG_PORT="5432"
readonly PG_USER="saboos_dash"
readonly PG_DATABASE="saboos_dashboard_dev"
readonly EXPECTED_PG_VERSION="16.14"
readonly EXPECTED_DB_ENCODING="UTF8"
readonly EXPECTED_DB_COLLATE="en_US.utf8"
readonly EXPECTED_DB_CTYPE="en_US.utf8"
readonly EXPECTED_LOCALE_PROVIDER="c"
readonly EXPECTED_PUBLIC_TABLES="114"
readonly EXPECTED_MIGRATIONS_TOTAL="29"
readonly EXPECTED_MIGRATIONS_COMPLETE="28"
readonly EXPECTED_MIGRATIONS_ROLLED_BACK="1"
readonly EXPECTED_MIGRATIONS_UNRESOLVED="0"
readonly EXPECTED_AUDIT_PREFIX="1"
readonly EXPECTED_AUDIT_PREBREAK_NON_NULL="626"
readonly EXPECTED_AUDIT_BREAK_NULL_RUN="5"
readonly EXPECTED_AUDIT_POSTBREAK_MIN="3448"
readonly EXPECTED_AUDIT_FIRST_BREAK="kashi-deploy-03b1031231f3ac68"
readonly STAFF_HEALTH_URL="http://127.0.0.1:3002/api/staff/health"
readonly B0_SCOPE_LABEL="staff-logical-restore-proof"
readonly MIN_FREE_BYTES="1073741824"
readonly MIN_AVAILABLE_MEMORY_KIB="2097152"

RUN_ID=""
RUN_SUFFIX=""
RUN_DIR=""
RUN_DIR_BASENAME=""
RUN_CREATE_PATH=""
RUN_DIR_CREATED=0
RUN_DIR_DEVICE_INODE=""
RUN_DIR_OWNER=""
RUN_DIR_MODE=""
RUN_DIR_RESOLVED=""
readonly RUN_DIR_FD="9"
RUN_DIR_IO=""
BACKUP_PARENT_DEVICE_INODE=""
BACKUP_PARENT_RESOLVED=""
BACKUP_PARENT_IO=""
PRIMARY_DIR=""
VERIFIER_DIR=""
PRIMARY_CANONICAL_DIR=""
VERIFIER_CANONICAL_DIR=""
PRIMARY_NAME=""
VERIFIER_NAME=""
PRIMARY_DB=""
VERIFIER_DB=""
PRIMARY_ID=""
VERIFIER_ID=""
PRIMARY_CLEANUP_ATTEMPTED=0
VERIFIER_CLEANUP_ATTEMPTED=0
PRIMARY_LAUNCH_ATTEMPTED=0
VERIFIER_LAUNCH_ATTEMPTED=0
EXIT_IN_PROGRESS=0
ABORT_REASON="not_started"
B0_LOCK_FD=""
BACKUP_PARENT_OWNER=""
SCHEMA_RESTRICT_KEY=""

safe_err() {
  printf 'SABOOS_B0_ERROR: %s\n' "$1" >&2
}

die() {
  ABORT_REASON="$1"
  safe_err "$1"
  exit 1
}

require_command() {
  command -v "$1" >/dev/null 2>&1 || die "required command unavailable: $1"
}

require_regex() {
  local value="$1"
  local pattern="$2"
  local label="$3"
  [[ "$value" =~ $pattern ]] || die "invalid ${label}"
}

sha256_of() {
  sha256sum -- "$1" | awk '{print $1}'
}

read_stream_sha256() {
  local file="$1"
  local line hash
  require_run_owned_target "$file"
  [[ -f "$file" && ! -L "$file" ]] || die "schema-only hash evidence is absent"
  [[ "$(wc -l < "$file" | tr -d '[:space:]')" == "1" ]] || die "schema-only hash evidence cardinality is invalid"
  line="$(cat -- "$file")"
  hash="$(awk 'NF == 2 && $2 == "-" { print $1 }' "$file")"
  require_regex "$hash" '^[a-f0-9]{64}$' "schema-only stream SHA-256"
  [[ "$line" == "${hash}  -" ]] || die "schema-only hash evidence format is invalid"
  printf '%s' "$hash"
}

mode_of() {
  stat -c '%a' -- "$1"
}

owner_of() {
  stat -c '%u:%g' -- "$1"
}

size_of() {
  stat -c '%s' -- "$1"
}

run_dir_identity_ok() {
  local current_device_inode current_owner current_mode current_type
  [[ "$RUN_DIR_CREATED" == "1" ]] || return 1
  [[ "$RUN_DIR_IO" == "/proc/self/fd/${RUN_DIR_FD}" ]] || return 1
  current_device_inode="$(stat -Lc '%d:%i' -- "$RUN_DIR_IO" 2>/dev/null)" || return 1
  current_owner="$(stat -Lc '%u:%g' -- "$RUN_DIR_IO" 2>/dev/null)" || return 1
  current_mode="$(stat -Lc '%a' -- "$RUN_DIR_IO" 2>/dev/null)" || return 1
  current_type="$(stat -Lc '%F' -- "$RUN_DIR_IO" 2>/dev/null)" || return 1
  [[ "$current_device_inode" == "$RUN_DIR_DEVICE_INODE" ]] || return 1
  [[ "$current_owner" == "$RUN_DIR_OWNER" ]] || return 1
  [[ "$current_mode" == "$RUN_DIR_MODE" ]] || return 1
  [[ "$current_type" == "directory" ]] || return 1
  return 0
}

canonical_run_path_ok() {
  local current_device_inode current_owner current_mode current_resolved
  run_dir_identity_ok || return 1
  [[ -d "$RUN_DIR" && ! -L "$RUN_DIR" ]] || return 1
  current_device_inode="$(stat -c '%d:%i' -- "$RUN_DIR" 2>/dev/null)" || return 1
  current_owner="$(stat -c '%u:%g' -- "$RUN_DIR" 2>/dev/null)" || return 1
  current_mode="$(stat -c '%a' -- "$RUN_DIR" 2>/dev/null)" || return 1
  current_resolved="$(realpath -e -- "$RUN_DIR" 2>/dev/null)" || return 1
  [[ "$current_device_inode" == "$RUN_DIR_DEVICE_INODE" ]] || return 1
  [[ "$current_owner" == "$RUN_DIR_OWNER" ]] || return 1
  [[ "$current_mode" == "$RUN_DIR_MODE" ]] || return 1
  [[ "$current_resolved" == "$RUN_DIR_RESOLVED" && "$current_resolved" == "$RUN_DIR" ]] || return 1
  return 0
}

require_run_dir_identity() {
  run_dir_identity_ok || die "run directory identity is unavailable or changed"
}

require_run_owned_target() {
  local target="$1"
  require_run_dir_identity
  [[ "$target" == "$RUN_DIR_IO"/* ]] || die "write target is outside the retained run-directory descriptor"
}

write_new_lines() {
  local target="$1"
  shift
  require_run_owned_target "$target"
  [[ ! -e "$target" && ! -L "$target" ]] || die "refusing to overwrite run-owned evidence"
  printf '%s\n' "$@" > "$target"
  [[ "$(mode_of "$target")" == "600" ]] || die "new evidence file mode is not 0600"
}

require_line() {
  local file="$1"
  local exact="$2"
  awk -v wanted="$exact" '$0 == wanted { found += 1 } END { exit(found == 1 ? 0 : 1) }' "$file" \
    || die "canonical evidence is missing an expected unique line"
}

assert_no_symlink_components() {
  local path="$1"
  local current=""
  local part
  [[ "$path" == /* ]] || die "filesystem boundary is not absolute"
  IFS='/' read -r -a parts <<< "${path#/}"
  [[ -d / && ! -L / ]] || die "root filesystem component is invalid"
  for part in "${parts[@]}"; do
    [[ -n "$part" ]] || continue
    current="${current}/${part}"
    [[ -e "$current" ]] || die "required filesystem component is absent"
    [[ ! -L "$current" ]] || die "symlink found in protected filesystem boundary"
  done
  [[ "$(realpath -e -- "$path")" == "$path" ]] || die "filesystem boundary does not resolve exactly"
}

docker_inspect_value() {
  local format="$1"
  local object="$2"
  docker inspect --type container --format "$format" "$object" 2>/dev/null
}

assert_live_db_pin() {
  local actual
  actual="$(docker_inspect_value '{{.Id}}' "$LIVE_DB_ID")" || die "pinned live DB container is unavailable"
  [[ "$actual" == "$LIVE_DB_ID" ]] || die "live DB container ID drifted"
  [[ "$(docker_inspect_value '{{.Name}}' "$LIVE_DB_ID")" == "$LIVE_DB_NAME" ]] || die "live DB container name drifted"
  [[ "$(docker_inspect_value '{{.Image}}' "$LIVE_DB_ID")" == "$POSTGRES_IMAGE_ID" ]] || die "live DB image drifted"
  [[ "$(docker_inspect_value '{{.State.Status}}' "$LIVE_DB_ID")" == "running" ]] || die "live DB is not running"
  [[ "$(docker_inspect_value '{{if .State.Health}}{{.State.Health.Status}}{{end}}' "$LIVE_DB_ID")" == "healthy" ]] \
    || die "live DB is not healthy"
  [[ "$(docker_inspect_value '{{index .Config.Labels "com.docker.compose.project"}}' "$LIVE_DB_ID")" == "$EXPECTED_COMPOSE_PROJECT" ]] \
    || die "live DB Compose project label drifted"
  [[ "$(docker_inspect_value '{{index .Config.Labels "com.docker.compose.service"}}' "$LIVE_DB_ID")" == "$EXPECTED_COMPOSE_SERVICE" ]] \
    || die "live DB Compose service label drifted"
  [[ "$(docker_inspect_value '{{index .Config.Labels "com.docker.compose.project.working_dir"}}' "$LIVE_DB_ID")" == "$DEPLOYMENT_DIR" ]] \
    || die "live DB Compose working-directory label drifted"
  [[ "$(docker_inspect_value '{{index .Config.Labels "com.docker.compose.project.config_files"}}' "$LIVE_DB_ID")" == "$COMPOSE_FILE" ]] \
    || die "live DB Compose config-file label drifted"
  [[ "$(docker_inspect_value '{{len .Mounts}}' "$LIVE_DB_ID")" == "1" ]] || die "live DB mount count drifted"
  actual="$(docker_inspect_value '{{range .Mounts}}{{.Name}}|{{.Destination}}|{{.RW}}{{end}}' "$LIVE_DB_ID")"
  [[ "$actual" == "${LIVE_VOLUME_NAME}|/var/lib/postgresql/data|true" ]] || die "live DB mount identity drifted"
}

assert_compose_pin() {
  [[ -d "$DEPLOYMENT_DIR" && ! -L "$DEPLOYMENT_DIR" ]] || die "deployment directory boundary drifted"
  [[ -f "$COMPOSE_FILE" && ! -L "$COMPOSE_FILE" ]] || die "Compose file boundary drifted"
  [[ "$(realpath -e -- "$COMPOSE_FILE")" == "$COMPOSE_FILE" ]] || die "Compose file does not resolve exactly"
  [[ "$(sha256_of "$COMPOSE_FILE")" == "$EXPECTED_COMPOSE_SHA256" ]] || die "Compose file hash drifted"
}

assert_image_pin() {
  local value
  value="$(docker image inspect --format '{{.Id}}' "$POSTGRES_IMAGE_ID" 2>/dev/null)" \
    || die "pinned PostgreSQL image is unavailable locally"
  [[ "$value" == "$POSTGRES_IMAGE_ID" ]] || die "pinned PostgreSQL image ID mismatch"
  [[ "$(docker image inspect --format '{{.Os}}' "$POSTGRES_IMAGE_ID")" == "$EXPECTED_IMAGE_OS" ]] \
    || die "pinned PostgreSQL image OS mismatch"
  [[ "$(docker image inspect --format '{{.Architecture}}' "$POSTGRES_IMAGE_ID")" == "$EXPECTED_IMAGE_ARCH" ]] \
    || die "pinned PostgreSQL image architecture mismatch"
}

assert_no_b0_containers() {
  local found=0
  local name names labeled_ids
  names="$(docker ps -a --format '{{.Names}}')" || die "could not enumerate Docker container names"
  while IFS= read -r name; do
    [[ -n "$name" ]] || continue
    if [[ "$name" == saboos-staff-b0-restore-* ]]; then
      found=$((found + 1))
    fi
  done <<< "$names"
  [[ "$found" == "0" ]] || die "another B0 restore container name is present"
  labeled_ids="$(docker ps -aq --no-trunc --filter "label=com.saboos.b0.scope=${B0_SCOPE_LABEL}")" \
    || die "could not enumerate B0-labeled Docker containers"
  [[ -z "$labeled_ids" ]] || die "another B0 restore container label is present"
}

HOST_PROCESS_CLASSIFICATION="DEFINITE_NONMATCH"
HOST_PROCESS_CATEGORY=""
COMPOSE_SCOPE_PATH_STATE="INDETERMINATE"

classify_compose_scope_path() {
  local supplied_path="$1"
  local process_cwd="$2"
  local expected_type="$3"
  local candidate_path resolved_path
  COMPOSE_SCOPE_PATH_STATE="INDETERMINATE"
  [[ -n "$supplied_path" && -n "$process_cwd" ]] || return 0
  if [[ "$supplied_path" == /* ]]; then
    candidate_path="$supplied_path"
  else
    candidate_path="${process_cwd}/${supplied_path}"
  fi
  resolved_path="$(realpath -e -- "$candidate_path" 2>/dev/null)" || return 0
  [[ "$resolved_path" == /* && "$resolved_path" != *$'\n'* ]] || return 0
  if [[ "$expected_type" == "file" ]]; then
    [[ -f "$resolved_path" ]] || return 0
  elif [[ "$expected_type" == "directory" ]]; then
    [[ -d "$resolved_path" ]] || return 0
  else
    return 0
  fi
  if [[ "$resolved_path" == "$DEPLOYMENT_DIR" || "$resolved_path" == "${DEPLOYMENT_DIR}/"* ]]; then
    COMPOSE_SCOPE_PATH_STATE="STAFF"
  else
    COMPOSE_SCOPE_PATH_STATE="UNRELATED"
  fi
}

classify_host_process() {
  local process_comm="$1"
  local executable_basename="$2"
  local process_cwd="$3"
  shift 3
  local -a process_argv=("$@")
  local argument argument_value argv0_basename action="" compose_start=-1 index
  local launcher_kind="" launcher_start=-1 node_script_index=-1 prisma_command_index=-1
  local cwd_staff=0 explicit_staff=0 scope_ambiguous=0 explicit_path_seen=0 all_paths_unrelated=1
  local explicit_project_unrelated=0
  HOST_PROCESS_CLASSIFICATION="DEFINITE_NONMATCH"
  HOST_PROCESS_CATEGORY=""

  # Docker remains anchored to its executable and canonical cwd. Node-family
  # processes may instead use stable comm plus argv[0] when /proc/<pid>/exe is
  # unavailable; their migration grammar does not depend on cwd.
  if [[ -z "$executable_basename" ]]; then
    case "$process_comm" in
      docker|docker-compose)
        HOST_PROCESS_CLASSIFICATION="INDETERMINATE"
        HOST_PROCESS_CATEGORY="docker_indeterminate"
        return 0
        ;;
      node|nodejs|npm|npx|prisma)
        HOST_PROCESS_CLASSIFICATION="INDETERMINATE"
        HOST_PROCESS_CATEGORY="prisma_indeterminate"
        (( ${#process_argv[@]} > 0 )) || return 0
        argv0_basename="${process_argv[0]##*/}"
        case "$argv0_basename" in
          node|nodejs|npm|npx|prisma)
            executable_basename="$argv0_basename"
            ;;
          *)
            return 0
            ;;
        esac
        ;;
      *)
        return 0
        ;;
    esac
  fi

  if [[ "$executable_basename" == "docker" || "$executable_basename" == "docker-compose" ]]; then
    HOST_PROCESS_CLASSIFICATION="INDETERMINATE"
    HOST_PROCESS_CATEGORY="docker_indeterminate"
    [[ -n "$process_cwd" ]] || return 0
    if [[ "$executable_basename" == "docker" ]]; then
      index=1
      while (( index < ${#process_argv[@]} )); do
        argument="${process_argv[$index]}"
        case "$argument" in
          compose)
            compose_start=$((index + 1))
            break
            ;;
          --config|--context|-H|--host|-l|--log-level|--tlscacert|--tlscert|--tlskey)
            index=$((index + 1))
            (( index < ${#process_argv[@]} )) || return 0
            [[ -n "${process_argv[$index]}" ]] || return 0
            ;;
          --config=*|--context=*|--host=*|--log-level=*|--tlscacert=*|--tlscert=*|--tlskey=*|-H=*|-l=*)
            [[ -n "${argument#*=}" ]] || return 0
            ;;
          -H?*|-l?*)
            [[ -n "${argument:2}" && "${argument:2}" != "=" ]] || return 0
            ;;
          --debug|-D|--tls|--tlsverify)
            ;;
          build|builder|commit|container|context|cp|create|diff|events|exec|export|history|image|images|import|info|inspect|kill|load|login|logout|logs|network|node|pause|plugin|port|ps|pull|push|rename|restart|rm|rmi|run|save|search|secret|service|stack|start|stats|stop|swarm|system|tag|top|trust|unpause|update|version|volume|wait)
            HOST_PROCESS_CLASSIFICATION="DEFINITE_NONMATCH"
            HOST_PROCESS_CATEGORY=""
            return 0
            ;;
          *)
            return 0
            ;;
        esac
        index=$((index + 1))
      done
      (( compose_start >= 0 )) || return 0
    else
      compose_start=1
      if (( ${#process_argv[@]} > 1 )) && [[ "${process_argv[1]}" == "compose" ]]; then
        compose_start=2
      fi
    fi

    [[ "$process_cwd" == "$DEPLOYMENT_DIR" || "$process_cwd" == "${DEPLOYMENT_DIR}/"* ]] && cwd_staff=1
    index=$compose_start
    while (( index < ${#process_argv[@]} )); do
      argument="${process_argv[$index]}"
      case "$argument" in
        -p|--project-name|-f|--file|--project-directory)
          index=$((index + 1))
          (( index < ${#process_argv[@]} )) || return 0
          argument_value="${process_argv[$index]}"
          [[ -n "$argument_value" ]] || return 0
          if [[ "$argument" == "-p" || "$argument" == "--project-name" ]]; then
            if [[ "$argument_value" == "$EXPECTED_COMPOSE_PROJECT" ]]; then
              explicit_staff=1
            else
              explicit_project_unrelated=1
            fi
          elif [[ "$argument" == "-f" || "$argument" == "--file" ]]; then
            explicit_path_seen=1
            classify_compose_scope_path "$argument_value" "$process_cwd" "file"
            if [[ "$COMPOSE_SCOPE_PATH_STATE" == "STAFF" ]]; then
              explicit_staff=1
              all_paths_unrelated=0
            elif [[ "$COMPOSE_SCOPE_PATH_STATE" != "UNRELATED" ]]; then
              scope_ambiguous=1
              all_paths_unrelated=0
            fi
          else
            explicit_path_seen=1
            classify_compose_scope_path "$argument_value" "$process_cwd" "directory"
            if [[ "$COMPOSE_SCOPE_PATH_STATE" == "STAFF" ]]; then
              explicit_staff=1
              all_paths_unrelated=0
            elif [[ "$COMPOSE_SCOPE_PATH_STATE" != "UNRELATED" ]]; then
              scope_ambiguous=1
              all_paths_unrelated=0
            fi
          fi
          ;;
        --project-name=*|-p=*|-p?*)
          if [[ "$argument" == --project-name=* ]]; then
            argument_value="${argument#--project-name=}"
          elif [[ "$argument" == -p=* ]]; then
            argument_value="${argument#-p=}"
          else
            argument_value="${argument#-p}"
          fi
          [[ -n "$argument_value" ]] || return 0
          if [[ "$argument_value" == "$EXPECTED_COMPOSE_PROJECT" ]]; then
            explicit_staff=1
          else
            explicit_project_unrelated=1
          fi
          ;;
        --file=*|-f=*|-f?*)
          if [[ "$argument" == --file=* ]]; then
            argument_value="${argument#--file=}"
          elif [[ "$argument" == -f=* ]]; then
            argument_value="${argument#-f=}"
          else
            argument_value="${argument#-f}"
          fi
          [[ -n "$argument_value" ]] || return 0
          explicit_path_seen=1
          classify_compose_scope_path "$argument_value" "$process_cwd" "file"
          if [[ "$COMPOSE_SCOPE_PATH_STATE" == "STAFF" ]]; then
            explicit_staff=1
            all_paths_unrelated=0
          elif [[ "$COMPOSE_SCOPE_PATH_STATE" != "UNRELATED" ]]; then
            scope_ambiguous=1
            all_paths_unrelated=0
          fi
          ;;
        --project-directory=*)
          argument_value="${argument#--project-directory=}"
          [[ -n "$argument_value" ]] || return 0
          explicit_path_seen=1
          classify_compose_scope_path "$argument_value" "$process_cwd" "directory"
          if [[ "$COMPOSE_SCOPE_PATH_STATE" == "STAFF" ]]; then
            explicit_staff=1
            all_paths_unrelated=0
          elif [[ "$COMPOSE_SCOPE_PATH_STATE" != "UNRELATED" ]]; then
            scope_ambiguous=1
            all_paths_unrelated=0
          fi
          ;;
        --profile|--env-file|--parallel|--ansi|--progress)
          index=$((index + 1))
          (( index < ${#process_argv[@]} )) || return 0
          [[ -n "${process_argv[$index]}" ]] || return 0
          ;;
        --profile=*|--env-file=*|--parallel=*|--ansi=*|--progress=*)
          [[ -n "${argument#*=}" ]] || return 0
          ;;
        --compatibility|--dry-run|--verbose)
          ;;
        up|build|create|pull|restart|run)
          action="$argument"
          break
          ;;
        config|events|help|images|kill|logs|ls|pause|port|ps|top|unpause|version|wait)
          HOST_PROCESS_CLASSIFICATION="DEFINITE_NONMATCH"
          HOST_PROCESS_CATEGORY=""
          return 0
          ;;
        *)
          return 0
          ;;
      esac
      index=$((index + 1))
    done
    [[ -n "$action" ]] || return 0
    if [[ "$explicit_staff" == "1" ]]; then
      HOST_PROCESS_CLASSIFICATION="MATCH"
      HOST_PROCESS_CATEGORY="staff_compose_${action}"
    elif [[ "$scope_ambiguous" == "1" ]]; then
      HOST_PROCESS_CLASSIFICATION="INDETERMINATE"
      HOST_PROCESS_CATEGORY="docker_indeterminate"
    elif [[ "$cwd_staff" == "1" && ! ( "$explicit_path_seen" == "1" && "$all_paths_unrelated" == "1" ) ]]; then
      HOST_PROCESS_CLASSIFICATION="MATCH"
      HOST_PROCESS_CATEGORY="staff_compose_${action}"
    elif [[ "$explicit_project_unrelated" == "1" \
      || ( "$explicit_path_seen" == "1" && "$all_paths_unrelated" == "1" ) ]]; then
      HOST_PROCESS_CLASSIFICATION="DEFINITE_NONMATCH"
      HOST_PROCESS_CATEGORY=""
    else
      HOST_PROCESS_CLASSIFICATION="INDETERMINATE"
      HOST_PROCESS_CATEGORY="docker_indeterminate"
    fi
    return 0
  fi

  case "$executable_basename" in
    node|nodejs|npm|npx|prisma)
      HOST_PROCESS_CLASSIFICATION="INDETERMINATE"
      HOST_PROCESS_CATEGORY="prisma_indeterminate"
      ;;
    *)
      return 0
      ;;
  esac
  if [[ "$executable_basename" == "prisma" ]]; then
    prisma_command_index=0
  elif [[ "$executable_basename" == "npm" ]]; then
    launcher_kind="npm"
    launcher_start=1
  elif [[ "$executable_basename" == "npx" ]]; then
    launcher_kind="npx"
    launcher_start=1
  else
    index=1
    while (( index < ${#process_argv[@]} )); do
      argument="${process_argv[$index]}"
      case "$argument" in
        --)
          index=$((index + 1))
          (( index < ${#process_argv[@]} )) || return 0
          node_script_index=$index
          break
          ;;
        --import|--require|-r|--loader)
          index=$((index + 1))
          (( index < ${#process_argv[@]} )) || return 0
          [[ -n "${process_argv[$index]}" ]] || return 0
          ;;
        --import=*|--require=*|--loader=*|-r=*)
          [[ -n "${argument#*=}" ]] || return 0
          ;;
        -r?*)
          [[ -n "${argument#-r}" ]] || return 0
          ;;
        --enable-source-maps|--no-warnings|--pending-deprecation|--preserve-symlinks|--preserve-symlinks-main|\
        --trace-deprecation|--trace-exit|--trace-sigint|--trace-sync-io|--trace-tls|\
        --trace-uncaught|--trace-warnings)
          ;;
        -*)
          return 0
          ;;
        *)
          node_script_index=$index
          break
          ;;
      esac
      index=$((index + 1))
    done
    (( node_script_index >= 0 )) || return 0
    argument="${process_argv[$node_script_index]}"
    case "$argument" in
      node_modules/prisma/build/index.js|node_modules/prisma/build/index.cjs|node_modules/prisma/build/index.mjs|\
      */node_modules/prisma/build/index.js|*/node_modules/prisma/build/index.cjs|*/node_modules/prisma/build/index.mjs|\
      node_modules/.bin/prisma|*/node_modules/.bin/prisma|prisma|*/prisma)
        prisma_command_index=$node_script_index
        ;;
      */npm|*/npm-cli.js)
        launcher_kind="npm"
        launcher_start=$((node_script_index + 1))
        ;;
      */npx|*/npx-cli.js)
        launcher_kind="npx"
        launcher_start=$((node_script_index + 1))
        ;;
      *)
        HOST_PROCESS_CLASSIFICATION="DEFINITE_NONMATCH"
        HOST_PROCESS_CATEGORY=""
        return 0
        ;;
    esac
  fi

  if [[ "$launcher_kind" == "npm" ]]; then
    index=$launcher_start
    while (( index < ${#process_argv[@]} )); do
      argument="${process_argv[$index]}"
      case "$argument" in
        exec|x)
          index=$((index + 1))
          break
          ;;
        --prefix|--workspace|-w|--userconfig|--cache)
          index=$((index + 1))
          (( index < ${#process_argv[@]} )) || return 0
          [[ -n "${process_argv[$index]}" ]] || return 0
          ;;
        --prefix=*|--workspace=*|--userconfig=*|--cache=*)
          [[ -n "${argument#*=}" ]] || return 0
          ;;
        --yes|-y|--silent|--quiet)
          ;;
        -*)
          return 0
          ;;
        *)
          HOST_PROCESS_CLASSIFICATION="DEFINITE_NONMATCH"
          HOST_PROCESS_CATEGORY=""
          return 0
          ;;
      esac
      index=$((index + 1))
    done
    while (( index < ${#process_argv[@]} )); do
      argument="${process_argv[$index]}"
      case "$argument" in
        --)
          ;;
        --package|-p)
          index=$((index + 1))
          (( index < ${#process_argv[@]} )) || return 0
          [[ -n "${process_argv[$index]}" ]] || return 0
          ;;
        --package=*|-p=*)
          [[ -n "${argument#*=}" ]] || return 0
          ;;
        -p?*|--yes|-y)
          ;;
        prisma|*/node_modules/.bin/prisma|*/prisma)
          prisma_command_index=$index
          break
          ;;
        -*)
          return 0
          ;;
        *)
          HOST_PROCESS_CLASSIFICATION="DEFINITE_NONMATCH"
          HOST_PROCESS_CATEGORY=""
          return 0
          ;;
      esac
      index=$((index + 1))
    done
  elif [[ "$launcher_kind" == "npx" ]]; then
    index=$launcher_start
    while (( index < ${#process_argv[@]} )); do
      argument="${process_argv[$index]}"
      case "$argument" in
        --package|-p|--cache|--userconfig)
          index=$((index + 1))
          (( index < ${#process_argv[@]} )) || return 0
          [[ -n "${process_argv[$index]}" ]] || return 0
          ;;
        --package=*|-p=*|--cache=*|--userconfig=*)
          [[ -n "${argument#*=}" ]] || return 0
          ;;
        -p?*|--yes|-y|--no-install|--quiet)
          ;;
        prisma|*/node_modules/.bin/prisma|*/prisma)
          prisma_command_index=$index
          break
          ;;
        -*)
          return 0
          ;;
        *)
          HOST_PROCESS_CLASSIFICATION="DEFINITE_NONMATCH"
          HOST_PROCESS_CATEGORY=""
          return 0
          ;;
      esac
      index=$((index + 1))
    done
  fi

  (( prisma_command_index >= 0 )) || return 0
  index=$((prisma_command_index + 1))
  while (( index < ${#process_argv[@]} )); do
    argument="${process_argv[$index]}"
    case "$argument" in
      --)
        ;;
      --schema|--config)
        index=$((index + 1))
        (( index < ${#process_argv[@]} )) || return 0
        [[ -n "${process_argv[$index]}" ]] || return 0
        ;;
      --schema=*|--config=*)
        [[ -n "${argument#*=}" ]] || return 0
        ;;
      --no-engine)
        ;;
      migrate)
        HOST_PROCESS_CLASSIFICATION="MATCH"
        HOST_PROCESS_CATEGORY="prisma_migration"
        return 0
        ;;
      -*)
        return 0
        ;;
      *)
        HOST_PROCESS_CLASSIFICATION="DEFINITE_NONMATCH"
        HOST_PROCESS_CATEGORY=""
        return 0
        ;;
    esac
    index=$((index + 1))
  done
  HOST_PROCESS_CLASSIFICATION="DEFINITE_NONMATCH"
  HOST_PROCESS_CATEGORY=""
  return 0
}

HOST_SAMPLE_DECISION="BLOCK_INDETERMINATE"

decide_host_process_sample() {
  local candidate_family="$1"
  local initial_classification="$2"
  local initial_category="$3"
  local final_classification="$4"
  local final_category="$5"
  local identity_state="$6"
  local initial_fingerprint="$7"
  local final_fingerprint="$8"
  local initial_cwd="$9"
  local final_cwd="${10}"
  local initial_comm="${11}"
  local final_comm="${12}"
  HOST_SAMPLE_DECISION="BLOCK_INDETERMINATE"
  if [[ "$identity_state" == "GONE" ]]; then
    HOST_SAMPLE_DECISION="IGNORE_GONE"
    return 0
  fi
  [[ "$identity_state" == "STABLE" ]] || return 0
  [[ "$initial_fingerprint" =~ ^[a-f0-9]{64}$ && "$final_fingerprint" == "$initial_fingerprint" ]] || return 0
  if [[ "$candidate_family" == "DOCKER" ]]; then
    [[ -n "$initial_cwd" && "$final_cwd" == "$initial_cwd" ]] || return 0
  elif [[ "$candidate_family" != "NODE" ]]; then
    return 0
  fi
  [[ -n "$initial_comm" && "$final_comm" == "$initial_comm" ]] || return 0
  [[ "$final_classification" == "$initial_classification" && "$final_category" == "$initial_category" ]] || return 0
  case "$initial_classification" in
    DEFINITE_NONMATCH)
      [[ -z "$initial_category" ]] || return 0
      HOST_SAMPLE_DECISION="IGNORE_DEFINITE_NONMATCH"
      ;;
    MATCH)
      HOST_SAMPLE_DECISION="BLOCK_MATCH"
      ;;
    INDETERMINATE)
      HOST_SAMPLE_DECISION="BLOCK_INDETERMINATE"
      ;;
  esac
}

classify_node_zombie_samples() {
  local initial_pid="$1"
  local initial_state="$2"
  local initial_ppid="$3"
  local initial_start="$4"
  local initial_uid="$5"
  local initial_comm="$6"
  local after_pid="$7"
  local after_state="$8"
  local after_ppid="$9"
  local after_start="${10}"
  local after_uid="${11}"
  local after_comm="${12}"
  local final_pid="${13}"
  local final_state="${14}"
  local final_ppid="${15}"
  local final_start="${16}"
  local final_uid="${17}"
  local final_comm="${18}"
  HOST_PROCESS_CLASSIFICATION="INDETERMINATE"
  HOST_PROCESS_CATEGORY="prisma_indeterminate"
  HOST_SAMPLE_DECISION="BLOCK_INDETERMINATE"

  [[ "$initial_pid" =~ ^[0-9]+$ && "$initial_state" == "Z" \
    && "$initial_ppid" =~ ^[0-9]+$ && "$initial_start" =~ ^[0-9]+$ \
    && "$initial_uid" =~ ^[0-9]+$ \
    && "$initial_comm" =~ ^(node|nodejs|npm|npx|prisma)$ ]] || return 0
  [[ "$after_pid" == "$initial_pid" && "$final_pid" == "$initial_pid" \
    && "$after_state" == "Z" && "$final_state" == "Z" \
    && "$after_ppid" == "$initial_ppid" && "$final_ppid" == "$initial_ppid" \
    && "$after_start" == "$initial_start" && "$final_start" == "$initial_start" \
    && "$after_uid" == "$initial_uid" && "$final_uid" == "$initial_uid" \
    && "$after_comm" == "$initial_comm" && "$final_comm" == "$initial_comm" ]] || return 0
  HOST_PROCESS_CLASSIFICATION="DEFINITE_NONMATCH"
  HOST_PROCESS_CATEGORY="non_runnable_zombie"
  HOST_SAMPLE_DECISION="IGNORE_NONRUNNABLE_ZOMBIE"
}

assert_host_process_classifier_self_tests() {
  classify_host_process "sh" "sh" "$DEPLOYMENT_DIR" \
    "sh" "-c" "prisma migrate deploy && node server.js"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "DEFINITE_NONMATCH" ]] \
    || die "host-process classifier self-test did not reject dormant shell entrypoint text"
  classify_host_process "sh" "sh" "$DEPLOYMENT_DIR" \
    "sh" "-c" "docker compose --project-name saboos-staff-staging up -d"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "DEFINITE_NONMATCH" ]] \
    || die "host-process classifier self-test did not reject Docker text held by a shell"
  classify_host_process "docker" "docker" "/tmp" \
    "/usr/bin/docker" "compose" "--project-name" "unrelated-project" "up" "-d"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "DEFINITE_NONMATCH" ]] \
    || die "host-process classifier self-test did not prove unrelated explicit Compose scope"
  classify_host_process "docker" "docker" "/tmp" "/usr/bin/docker" "compose" "up" "-d"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "INDETERMINATE" ]] \
    || die "host-process classifier self-test discarded absent Compose scope"
  classify_host_process "docker" "docker" "$DEPLOYMENT_DIR" \
    "/usr/bin/docker" "compose" "-f" "/etc/hosts" "up" "-d"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "DEFINITE_NONMATCH" ]] \
    || die "host-process classifier self-test did not prove canonical unrelated Compose file"
  classify_host_process "docker" "docker" "/tmp" \
    "/usr/bin/docker" "compose" "-f" "${DEPLOYMENT_DIR}/../saboos-staff-staging/docker-compose.yml" "up"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" ]] \
    || die "host-process classifier self-test missed dot-dot path resolving into Staff"
  classify_host_process "docker" "docker" "/tmp" \
    "/usr/bin/docker" "compose" "--file=/proc/self/root${COMPOSE_FILE}" "up"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" ]] \
    || die "host-process classifier self-test missed symlink path resolving into Staff"
  classify_host_process "node" "node" "/app" "/usr/bin/node" "/app/server.js" "prisma" "migrate"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "DEFINITE_NONMATCH" ]] \
    || die "host-process classifier self-test accepted ordinary Node arguments"
  classify_host_process "node" "node" "/app" "/usr/bin/node" "--import" "tsx" "src/index.ts"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "DEFINITE_NONMATCH" ]] \
    || die "host-process classifier self-test did not reject the legitimate optioned Staff API command"
  classify_host_process "node" "" "" "/usr/bin/node" "--import" "tsx" "src/index.ts"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "DEFINITE_NONMATCH" ]] \
    || die "host-process classifier self-test required unavailable exe or cwd for an ordinary Node API"
  classify_host_process "node" "" "" "/usr/bin/node" "/app/node_modules/prisma/build/index.js" "migrate" "deploy"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "prisma_migration" ]] \
    || die "host-process classifier self-test missed Prisma migration with unavailable exe and cwd"
  classify_host_process "node" "" ""
  [[ "$HOST_PROCESS_CLASSIFICATION" == "INDETERMINATE" ]] \
    || die "host-process classifier self-test discarded unreadable or empty Node argv uncertainty"
  classify_host_process "docker" "" "" "/usr/bin/docker" "compose" "-p" "$EXPECTED_COMPOSE_PROJECT" "up"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "INDETERMINATE" ]] \
    || die "host-process classifier self-test discarded missing Docker exe and cwd uncertainty"
  classify_host_process "docker" "docker" "" "/usr/bin/docker" "compose" "-p" "$EXPECTED_COMPOSE_PROJECT" "up"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "INDETERMINATE" ]] \
    || die "host-process classifier self-test discarded missing Docker cwd uncertainty"
  classify_host_process "node" "node" "/app" "/usr/bin/node" "--import"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "INDETERMINATE" ]] \
    || die "host-process classifier self-test discarded malformed Node-option uncertainty"
  classify_host_process "node" "node" "/app" "/usr/bin/node" "--unknown-runtime-option" "src/index.ts"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "INDETERMINATE" ]] \
    || die "host-process classifier self-test discarded unknown Node-option uncertainty"

  classify_host_process "docker" "docker" "${DEPLOYMENT_DIR}/backend" "/usr/bin/docker" "compose" "up" "-d"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "staff_compose_up" ]] \
    || die "host-process classifier self-test missed implicit Compose from a Staff child directory"
  classify_host_process "docker" "docker" "/tmp" \
    "/usr/bin/docker" "-l" "debug" "compose" "-p" "$EXPECTED_COMPOSE_PROJECT" "up" "-d"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "staff_compose_up" ]] \
    || die "host-process classifier self-test missed Docker short log-level Compose up"
  classify_host_process "docker" "docker" "/tmp" \
    "/usr/bin/docker" "--log-level" "debug" "compose" "-p" "$EXPECTED_COMPOSE_PROJECT" "up" "-d"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "staff_compose_up" ]] \
    || die "host-process classifier self-test missed Docker long log-level Compose up"
  classify_host_process "docker" "docker" "/tmp" \
    "/usr/bin/docker" "compose" "--unknown-scope-option" "value" "-p" "$EXPECTED_COMPOSE_PROJECT" "up"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "INDETERMINATE" ]] \
    || die "host-process classifier self-test did not retain unknown Compose option uncertainty"
  classify_host_process "docker" "docker" "/tmp" "/usr/bin/docker" "--log-level"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "INDETERMINATE" ]] \
    || die "host-process classifier self-test did not retain malformed Docker-option uncertainty"
  classify_host_process "docker" "docker" "/tmp" "/usr/bin/docker" "compose" "-p"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "INDETERMINATE" ]] \
    || die "host-process classifier self-test did not retain malformed Compose-option uncertainty"

  classify_host_process "node" "node" "/app" \
    "/usr/bin/node" "/app/node_modules/prisma/build/index.js" "migrate" "deploy"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "prisma_migration" ]] \
    || die "host-process classifier self-test missed direct Node Prisma migration"
  classify_host_process "node" "node" "/app" \
    "/usr/bin/node" "--trace-warnings" "/app/node_modules/prisma/build/index.js" "migrate" "deploy"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "prisma_migration" ]] \
    || die "host-process classifier self-test missed optioned Node Prisma migration"
  classify_host_process "node" "node" "/app" \
    "/usr/bin/node" "--" "/app/node_modules/prisma/build/index.js" "migrate" "deploy"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "prisma_migration" ]] \
    || die "host-process classifier self-test missed Node end-of-options Prisma migration"
  classify_host_process "node" "node" "/app" \
    "/usr/bin/node" "node_modules/prisma/build/index.js" "migrate" "deploy"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "prisma_migration" ]] \
    || die "host-process classifier self-test missed relative Node Prisma migration"
  classify_host_process "node" "node" "/app" \
    "/usr/bin/node" "/usr/bin/npm" "exec" "prisma" "migrate" "deploy"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "prisma_migration" ]] \
    || die "host-process classifier self-test missed npm Prisma migration"
  classify_host_process "node" "node" "/app" \
    "/usr/bin/node" "/usr/bin/npx" "prisma" "migrate" "deploy"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "prisma_migration" ]] \
    || die "host-process classifier self-test missed npx Prisma migration"
  classify_host_process "prisma" "prisma" "/app" "/usr/local/bin/prisma" "migrate" "deploy"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "prisma_migration" ]] \
    || die "host-process classifier self-test missed direct Prisma migration"

  classify_host_process "docker" "docker" "/tmp" \
    "/usr/bin/docker" "compose" "--project-name" "$EXPECTED_COMPOSE_PROJECT" "build"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "staff_compose_build" ]] \
    || die "host-process classifier self-test missed Docker Compose build"
  classify_host_process "docker-compose" "docker-compose" "/tmp" \
    "/usr/local/bin/docker-compose" "-p" "$EXPECTED_COMPOSE_PROJECT" "run" "worker"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "staff_compose_run" ]] \
    || die "host-process classifier self-test missed docker-compose run"
  classify_host_process "docker" "docker" "/tmp" \
    "/usr/bin/docker" "compose" "-p" "$EXPECTED_COMPOSE_PROJECT" "create"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "staff_compose_create" ]] \
    || die "host-process classifier self-test missed Docker Compose create"
  classify_host_process "docker" "docker" "/tmp" \
    "/usr/bin/docker" "compose" "--file=${COMPOSE_FILE}" "pull"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "staff_compose_pull" ]] \
    || die "host-process classifier self-test missed Docker Compose pull"
  classify_host_process "docker" "docker" "/tmp" \
    "/usr/bin/docker" "compose" "--project-directory" "$DEPLOYMENT_DIR" "restart"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "staff_compose_restart" ]] \
    || die "host-process classifier self-test missed Docker Compose restart"

  decide_host_process_sample "NODE" "DEFINITE_NONMATCH" "" "DEFINITE_NONMATCH" "" "STABLE" \
    "$EXPECTED_COMPOSE_SHA256" "$EXPECTED_COMPOSE_SHA256" "/tmp" "/tmp" "node" "node"
  [[ "$HOST_SAMPLE_DECISION" == "IGNORE_DEFINITE_NONMATCH" ]] \
    || die "host-process sample self-test did not accept a stable definite nonmatch"
  decide_host_process_sample "NODE" "DEFINITE_NONMATCH" "" "DEFINITE_NONMATCH" "" "STABLE" \
    "$EXPECTED_COMPOSE_SHA256" "$EXPECTED_COMPOSE_SHA256" "" "" "node" "node"
  [[ "$HOST_SAMPLE_DECISION" == "IGNORE_DEFINITE_NONMATCH" ]] \
    || die "host-process sample self-test required cwd for a stable Node nonmatch"
  decide_host_process_sample "NODE" "DEFINITE_NONMATCH" "" "DEFINITE_NONMATCH" "" "STABLE" \
    "$EXPECTED_COMPOSE_SHA256" "$LIVE_DB_ID" "/tmp" "/tmp" "node" "node"
  [[ "$HOST_SAMPLE_DECISION" == "BLOCK_INDETERMINATE" ]] \
    || die "host-process sample self-test ignored final fingerprint drift"
  decide_host_process_sample "DOCKER" "DEFINITE_NONMATCH" "" "DEFINITE_NONMATCH" "" "STABLE" \
    "$EXPECTED_COMPOSE_SHA256" "$EXPECTED_COMPOSE_SHA256" "/tmp" "$DEPLOYMENT_DIR" "docker" "docker"
  [[ "$HOST_SAMPLE_DECISION" == "BLOCK_INDETERMINATE" ]] \
    || die "host-process sample self-test ignored final cwd drift"
  decide_host_process_sample "NODE" "DEFINITE_NONMATCH" "" "DEFINITE_NONMATCH" "" "INDETERMINATE" \
    "$EXPECTED_COMPOSE_SHA256" "$EXPECTED_COMPOSE_SHA256" "/tmp" "/tmp" "node" "node"
  [[ "$HOST_SAMPLE_DECISION" == "BLOCK_INDETERMINATE" ]] \
    || die "host-process sample self-test ignored identity uncertainty"

  classify_node_zombie_samples \
    "1234" "Z" "100" "9000" "0" "node" \
    "1234" "Z" "100" "9000" "0" "node" \
    "1234" "Z" "100" "9000" "0" "node"
  [[ "$HOST_SAMPLE_DECISION" == "IGNORE_NONRUNNABLE_ZOMBIE" \
    && "$HOST_PROCESS_CLASSIFICATION" == "DEFINITE_NONMATCH" \
    && "$HOST_PROCESS_CATEGORY" == "non_runnable_zombie" ]] \
    || die "host-process sample self-test did not ignore a stable non-runnable Node zombie"
  classify_node_zombie_samples \
    "1234" "Z" "100" "9000" "0" "node" \
    "1234" "Z" "100" "9000" "0" "node" \
    "1234" "S" "100" "9000" "0" "node"
  [[ "$HOST_SAMPLE_DECISION" == "BLOCK_INDETERMINATE" ]] \
    || die "host-process sample self-test inherited a zombie exemption after a live-state transition"
  classify_node_zombie_samples \
    "1234" "Z" "100" "9000" "0" "node" \
    "1234" "Z" "100" "9000" "0" "node" \
    "1234" "Z" "100" "9001" "0" "node"
  [[ "$HOST_SAMPLE_DECISION" == "BLOCK_INDETERMINATE" ]] \
    || die "host-process sample self-test inherited a zombie exemption across PID reuse"
  classify_host_process "node" "" "" "/usr/bin/node"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "INDETERMINATE" ]] \
    || die "host-process classifier self-test ignored live empty-argv uncertainty"
  classify_host_process "node" "" "" "/usr/bin/node" "/app/node_modules/prisma/build/index.js" "migrate" "deploy"
  [[ "$HOST_PROCESS_CLASSIFICATION" == "MATCH" && "$HOST_PROCESS_CATEGORY" == "prisma_migration" ]] \
    || die "host-process classifier self-test missed live Prisma migration after zombie cases"
}

read_process_stat_sample() {
  local stat_file="$1"
  local stat_line stat_pid stat_tail
  local -a stat_fields
  IFS= read -r stat_line < "$stat_file" 2>/dev/null || return 1
  [[ "$stat_line" == *") "* ]] || return 1
  stat_pid="${stat_line%% *}"
  [[ "$stat_pid" =~ ^[0-9]+$ ]] || return 1
  stat_tail="${stat_line##*) }"
  IFS=' ' read -r -a stat_fields <<< "$stat_tail"
  (( ${#stat_fields[@]} >= 20 )) || return 1
  [[ "${stat_fields[0]}" =~ ^[A-Za-z]$ ]] || return 1
  [[ "${stat_fields[1]}" =~ ^[0-9]+$ ]] || return 1
  [[ "${stat_fields[19]}" =~ ^[0-9]+$ ]] || return 1
  printf '%s|%s|%s|%s' "$stat_pid" "${stat_fields[0]}" "${stat_fields[1]}" "${stat_fields[19]}"
}

PROCESS_OBSERVATION_STATUS="INDETERMINATE"
PROCESS_OBS_PID=""
PROCESS_OBS_STATE=""
PROCESS_OBS_PPID=""
PROCESS_OBS_START=""
PROCESS_OBS_UID=""
PROCESS_OBS_COMM=""

observe_process_identity() {
  local pid="$1"
  local proc_dir="/proc/${pid}"
  local stat_sample extra=""
  PROCESS_OBSERVATION_STATUS="INDETERMINATE"
  PROCESS_OBS_PID=""
  PROCESS_OBS_STATE=""
  PROCESS_OBS_PPID=""
  PROCESS_OBS_START=""
  PROCESS_OBS_UID=""
  PROCESS_OBS_COMM=""
  if [[ ! -d "$proc_dir" ]]; then
    PROCESS_OBSERVATION_STATUS="GONE"
    return 0
  fi
  stat_sample="$(read_process_stat_sample "${proc_dir}/stat" 2>/dev/null)" || {
    [[ -d "$proc_dir" ]] || PROCESS_OBSERVATION_STATUS="GONE"
    return 0
  }
  IFS='|' read -r PROCESS_OBS_PID PROCESS_OBS_STATE PROCESS_OBS_PPID PROCESS_OBS_START extra <<< "$stat_sample"
  [[ -z "$extra" && "$PROCESS_OBS_PID" == "$pid" \
    && "$PROCESS_OBS_STATE" =~ ^[A-Za-z]$ \
    && "$PROCESS_OBS_PPID" =~ ^[0-9]+$ \
    && "$PROCESS_OBS_START" =~ ^[0-9]+$ ]] || return 0
  PROCESS_OBS_UID="$(stat -c '%u' -- "$proc_dir" 2>/dev/null)" || {
    [[ -d "$proc_dir" ]] || PROCESS_OBSERVATION_STATUS="GONE"
    return 0
  }
  [[ "$PROCESS_OBS_UID" =~ ^[0-9]+$ ]] || return 0
  IFS= read -r PROCESS_OBS_COMM < "${proc_dir}/comm" 2>/dev/null || {
    [[ -d "$proc_dir" ]] || PROCESS_OBSERVATION_STATUS="GONE"
    return 0
  }
  [[ "$PROCESS_OBS_COMM" =~ ^[A-Za-z0-9_.+-]{1,32}$ ]] || return 0
  PROCESS_OBSERVATION_STATUS="OBSERVED"
}

PROCESS_IDENTITY_STATE="INDETERMINATE"

prove_process_identity_state() {
  local pid="$1"
  local expected_start="$2"
  local expected_uid="$3"
  local candidate_family="$4"
  local expected_executable="$5"
  local expected_state="$6"
  local expected_ppid="$7"
  local proc_dir="/proc/${pid}"
  local stat_sample current_pid current_state current_ppid current_start current_uid current_executable extra=""
  PROCESS_IDENTITY_STATE="INDETERMINATE"
  if [[ ! -d "$proc_dir" ]]; then
    PROCESS_IDENTITY_STATE="GONE"
    return 0
  fi
  stat_sample="$(read_process_stat_sample "${proc_dir}/stat" 2>/dev/null)" || {
    [[ -d "$proc_dir" ]] || PROCESS_IDENTITY_STATE="GONE"
    return 0
  }
  IFS='|' read -r current_pid current_state current_ppid current_start extra <<< "$stat_sample"
  [[ -z "$extra" && "$current_pid" == "$pid" \
    && "$current_state" =~ ^[A-Za-z]$ \
    && "$current_ppid" =~ ^[0-9]+$ \
    && "$current_start" =~ ^[0-9]+$ ]] || return 0
  current_uid="$(stat -c '%u' -- "$proc_dir" 2>/dev/null)" || {
    [[ -d "$proc_dir" ]] || PROCESS_IDENTITY_STATE="GONE"
    return 0
  }
  [[ "$current_uid" =~ ^[0-9]+$ ]] || return 0
  if [[ "$current_start" != "$expected_start" || "$current_uid" != "$expected_uid" \
    || "$current_ppid" != "$expected_ppid" ]]; then
    return 0
  fi
  # Runnable states legitimately change between R/S/D/etc. A transition into
  # or out of Z is different: it must never inherit either a live-process or a
  # zombie exemption.
  if [[ "$expected_state" == "Z" || "$current_state" == "Z" ]]; then
    [[ "$current_state" == "$expected_state" ]] || return 0
  fi
  if [[ "$expected_state" == "Z" ]]; then
    return 0
  fi
  if [[ "$candidate_family" == "DOCKER" ]]; then
    [[ -n "$expected_executable" ]] || return 0
    current_executable="$(readlink -- "${proc_dir}/exe" 2>/dev/null)" || {
      [[ -d "$proc_dir" ]] || PROCESS_IDENTITY_STATE="GONE"
      return 0
    }
    current_executable="${current_executable% (deleted)}"
    [[ "$current_executable" == "$expected_executable" ]] || return 0
  elif [[ "$candidate_family" != "NODE" ]]; then
    return 0
  fi
  PROCESS_IDENTITY_STATE="STABLE"
}

assert_no_host_deploy_or_migration() {
  local proc_dir proc_file pid discovery_comm process_comm safe_comm executable_path executable_basename classifier_executable process_cwd
  local final_comm final_cwd start_before process_uid process_state_before process_ppid_before
  local fingerprint_before fingerprint_after fingerprint_final category uncertainty_category
  local candidate_family initial_classification initial_category final_classification final_category sample_failed final_sample_failed
  local zombie_after_pid zombie_after_state zombie_after_ppid zombie_after_start zombie_after_uid zombie_after_comm
  local zombie_final_pid zombie_final_state zombie_final_ppid zombie_final_start zombie_final_uid zombie_final_comm
  local self_pid="$$"
  local -a process_argv=()
  local -a matches=()
  assert_host_process_classifier_self_tests

  for proc_dir in /proc/[0-9]*; do
    [[ -d "$proc_dir" ]] || continue
    pid="${proc_dir#/proc/}"
    [[ "$pid" =~ ^[0-9]+$ ]] || continue
    [[ "$pid" == "$self_pid" ]] && continue
    proc_file="${proc_dir}/cmdline"
    discovery_comm="$(IFS= read -r value < "${proc_dir}/comm" 2>/dev/null && printf '%s' "$value" || true)"
    executable_path=""
    executable_basename=""
    candidate_family=""
    classifier_executable=""
    case "$discovery_comm" in
      node|nodejs|npm|npx|prisma)
        # A Node-family comm is enough for candidate discovery. In particular,
        # do not require or read exe/cwd for a non-runnable zombie.
        candidate_family="NODE"
        uncertainty_category="prisma_indeterminate"
        ;;
      docker|docker-compose)
        candidate_family="DOCKER"
        uncertainty_category="docker_indeterminate"
        ;;
      *)
        # A readable executable is a secondary discovery signal only. Node
        # launcher grammar is still derived from the later stable comm/argv.
        executable_path="$(readlink -- "${proc_dir}/exe" 2>/dev/null || true)"
        executable_path="${executable_path% (deleted)}"
        executable_basename="${executable_path##*/}"
        case "$executable_basename" in
          docker|docker-compose)
            candidate_family="DOCKER"
            classifier_executable="$executable_basename"
            uncertainty_category="docker_indeterminate"
            ;;
          node|nodejs|npm|npx|prisma)
            candidate_family="NODE"
            uncertainty_category="prisma_indeterminate"
            ;;
          *)
            continue
            ;;
        esac
        ;;
    esac

    if [[ "$candidate_family" == "DOCKER" && -z "$executable_path" ]]; then
      executable_path="$(readlink -- "${proc_dir}/exe" 2>/dev/null || true)"
      executable_path="${executable_path% (deleted)}"
      executable_basename="${executable_path##*/}"
      if [[ "$executable_basename" == "docker" || "$executable_basename" == "docker-compose" ]]; then
        classifier_executable="$executable_basename"
      fi
    fi

    observe_process_identity "$pid"
    if [[ "$PROCESS_OBSERVATION_STATUS" == "GONE" ]]; then
      continue
    fi
    if [[ "$PROCESS_OBSERVATION_STATUS" != "OBSERVED" ]]; then
      matches+=("${pid}|${uncertainty_category}|unavailable|unavailable|unavailable")
      continue
    fi
    start_before="$PROCESS_OBS_START"
    process_uid="$PROCESS_OBS_UID"
    process_state_before="$PROCESS_OBS_STATE"
    process_ppid_before="$PROCESS_OBS_PPID"
    process_comm="$PROCESS_OBS_COMM"
    safe_comm="$process_comm"
    [[ "$safe_comm" =~ ^[A-Za-z0-9_.+-]{1,32}$ ]] || safe_comm="untrusted"

    if [[ "$candidate_family" == "NODE" && "$process_state_before" == "Z" ]]; then
      if [[ ! "$process_comm" =~ ^(node|nodejs|npm|npx|prisma)$ ]]; then
        matches+=("${pid}|${uncertainty_category}|${safe_comm}|${start_before}|unavailable")
        continue
      fi

      observe_process_identity "$pid"
      if [[ "$PROCESS_OBSERVATION_STATUS" == "GONE" ]]; then
        continue
      fi
      if [[ "$PROCESS_OBSERVATION_STATUS" != "OBSERVED" ]]; then
        matches+=("${pid}|${uncertainty_category}|${safe_comm}|${start_before}|unavailable")
        continue
      fi
      zombie_after_pid="$PROCESS_OBS_PID"
      zombie_after_state="$PROCESS_OBS_STATE"
      zombie_after_ppid="$PROCESS_OBS_PPID"
      zombie_after_start="$PROCESS_OBS_START"
      zombie_after_uid="$PROCESS_OBS_UID"
      zombie_after_comm="$PROCESS_OBS_COMM"

      observe_process_identity "$pid"
      if [[ "$PROCESS_OBSERVATION_STATUS" == "GONE" ]]; then
        continue
      fi
      if [[ "$PROCESS_OBSERVATION_STATUS" != "OBSERVED" ]]; then
        matches+=("${pid}|${uncertainty_category}|${safe_comm}|${start_before}|unavailable")
        continue
      fi
      zombie_final_pid="$PROCESS_OBS_PID"
      zombie_final_state="$PROCESS_OBS_STATE"
      zombie_final_ppid="$PROCESS_OBS_PPID"
      zombie_final_start="$PROCESS_OBS_START"
      zombie_final_uid="$PROCESS_OBS_UID"
      zombie_final_comm="$PROCESS_OBS_COMM"

      classify_node_zombie_samples \
        "$pid" "$process_state_before" "$process_ppid_before" "$start_before" "$process_uid" "$process_comm" \
        "$zombie_after_pid" "$zombie_after_state" "$zombie_after_ppid" "$zombie_after_start" "$zombie_after_uid" "$zombie_after_comm" \
        "$zombie_final_pid" "$zombie_final_state" "$zombie_final_ppid" "$zombie_final_start" "$zombie_final_uid" "$zombie_final_comm"
      if [[ "$HOST_SAMPLE_DECISION" == "IGNORE_NONRUNNABLE_ZOMBIE" ]]; then
        continue
      fi
      matches+=("${pid}|${uncertainty_category}|${safe_comm}|${start_before}|unavailable")
      continue
    fi

    sample_failed=0
    process_comm=""
    safe_comm="unavailable"
    fingerprint_before=""
    fingerprint_after=""
    process_cwd=""
    process_argv=()
    if ! IFS= read -r process_comm < "${proc_dir}/comm" 2>/dev/null; then
      sample_failed=1
    elif [[ "$candidate_family" == "NODE" \
      && ! "$process_comm" =~ ^(node|nodejs|npm|npx|prisma)$ ]]; then
      sample_failed=1
    elif ! fingerprint_before="$(sha256_of "$proc_file" 2>/dev/null)"; then
      sample_failed=1
    elif [[ ! "$fingerprint_before" =~ ^[a-f0-9]{64}$ ]]; then
      sample_failed=1
    elif ! mapfile -d '' -t process_argv < "$proc_file" 2>/dev/null; then
      sample_failed=1
    elif (( ${#process_argv[@]} == 0 )); then
      sample_failed=1
    elif ! fingerprint_after="$(sha256_of "$proc_file" 2>/dev/null)"; then
      sample_failed=1
    elif [[ "$fingerprint_after" != "$fingerprint_before" ]]; then
      sample_failed=1
    elif [[ "$candidate_family" == "DOCKER" ]]; then
      if [[ -z "$executable_path" ]]; then
        sample_failed=1
      elif ! process_cwd="$(readlink -e -- "${proc_dir}/cwd" 2>/dev/null)"; then
        sample_failed=1
      fi
    fi

    prove_process_identity_state "$pid" "$start_before" "$process_uid" "$candidate_family" \
      "$executable_path" "$process_state_before" "$process_ppid_before"
    if [[ "$PROCESS_IDENTITY_STATE" == "GONE" ]]; then
      continue
    fi
    if [[ -n "$process_comm" ]]; then
      safe_comm="$process_comm"
      if [[ ! "$safe_comm" =~ ^[A-Za-z0-9_.+-]{1,32}$ ]]; then
        safe_comm="untrusted"
      fi
    fi
    [[ "$fingerprint_before" =~ ^[a-f0-9]{64}$ ]] || fingerprint_before="unavailable"
    if [[ "$sample_failed" == "1" || "$PROCESS_IDENTITY_STATE" != "STABLE" ]]; then
      matches+=("${pid}|${uncertainty_category}|${safe_comm}|${start_before}|${fingerprint_before}")
      continue
    fi

    classify_host_process "$process_comm" "$classifier_executable" "$process_cwd" "${process_argv[@]}"
    initial_classification="$HOST_PROCESS_CLASSIFICATION"
    initial_category="$HOST_PROCESS_CATEGORY"

    final_sample_failed=0
    final_comm=""
    final_cwd=""
    fingerprint_final=""
    if ! IFS= read -r final_comm < "${proc_dir}/comm" 2>/dev/null; then
      final_sample_failed=1
    elif [[ "$candidate_family" == "NODE" \
      && ! "$final_comm" =~ ^(node|nodejs|npm|npx|prisma)$ ]]; then
      final_sample_failed=1
    elif ! fingerprint_final="$(sha256_of "$proc_file" 2>/dev/null)"; then
      final_sample_failed=1
    elif [[ ! "$fingerprint_final" =~ ^[a-f0-9]{64}$ ]]; then
      final_sample_failed=1
    elif [[ "$candidate_family" == "DOCKER" ]]; then
      if ! final_cwd="$(readlink -e -- "${proc_dir}/cwd" 2>/dev/null)"; then
        final_sample_failed=1
      fi
    fi
    prove_process_identity_state "$pid" "$start_before" "$process_uid" "$candidate_family" \
      "$executable_path" "$process_state_before" "$process_ppid_before"
    final_classification="INDETERMINATE"
    final_category="$uncertainty_category"
    if [[ "$final_sample_failed" == "0" && "$PROCESS_IDENTITY_STATE" == "STABLE" ]]; then
      classify_host_process "$final_comm" "$classifier_executable" "$final_cwd" "${process_argv[@]}"
      final_classification="$HOST_PROCESS_CLASSIFICATION"
      final_category="$HOST_PROCESS_CATEGORY"
    fi

    decide_host_process_sample "$candidate_family" "$initial_classification" "$initial_category" \
      "$final_classification" "$final_category" "$PROCESS_IDENTITY_STATE" \
      "$fingerprint_before" "$fingerprint_final" "$process_cwd" "$final_cwd" "$process_comm" "$final_comm"
    case "$HOST_SAMPLE_DECISION" in
      IGNORE_GONE|IGNORE_DEFINITE_NONMATCH)
        continue
        ;;
      BLOCK_MATCH)
        category="$initial_category"
        [[ "$category" =~ ^(prisma_migration|staff_compose_(up|build|create|pull|restart|run))$ ]] \
          || category="$uncertainty_category"
        ;;
      *)
        category="$uncertainty_category"
        ;;
    esac
    matches+=("${pid}|${category}|${safe_comm}|${start_before}|${fingerprint_before}")
  done

  if (( ${#matches[@]} > 0 )); then
    while IFS='|' read -r pid category safe_comm start_before fingerprint_before; do
      safe_err "concurrency process pid=${pid} category=${category} comm=${safe_comm} start_ticks=${start_before} argv_sha256=${fingerprint_before}"
    done < <(printf '%s\n' "${matches[@]}" | LC_ALL=C sort -t '|' -k1,1n)
    die "concurrent deployment or migration process detected"
  fi
}

source_psql_capture() {
  local app="$1"
  local sql="$2"
  require_regex "$app" '^[a-z0-9_]{1,63}$' "source PostgreSQL application name"
  docker exec \
    --env "PGAPPNAME=${app}" \
    --env 'PGOPTIONS=-c default_transaction_read_only=on -c statement_timeout=120000 -c lock_timeout=5000' \
    "$LIVE_DB_ID" \
    psql --no-psqlrc --no-password --set=ON_ERROR_STOP=1 --quiet --tuples-only --no-align --field-separator='|' \
      --host="$PG_SOCKET" --port="$PG_PORT" --username="$PG_USER" --dbname="$PG_DATABASE" \
      --command="$sql" 2>/dev/null
}

assert_source_identity() {
  local phase="$1"
  local app="b0_${RUN_SUFFIX}_${phase}_identity"
  local sql result
  sql="BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY; SET LOCAL statement_timeout='30s'; SET LOCAL lock_timeout='5s'; SELECT current_database(), current_user, current_setting('server_version'), pg_is_in_recovery(), pg_encoding_to_char(encoding), datcollate, datctype, datlocprovider FROM pg_database WHERE datname=current_database(); COMMIT;"
  result="$(source_psql_capture "$app" "$sql")" || die "could not prove live database endpoint identity"
  [[ "$result" == "${PG_DATABASE}|${PG_USER}|${EXPECTED_PG_VERSION}|f|${EXPECTED_DB_ENCODING}|${EXPECTED_DB_COLLATE}|${EXPECTED_DB_CTYPE}|${EXPECTED_LOCALE_PROVIDER}" ]] \
    || die "live database identity or locale drifted"
}

assert_source_quiescent_for_b0() {
  local phase="$1"
  local app="b0_${RUN_SUFFIX}_${phase}_gate"
  local sql result
  sql="BEGIN TRANSACTION ISOLATION LEVEL READ COMMITTED READ ONLY; SET LOCAL statement_timeout='30s'; SET LOCAL lock_timeout='5s'; WITH conflicting_sessions AS (SELECT count(*)::bigint AS n FROM pg_stat_activity WHERE pid <> pg_backend_pid() AND datname=current_database() AND ((lower(application_name) ~ '(pg_dump|pg_restore|prisma.*migrat|saboos_b0)') OR (state <> 'idle' AND lower(query) ~ '(^|[[:space:];])(alter|create|drop|truncate|reindex|cluster|vacuum[[:space:]]+full)([[:space:]]|$)'))), exclusive_locks AS (SELECT count(DISTINCT l.pid)::bigint AS n FROM pg_locks l JOIN pg_class c ON c.oid=l.relation JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND l.mode='AccessExclusiveLock' AND l.pid <> pg_backend_pid()) SELECT (SELECT n FROM conflicting_sessions), (SELECT n FROM exclusive_locks); COMMIT;"
  result="$(source_psql_capture "$app" "$sql")" || die "could not prove live database concurrency gate"
  [[ "$result" == "0|0" ]] || die "concurrent dump, restore, migration, DDL, or exclusive public-schema lock detected"
}

assert_health_endpoint() {
  local code
  code="$(curl --silent --show-error --output /dev/null --write-out '%{http_code}' --max-time 10 "$STAFF_HEALTH_URL" 2>/dev/null)" \
    || die "Staff health endpoint was unreachable"
  [[ "$code" == "200" ]] || die "Staff health endpoint did not return HTTP 200"
}

assert_preflight() {
  local command_name free_bytes memory_kib pg_binary_version parent_mode
  for command_name in awk basename bash cat cmp curl date df docker find flock head hostname id mkdir mv od readlink realpath seq sha256sum sleep sort stat sync tail tr wc xargs; do
    require_command "$command_name"
  done
  [[ "$(hostname -s)" == "$EXPECTED_HOST" ]] || die "remote host identity mismatch"
  [[ "$(id -un)" == "$EXPECTED_USER" ]] || die "remote user identity mismatch"
  [[ "$(id -u)" == "$EXPECTED_UID" ]] || die "remote user UID mismatch"
  [[ "$(id -g)" == "$EXPECTED_GID" ]] || die "remote user GID mismatch"
  id -nG | tr ' ' '\n' | awk '$0 == "docker" { found=1 } END { exit(found ? 0 : 1) }' \
    || die "remote user is not in the docker group"
  assert_no_symlink_components "$BACKUP_PARENT"
  [[ -d "$BACKUP_PARENT" ]] || die "Staff backup parent is not a directory"
  parent_mode="$(mode_of "$BACKUP_PARENT")"
  [[ "$parent_mode" == "$EXPECTED_BACKUP_PARENT_MODE" ]] || die "Staff backup parent mode drifted"
  BACKUP_PARENT_OWNER="$(owner_of "$BACKUP_PARENT")"
  require_regex "$BACKUP_PARENT_OWNER" '^[0-9]+:[0-9]+$' "Staff backup parent owner"
  BACKUP_PARENT_DEVICE_INODE="$(stat -c '%d:%i' -- "$BACKUP_PARENT")"
  require_regex "$BACKUP_PARENT_DEVICE_INODE" '^[0-9]+:[0-9]+$' "Staff backup parent device and inode"
  BACKUP_PARENT_RESOLVED="$(realpath -e -- "$BACKUP_PARENT")"
  [[ "$BACKUP_PARENT_RESOLVED" == "$BACKUP_PARENT" ]] || die "Staff backup parent resolution drifted"
  [[ -w "$BACKUP_PARENT" && -x "$BACKUP_PARENT" ]] || die "Staff backup parent is not writable by the pinned operator"
  assert_compose_pin
  assert_image_pin
  assert_live_db_pin
  pg_binary_version="$(docker exec "$LIVE_DB_ID" postgres --version 2>/dev/null)" \
    || die "could not read the pinned PostgreSQL binary version"
  [[ "$pg_binary_version" == "postgres (PostgreSQL) ${EXPECTED_PG_VERSION}" ]] || die "PostgreSQL binary version drifted"
  assert_health_endpoint
  assert_no_b0_containers
  assert_no_host_deploy_or_migration
  assert_source_identity "preflight"
  assert_source_quiescent_for_b0 "preflight"
  free_bytes="$(df -B1 --output=avail -- "$BACKUP_PARENT" | awk 'NR==2 {gsub(/[[:space:]]/, "", $0); print $0}')"
  require_regex "$free_bytes" '^[0-9]+$' "available filesystem bytes"
  (( free_bytes >= MIN_FREE_BYTES )) || die "insufficient free space for protected backup evidence"
  memory_kib="$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)"
  require_regex "$memory_kib" '^[0-9]+$' "available memory"
  (( memory_kib >= MIN_AVAILABLE_MEMORY_KIB )) || die "insufficient available memory for isolated restore"
}

container_identity_matches() {
  local id_value="$1"
  local expected_name="$2"
  local expected_role="$3"
  local actual_id actual_name actual_run actual_scope actual_role actual_image
  [[ "$id_value" =~ ^[a-f0-9]{64}$ ]] || return 1
  actual_id="$(docker_inspect_value '{{.Id}}' "$id_value")" || return 1
  actual_name="$(docker_inspect_value '{{.Name}}' "$id_value")" || return 1
  actual_run="$(docker_inspect_value '{{index .Config.Labels "com.saboos.b0.run"}}' "$id_value")" || return 1
  actual_scope="$(docker_inspect_value '{{index .Config.Labels "com.saboos.b0.scope"}}' "$id_value")" || return 1
  actual_role="$(docker_inspect_value '{{index .Config.Labels "com.saboos.b0.role"}}' "$id_value")" || return 1
  actual_image="$(docker_inspect_value '{{.Image}}' "$id_value")" || return 1
  [[ "$actual_id" == "$id_value" ]] || return 1
  [[ "$actual_name" == "/${expected_name}" ]] || return 1
  [[ "$actual_run" == "$RUN_ID" ]] || return 1
  [[ "$actual_scope" == "$B0_SCOPE_LABEL" ]] || return 1
  [[ "$actual_role" == "$expected_role" ]] || return 1
  [[ "$actual_image" == "$POSTGRES_IMAGE_ID" ]] || return 1
  return 0
}

recover_launch_id_from_evidence() {
  local role="$1"
  local expected_name="$2"
  local directory="$3"
  local cidfile="${directory}/container.cid"
  local stdout_file="${directory}/docker-run.stdout.safe"
  local -a evidence_paths=("$cidfile" "$stdout_file")
  local -a evidence_states=("absent" "absent")
  local -a evidence_candidates=("" "")
  local index evidence_path evidence_size candidate final_byte_hex directory_resolved recovered_candidate=""
  run_dir_identity_ok || return 1
  [[ "$role" == "primary" || "$role" == "verifier" ]] || return 1
  [[ "$directory" == "${RUN_DIR_IO}/${role}" && -d "$directory" && ! -L "$directory" ]] || return 1
  directory_resolved="$(realpath -e -- "$directory" 2>/dev/null)" || return 1
  [[ "$(owner_of "$directory")" == "${EXPECTED_UID}:${EXPECTED_GID}" ]] || return 1
  [[ "$(mode_of "$directory")" == "700" ]] || return 1

  for index in 0 1; do
    evidence_path="${evidence_paths[$index]}"
    if [[ -L "$evidence_path" ]]; then
      return 1
    fi
    if [[ ! -e "$evidence_path" ]]; then
      continue
    fi
    [[ -f "$evidence_path" ]] || return 1
    [[ "$(owner_of "$evidence_path")" == "${EXPECTED_UID}:${EXPECTED_GID}" ]] || return 1
    [[ "$(mode_of "$evidence_path")" == "600" ]] || return 1
    evidence_size="$(stat -Lc '%s' -- "$evidence_path" 2>/dev/null)" || return 1
    [[ "$evidence_size" =~ ^[0-9]+$ ]] || return 1
    if [[ "$evidence_size" == "0" ]]; then
      evidence_states[$index]="empty"
      continue
    fi
    if [[ "$evidence_size" == "64" ]]; then
      candidate="$(LC_ALL=C head -c 64 -- "$evidence_path" 2>/dev/null)" || return 1
    elif [[ "$evidence_size" == "65" ]]; then
      final_byte_hex="$(LC_ALL=C tail -c 1 -- "$evidence_path" 2>/dev/null | od -An -tx1 | tr -d '[:space:]')" \
        || return 1
      [[ "$final_byte_hex" == "0a" ]] || return 1
      candidate="$(LC_ALL=C head -c 64 -- "$evidence_path" 2>/dev/null)" || return 1
    else
      return 1
    fi
    [[ "${#candidate}" == "64" && "$candidate" =~ ^[a-f0-9]{64}$ ]] || return 1
    evidence_candidates[$index]="$candidate"
    evidence_states[$index]="valid"
  done

  if [[ "${evidence_states[0]}" == "valid" && "${evidence_states[1]}" == "valid" ]]; then
    [[ "${evidence_candidates[0]}" == "${evidence_candidates[1]}" ]] || return 1
    recovered_candidate="${evidence_candidates[0]}"
  elif [[ "${evidence_states[0]}" == "valid" \
    && ( "${evidence_states[1]}" == "absent" || "${evidence_states[1]}" == "empty" ) ]]; then
    recovered_candidate="${evidence_candidates[0]}"
  elif [[ "${evidence_states[1]}" == "valid" \
    && ( "${evidence_states[0]}" == "absent" || "${evidence_states[0]}" == "empty" ) ]]; then
    recovered_candidate="${evidence_candidates[1]}"
  else
    return 1
  fi

  container_identity_matches "$recovered_candidate" "$expected_name" "$role" || return 1
  printf '%s' "$recovered_candidate"
}

cleanup_owned_container() {
  local role="$1"
  local id_value="$2"
  local expected_name="$3"
  local error_file="$4"
  local actual_id actual_name actual_run actual_scope actual_role actual_image
  local attempt_var
  if [[ "$role" == "primary" ]]; then
    attempt_var="PRIMARY_CLEANUP_ATTEMPTED"
  else
    attempt_var="VERIFIER_CLEANUP_ATTEMPTED"
  fi
  if [[ "${!attempt_var}" == "1" || -z "$id_value" ]]; then
    return 0
  fi
  printf -v "$attempt_var" '%s' "1"
  if [[ ! "$id_value" =~ ^[a-f0-9]{64}$ ]]; then
    safe_err "${role} cleanup skipped because captured ID was invalid"
    return 1
  fi
  if ! actual_id="$(docker_inspect_value '{{.Id}}' "$id_value")"; then
    prove_container_absent "$id_value" "$expected_name" || {
      safe_err "${role} absence could not be proven after inspect failure"
      return 1
    }
    return 0
  fi
  actual_name="$(docker_inspect_value '{{.Name}}' "$id_value")" || return 1
  actual_run="$(docker_inspect_value '{{index .Config.Labels "com.saboos.b0.run"}}' "$id_value")" || return 1
  actual_scope="$(docker_inspect_value '{{index .Config.Labels "com.saboos.b0.scope"}}' "$id_value")" || return 1
  actual_role="$(docker_inspect_value '{{index .Config.Labels "com.saboos.b0.role"}}' "$id_value")" || return 1
  actual_image="$(docker_inspect_value '{{.Image}}' "$id_value")" || return 1
  if [[ "$actual_id" != "$id_value" || "$actual_name" != "/${expected_name}" \
    || "$actual_run" != "$RUN_ID" || "$actual_scope" != "$B0_SCOPE_LABEL" \
    || "$actual_role" != "$role" || "$actual_image" != "$POSTGRES_IMAGE_ID" ]]; then
    safe_err "${role} cleanup identity could not be re-proven; container left untouched"
    return 1
  fi
  if run_dir_identity_ok && [[ "$error_file" == "$RUN_DIR_IO"/* && ! -e "$error_file" && ! -L "$error_file" ]]; then
    docker stop --time 30 "$id_value" >/dev/null 2>"$error_file" || {
      safe_err "${role} container stop failed; no retry or fallback target used"
      return 1
    }
  else
    docker stop --time 30 "$id_value" >/dev/null 2>/dev/null || {
      safe_err "${role} container stop failed without a trusted evidence path; no retry or fallback target used"
      return 1
    }
  fi
  local wait_count
  for wait_count in $(seq 1 60); do
    if ! docker inspect --type container "$id_value" >/dev/null 2>&1; then
      prove_container_absent "$id_value" "$expected_name" && return 0
    fi
    sleep 1
  done
  safe_err "${role} container remained after one ID-bound stop attempt"
  return 1
}

prove_container_absent() {
  local id_value="$1"
  local expected_name="$2"
  local snapshot line listed_id listed_name listed_run listed_scope
  snapshot="$(docker ps -a --no-trunc --format '{{.ID}}|{{.Names}}|{{.Label "com.saboos.b0.run"}}|{{.Label "com.saboos.b0.scope"}}')" \
    || return 1
  while IFS='|' read -r listed_id listed_name listed_run listed_scope; do
    [[ -n "$listed_id" ]] || continue
    [[ "$listed_id" != "$id_value" ]] || return 1
    [[ "$listed_name" != "$expected_name" ]] || return 1
    [[ "$listed_run" != "$RUN_ID" ]] || return 1
    if [[ "$listed_scope" == "$B0_SCOPE_LABEL" && "$listed_run" == "$RUN_ID" ]]; then
      return 1
    fi
  done <<< "$snapshot"
  return 0
}

prove_uncaptured_launch_absent() {
  local expected_name="$1"
  local snapshot listed_id listed_name listed_run listed_scope listed_role
  snapshot="$(docker ps -a --no-trunc --format '{{.ID}}|{{.Names}}|{{.Label "com.saboos.b0.run"}}|{{.Label "com.saboos.b0.scope"}}|{{.Label "com.saboos.b0.role"}}')" \
    || return 1
  while IFS='|' read -r listed_id listed_name listed_run listed_scope listed_role; do
    [[ -n "$listed_id" ]] || continue
    [[ "$listed_name" != "$expected_name" ]] || return 1
    [[ "$listed_run" != "$RUN_ID" ]] || return 1
  done <<< "$snapshot"
  return 0
}

on_exit() {
  local rc=$?
  local cleanup_failed=0
  local abort_status abort_hashes abort_hashes_hash recovered_id
  [[ "$EXIT_IN_PROGRESS" == "0" ]] || return
  EXIT_IN_PROGRESS=1
  set +e
  if [[ "$PRIMARY_LAUNCH_ATTEMPTED" == "1" ]]; then
    if [[ -z "$PRIMARY_ID" ]] && run_dir_identity_ok; then
      recovered_id="$(recover_launch_id_from_evidence "primary" "$PRIMARY_NAME" "$PRIMARY_DIR" 2>/dev/null || true)"
      [[ "$recovered_id" =~ ^[a-f0-9]{64}$ ]] && PRIMARY_ID="$recovered_id"
    fi
    if [[ -n "$PRIMARY_ID" ]]; then
      cleanup_owned_container "primary" "$PRIMARY_ID" "$PRIMARY_NAME" "${PRIMARY_DIR:-/nonexistent}/cleanup.stderr.raw" || cleanup_failed=1
    fi
    prove_uncaptured_launch_absent "$PRIMARY_NAME" || cleanup_failed=1
  fi
  if [[ "$VERIFIER_LAUNCH_ATTEMPTED" == "1" ]]; then
    if [[ -z "$VERIFIER_ID" ]] && run_dir_identity_ok; then
      recovered_id="$(recover_launch_id_from_evidence "verifier" "$VERIFIER_NAME" "$VERIFIER_DIR" 2>/dev/null || true)"
      [[ "$recovered_id" =~ ^[a-f0-9]{64}$ ]] && VERIFIER_ID="$recovered_id"
    fi
    if [[ -n "$VERIFIER_ID" ]]; then
      cleanup_owned_container "verifier" "$VERIFIER_ID" "$VERIFIER_NAME" "${VERIFIER_DIR:-/nonexistent}/cleanup.stderr.raw" || cleanup_failed=1
    fi
    prove_uncaptured_launch_absent "$VERIFIER_NAME" || cleanup_failed=1
  fi
  if [[ "$rc" != "0" || "$cleanup_failed" != "0" ]]; then
    if run_dir_identity_ok; then
      abort_status="${RUN_DIR_IO}/abort-status.safe"
      abort_hashes="${RUN_DIR_IO}/abort-raw-artifacts.sha256"
      if run_dir_identity_ok && [[ ! -e "$abort_status" && ! -L "$abort_status" ]]; then
        printf 'status=ABORTED\nabort_stage=%s\ncleanup_identity_failure=%s\nraw_artifacts=not_printed\n' \
          "$ABORT_REASON" "$cleanup_failed" >"$abort_status"
      fi
      if run_dir_identity_ok && [[ ! -e "$abort_hashes" && ! -L "$abort_hashes" ]]; then
        (
          cd "$RUN_DIR_IO" || exit 1
          find . -type f \( -name '*.stderr.raw' -o -name '*.stdout.raw' \) -print0 \
            | LC_ALL=C sort -z | xargs -0 -r sha256sum
        ) >"$abort_hashes" 2>/dev/null || true
      fi
      if run_dir_identity_ok && [[ -f "$abort_hashes" && ! -L "$abort_hashes" ]]; then
        abort_hashes_hash="$(sha256_of "$abort_hashes" 2>/dev/null || true)"
        if canonical_run_path_ok; then
          safe_err "abort evidence: ${RUN_DIR}/abort-status.safe"
          safe_err "raw-artifact hash inventory: ${RUN_DIR}/abort-raw-artifacts.sha256 sha256=${abort_hashes_hash:-unavailable}"
        else
          safe_err "abort evidence was retained on the verified run-directory inode; canonical path identity is unavailable"
        fi
      fi
      if canonical_run_path_ok; then
        safe_err "run retained for review: ${RUN_DIR}"
      else
        safe_err "verified run-directory inode retained, but its canonical path identity is unavailable"
      fi
    else
      safe_err "run directory identity unavailable; no abort evidence was written"
    fi
    safe_err "abort stage: ${ABORT_REASON}"
  fi
  if [[ "$cleanup_failed" != "0" && "$rc" == "0" ]]; then
    rc=1
  fi
  exit "$rc"
}
trap on_exit EXIT

source_psql_file() {
  local app="$1"
  local output="$2"
  local error_output="$3"
  require_run_owned_target "$output"
  require_run_owned_target "$error_output"
  require_regex "$app" '^[a-z0-9_]{1,63}$' "source PostgreSQL application name"
  [[ ! -e "$output" && ! -L "$output" && ! -e "$error_output" && ! -L "$error_output" ]] \
    || die "source evidence path already exists"
  docker exec -i \
    --env "PGAPPNAME=${app}" \
    --env 'PGOPTIONS=-c default_transaction_read_only=on -c statement_timeout=240000 -c lock_timeout=5000' \
    "$LIVE_DB_ID" \
    psql --no-psqlrc --no-password --set=ON_ERROR_STOP=1 --quiet --tuples-only --no-align --field-separator='|' \
      --host="$PG_SOCKET" --port="$PG_PORT" --username="$PG_USER" --dbname="$PG_DATABASE" \
      >"$output" 2>"$error_output"
}

disposable_psql_file() {
  local container_id="$1"
  local database="$2"
  local app="$3"
  local output="$4"
  local error_output="$5"
  require_run_owned_target "$output"
  require_run_owned_target "$error_output"
  require_regex "$container_id" '^[a-f0-9]{64}$' "disposable container ID"
  require_regex "$database" '^[a-z][a-z0-9_]{1,62}$' "disposable database name"
  require_regex "$app" '^[a-z0-9_]{1,63}$' "disposable PostgreSQL application name"
  [[ ! -e "$output" && ! -L "$output" && ! -e "$error_output" && ! -L "$error_output" ]] \
    || die "disposable evidence path already exists"
  docker exec -i \
    --env "PGAPPNAME=${app}" \
    --env 'PGOPTIONS=-c default_transaction_read_only=on -c statement_timeout=240000 -c lock_timeout=5000' \
    "$container_id" \
    psql --no-psqlrc --no-password --set=ON_ERROR_STOP=1 --quiet --tuples-only --no-align --field-separator='|' \
      --host="$PG_SOCKET" --port="$PG_PORT" --username="$PG_USER" --dbname="$database" \
      >"$output" 2>"$error_output"
}

emit_schema_catalog_sql() {
  cat <<'SQL'
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='240s';
SET LOCAL lock_timeout='5s';
WITH catalog(kind, payload) AS (
  SELECT 'RELATION', encode(convert_to(concat_ws(chr(31), n.nspname, c.relname, c.relkind::text,
         c.relpersistence::text, c.relrowsecurity::text, c.relforcerowsecurity::text), 'UTF8'), 'hex')
    FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
   WHERE n.nspname='public' AND c.relkind IN ('r','p','S','v','m','f','c')
  UNION ALL
  SELECT 'COLUMN', encode(convert_to(concat_ws(chr(31), n.nspname, c.relname, a.attnum::text, a.attname,
         pg_catalog.format_type(a.atttypid,a.atttypmod), a.attnotnull::text, a.attidentity::text,
         a.attgenerated::text, COALESCE(cn.nspname,''), COALESCE(coll.collname,''),
         COALESCE(pg_get_expr(d.adbin,d.adrelid,true),'')), 'UTF8'), 'hex')
    FROM pg_attribute a
    JOIN pg_class c ON c.oid=a.attrelid
    JOIN pg_namespace n ON n.oid=c.relnamespace
    LEFT JOIN pg_attrdef d ON d.adrelid=a.attrelid AND d.adnum=a.attnum
    LEFT JOIN pg_collation coll ON coll.oid=a.attcollation
    LEFT JOIN pg_namespace cn ON cn.oid=coll.collnamespace
   WHERE n.nspname='public' AND c.relkind IN ('r','p','S','v','m','f','c') AND a.attnum>0 AND NOT a.attisdropped
  UNION ALL
  SELECT 'CONSTRAINT', encode(convert_to(concat_ws(chr(31), n.nspname, COALESCE(c.relname,''), con.conname,
         con.contype::text, con.condeferrable::text, con.condeferred::text, con.convalidated::text,
         pg_get_constraintdef(con.oid,true)), 'UTF8'), 'hex')
    FROM pg_constraint con
    JOIN pg_namespace n ON n.oid=con.connamespace
    LEFT JOIN pg_class c ON c.oid=con.conrelid
   WHERE n.nspname='public'
  UNION ALL
  SELECT 'INDEX', encode(convert_to(concat_ws(chr(31), n.nspname, t.relname, i.relname,
         x.indisunique::text, x.indisprimary::text, x.indisvalid::text, x.indisready::text,
         pg_get_indexdef(i.oid)), 'UTF8'), 'hex')
    FROM pg_index x
    JOIN pg_class i ON i.oid=x.indexrelid
    JOIN pg_class t ON t.oid=x.indrelid
    JOIN pg_namespace n ON n.oid=t.relnamespace
   WHERE n.nspname='public'
  UNION ALL
  SELECT 'TRIGGER', encode(convert_to(concat_ws(chr(31), n.nspname, c.relname, t.tgname, t.tgenabled::text,
         pg_get_triggerdef(t.oid,true)), 'UTF8'), 'hex')
    FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace
   WHERE n.nspname='public' AND NOT t.tgisinternal
  UNION ALL
  SELECT 'FUNCTION', encode(convert_to(concat_ws(chr(31), n.nspname, p.proname,
         pg_get_function_identity_arguments(p.oid), pg_get_function_result(p.oid), l.lanname,
         p.prokind::text, p.provolatile::text, p.prosecdef::text, p.proleakproof::text,
         p.proisstrict::text, p.proparallel::text, COALESCE(array_to_string(p.proconfig,','),''),
         pg_get_functiondef(p.oid)), 'UTF8'), 'hex')
    FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace JOIN pg_language l ON l.oid=p.prolang
   WHERE n.nspname='public'
  UNION ALL
  SELECT 'POLICY', encode(convert_to(concat_ws(chr(31), n.nspname, c.relname, p.polname,
         p.polpermissive::text, p.polcmd::text, COALESCE(array_to_string(p.polroles,','),''),
         COALESCE(pg_get_expr(p.polqual,p.polrelid,true),''),
         COALESCE(pg_get_expr(p.polwithcheck,p.polrelid,true),'')), 'UTF8'), 'hex')
   FROM pg_policy p JOIN pg_class c ON c.oid=p.polrelid JOIN pg_namespace n ON n.oid=c.relnamespace
   WHERE n.nspname='public'
  UNION ALL
  SELECT 'VIEW_DEFINITION', encode(convert_to(concat_ws(chr(31), n.nspname, c.relname,
         c.relkind::text, pg_get_viewdef(c.oid,true)), 'UTF8'), 'hex')
    FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
   WHERE n.nspname='public' AND c.relkind IN ('v','m')
  UNION ALL
  SELECT 'PARTITION', encode(convert_to(concat_ws(chr(31), pn.nspname, parent.relname,
         cn.nspname, child.relname, pg_get_expr(child.relpartbound,child.oid,true)), 'UTF8'), 'hex')
    FROM pg_inherits i
    JOIN pg_class parent ON parent.oid=i.inhparent
    JOIN pg_namespace pn ON pn.oid=parent.relnamespace
    JOIN pg_class child ON child.oid=i.inhrelid
   JOIN pg_namespace cn ON cn.oid=child.relnamespace
   WHERE pn.nspname='public' OR cn.nspname='public'
  UNION ALL
  SELECT 'PARTITION_KEY', encode(convert_to(concat_ws(chr(31), n.nspname, c.relname,
         p.partstrat::text, pg_get_partkeydef(c.oid)), 'UTF8'), 'hex')
    FROM pg_partitioned_table p JOIN pg_class c ON c.oid=p.partrelid JOIN pg_namespace n ON n.oid=c.relnamespace
   WHERE n.nspname='public'
  UNION ALL
  SELECT 'FOREIGN_TABLE', encode(convert_to(concat_ws(chr(31), n.nspname, c.relname, s.srvname,
         md5(COALESCE(array_to_string(ft.ftoptions,chr(31)),''))), 'UTF8'), 'hex')
    FROM pg_foreign_table ft
    JOIN pg_class c ON c.oid=ft.ftrelid
    JOIN pg_namespace n ON n.oid=c.relnamespace
    JOIN pg_foreign_server s ON s.oid=ft.ftserver
   WHERE n.nspname='public'
  UNION ALL
  SELECT 'DOMAIN', encode(convert_to(concat_ws(chr(31), n.nspname, t.typname,
         pg_catalog.format_type(t.typbasetype,t.typtypmod), t.typnotnull::text,
         COALESCE(t.typdefault,''), COALESCE(cn.nspname,''), COALESCE(coll.collname,'')), 'UTF8'), 'hex')
    FROM pg_type t
    JOIN pg_namespace n ON n.oid=t.typnamespace
    LEFT JOIN pg_collation coll ON coll.oid=t.typcollation
    LEFT JOIN pg_namespace cn ON cn.oid=coll.collnamespace
   WHERE n.nspname='public' AND t.typtype='d'
  UNION ALL
  SELECT 'RANGE', encode(convert_to(concat_ws(chr(31), n.nspname, t.typname,
         pg_catalog.format_type(r.rngsubtype,NULL), r.rngcollation::regcollation::text,
         opn.nspname, opc.opcname, am.amname, r.rngcanonical::regprocedure::text,
         r.rngsubdiff::regprocedure::text, r.rngmultitypid::regtype::text), 'UTF8'), 'hex')
    FROM pg_range r
    JOIN pg_type t ON t.oid=r.rngtypid
    JOIN pg_namespace n ON n.oid=t.typnamespace
    JOIN pg_opclass opc ON opc.oid=r.rngsubopc
    JOIN pg_namespace opn ON opn.oid=opc.opcnamespace
    JOIN pg_am am ON am.oid=opc.opcmethod
   WHERE n.nspname='public'
  UNION ALL
  SELECT 'ENUM', encode(convert_to(concat_ws(chr(31), n.nspname, t.typname, e.enumsortorder::text, e.enumlabel), 'UTF8'), 'hex')
    FROM pg_enum e JOIN pg_type t ON t.oid=e.enumtypid JOIN pg_namespace n ON n.oid=t.typnamespace
   WHERE n.nspname='public'
  UNION ALL
  SELECT 'SEQUENCE', encode(convert_to(concat_ws(chr(31), n.nspname, c.relname, s.seqstart::text,
         s.seqincrement::text, s.seqmax::text, s.seqmin::text, s.seqcache::text, s.seqcycle::text), 'UTF8'), 'hex')
    FROM pg_sequence s JOIN pg_class c ON c.oid=s.seqrelid JOIN pg_namespace n ON n.oid=c.relnamespace
   WHERE n.nspname='public'
  UNION ALL
  SELECT 'EXTENSION', encode(convert_to(concat_ws(chr(31), e.extname, e.extversion), 'UTF8'), 'hex')
    FROM pg_extension e
)
SELECT kind, payload FROM catalog ORDER BY kind, payload;
COMMIT;
SQL
}

emit_migration_fingerprint_sql() {
  cat <<'SQL'
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='120s';
SET LOCAL lock_timeout='5s';
SELECT migration_name, checksum,
       CASE WHEN rolled_back_at IS NOT NULL THEN 'rolled_back'
            WHEN finished_at IS NOT NULL THEN 'complete'
            ELSE 'unresolved' END,
       applied_steps_count::text
  FROM public._prisma_migrations
 ORDER BY migration_name;
COMMIT;
SQL
}

emit_dumpable_schema_inventory_sql() {
  cat <<'SQL'
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='120s';
SET LOCAL lock_timeout='5s';
SELECT nspname
  FROM pg_namespace
 WHERE nspname <> 'information_schema'
   AND nspname !~ '^pg_'
 ORDER BY nspname;
COMMIT;
SQL
}

emit_table_counts_sql() {
  cat <<'SQL'
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='240s';
SET LOCAL lock_timeout='5s';
SELECT format('SELECT %L::text AS table_name, count(*)::bigint AS row_count FROM %I.%I',
              table_schema || '.' || table_name, table_schema, table_name)
  FROM information_schema.tables
 WHERE table_schema='public' AND table_type='BASE TABLE'
 ORDER BY table_name
\gexec
COMMIT;
SQL
}

emit_logical_summary_sql() {
  cat <<'SQL'
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='120s';
SET LOCAL lock_timeout='5s';
WITH migration_counts AS (
  SELECT count(*)::bigint AS total,
         count(*) FILTER (WHERE finished_at IS NOT NULL AND rolled_back_at IS NULL)::bigint AS complete,
         count(*) FILTER (WHERE rolled_back_at IS NOT NULL)::bigint AS rolled_back,
         count(*) FILTER (WHERE finished_at IS NULL AND rolled_back_at IS NULL)::bigint AS unresolved
    FROM public._prisma_migrations
), facts(label,value) AS (
  SELECT 'database_encoding', pg_encoding_to_char(encoding) FROM pg_database WHERE datname=current_database()
  UNION ALL SELECT 'database_collation', datcollate FROM pg_database WHERE datname=current_database()
  UNION ALL SELECT 'database_ctype', datctype FROM pg_database WHERE datname=current_database()
  UNION ALL SELECT 'database_locale_provider', datlocprovider::text FROM pg_database WHERE datname=current_database()
  UNION ALL SELECT 'postgres_server_version', current_setting('server_version')
  UNION ALL SELECT 'public_base_tables', count(*)::text FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE'
  UNION ALL SELECT 'migrations_total', total::text FROM migration_counts
  UNION ALL SELECT 'migrations_complete', complete::text FROM migration_counts
  UNION ALL SELECT 'migrations_rolled_back', rolled_back::text FROM migration_counts
  UNION ALL SELECT 'migrations_unresolved', unresolved::text FROM migration_counts
  UNION ALL SELECT 'unvalidated_public_constraints', count(*)::text
    FROM pg_constraint con JOIN pg_namespace n ON n.oid=con.connamespace
   WHERE n.nspname='public' AND NOT con.convalidated
  UNION ALL SELECT 'large_objects', count(*)::text FROM pg_largeobject_metadata
  UNION ALL SELECT 'event_triggers', count(*)::text FROM pg_event_trigger
  UNION ALL SELECT 'foreign_servers', count(*)::text FROM pg_foreign_server
  UNION ALL SELECT 'subscriptions', count(*)::text FROM pg_subscription
  UNION ALL SELECT 'publications', count(*)::text FROM pg_publication
  UNION ALL SELECT 'public_non_plpgsql_functions', count(*)::text
    FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace JOIN pg_language l ON l.oid=p.prolang
   WHERE n.nspname='public' AND l.lanname <> 'plpgsql'
  UNION ALL SELECT 'dumpable_non_system_schemas', string_agg(nspname,',' ORDER BY nspname)
    FROM pg_namespace
   WHERE nspname <> 'information_schema' AND nspname !~ '^pg_'
  UNION ALL SELECT 'extension', extname || '|' || extversion FROM pg_extension
)
SELECT label, value FROM facts ORDER BY label, value;
COMMIT;
SQL
}

emit_audit_segments_sql() {
  cat <<'SQL'
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='120s';
SET LOCAL lock_timeout='5s';
WITH ordered AS (
  SELECT row_number() OVER (ORDER BY created_at, id) AS rn, id, row_hash
    FROM public.audit_logs
), first_non_null AS (
  SELECT min(rn) AS rn FROM ordered WHERE row_hash IS NOT NULL
), first_break AS (
  SELECT min(o.rn) AS rn FROM ordered o CROSS JOIN first_non_null f
   WHERE o.row_hash IS NULL AND o.rn > f.rn
), first_resume AS (
  SELECT min(o.rn) AS rn FROM ordered o CROSS JOIN first_break b
   WHERE o.row_hash IS NOT NULL AND o.rn > b.rn
), facts(label,value) AS (
  SELECT 'total', count(*)::text FROM ordered
  UNION ALL SELECT 'unchained_prefix', count(*)::text FROM ordered o CROSS JOIN first_non_null f
    WHERE o.row_hash IS NULL AND o.rn < f.rn
  UNION ALL SELECT 'non_null_before_first_break', count(*)::text
    FROM ordered o CROSS JOIN first_non_null f CROSS JOIN first_break b
   WHERE o.row_hash IS NOT NULL AND o.rn >= f.rn AND o.rn < b.rn
  UNION ALL SELECT 'first_break_null_run', count(*)::text
    FROM ordered o CROSS JOIN first_break b CROSS JOIN first_resume r
   WHERE o.row_hash IS NULL AND o.rn >= b.rn AND o.rn < r.rn
  UNION ALL SELECT 'non_null_after_first_break', count(*)::text
    FROM ordered o CROSS JOIN first_resume r WHERE o.row_hash IS NOT NULL AND o.rn >= r.rn
  UNION ALL SELECT 'null_after_first_resume', count(*)::text
    FROM ordered o CROSS JOIN first_resume r WHERE o.row_hash IS NULL AND o.rn >= r.rn
  UNION ALL SELECT 'first_break_id', o.id FROM ordered o CROSS JOIN first_break b WHERE o.rn=b.rn
)
SELECT label, value FROM facts ORDER BY label;
COMMIT;
SQL
}

emit_sequence_values_sql() {
  cat <<'SQL'
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='120s';
SET LOCAL lock_timeout='5s';
SELECT schemaname || '.' || sequencename, COALESCE(last_value::text,'NULL'),
       start_value::text, increment_by::text, min_value::text, max_value::text,
       cache_size::text, cycle::text
  FROM pg_sequences
 WHERE schemaname='public'
 ORDER BY schemaname, sequencename;
COMMIT;
SQL
}

validate_pinned_logical_summary() {
  local file="$1"
  require_line "$file" "database_encoding|${EXPECTED_DB_ENCODING}"
  require_line "$file" "database_collation|${EXPECTED_DB_COLLATE}"
  require_line "$file" "database_ctype|${EXPECTED_DB_CTYPE}"
  require_line "$file" "database_locale_provider|${EXPECTED_LOCALE_PROVIDER}"
  require_line "$file" "postgres_server_version|${EXPECTED_PG_VERSION}"
  require_line "$file" "public_base_tables|${EXPECTED_PUBLIC_TABLES}"
  require_line "$file" "migrations_total|${EXPECTED_MIGRATIONS_TOTAL}"
  require_line "$file" "migrations_complete|${EXPECTED_MIGRATIONS_COMPLETE}"
  require_line "$file" "migrations_rolled_back|${EXPECTED_MIGRATIONS_ROLLED_BACK}"
  require_line "$file" "migrations_unresolved|${EXPECTED_MIGRATIONS_UNRESOLVED}"
  require_line "$file" "unvalidated_public_constraints|0"
  require_line "$file" "large_objects|0"
  require_line "$file" "event_triggers|0"
  require_line "$file" "foreign_servers|0"
  require_line "$file" "subscriptions|0"
  require_line "$file" "publications|0"
  require_line "$file" "public_non_plpgsql_functions|0"
  require_line "$file" "dumpable_non_system_schemas|public"
  require_line "$file" "extension|plpgsql|1.0"
  [[ "$(awk -F'|' '$1=="extension" {n++} END {print n+0}' "$file")" == "1" ]] \
    || die "extension inventory differs from the expected plpgsql-only set"
}

capture_source_evidence() {
  local phase="$1"
  local prefix="${PRIMARY_DIR}/source-${phase}"
  assert_live_db_pin
  emit_schema_catalog_sql | source_psql_file "b0_${RUN_SUFFIX}_src_${phase}_schema" "${prefix}-schema-catalog.tsv" "${prefix}-schema.stderr.raw"
  capture_schema_only_hash "source" "$LIVE_DB_ID" "$PG_DATABASE" "$PG_DATABASE" \
    "b0_${RUN_SUFFIX}_src_${phase}_schemadump" "${prefix}-schema-dump.sha256" "${prefix}-schema-dump.stderr.raw"
  emit_migration_fingerprint_sql | source_psql_file "b0_${RUN_SUFFIX}_src_${phase}_migrations" "${prefix}-migrations.tsv" "${prefix}-migrations.stderr.raw"
  emit_dumpable_schema_inventory_sql | source_psql_file "b0_${RUN_SUFFIX}_src_${phase}_schemas" "${prefix}-dumpable-schemas.tsv" "${prefix}-dumpable-schemas.stderr.raw"
  emit_table_counts_sql | source_psql_file "b0_${RUN_SUFFIX}_src_${phase}_counts" "${prefix}-table-counts.tsv" "${prefix}-table-counts.stderr.raw"
  emit_logical_summary_sql | source_psql_file "b0_${RUN_SUFFIX}_src_${phase}_summary" "${prefix}-logical-summary.tsv" "${prefix}-logical-summary.stderr.raw"
  [[ "$(wc -l < "${prefix}-table-counts.tsv" | tr -d '[:space:]')" == "$EXPECTED_PUBLIC_TABLES" ]] \
    || die "source table-count cardinality drifted"
  [[ "$(wc -l < "${prefix}-migrations.tsv" | tr -d '[:space:]')" == "$EXPECTED_MIGRATIONS_TOTAL" ]] \
    || die "source migration-ledger cardinality drifted"
  [[ "$(wc -l < "${prefix}-dumpable-schemas.tsv" | tr -d '[:space:]')" == "1" ]] \
    || die "source contains a dumpable non-system schema set other than public-only"
  require_line "${prefix}-dumpable-schemas.tsv" "public"
  validate_pinned_logical_summary "${prefix}-logical-summary.tsv"
}

assert_dump_app_absent() {
  local target_app="$1"
  local attempt result sql probe_app probe_tag
  require_regex "$target_app" '^[a-z0-9_]{1,63}$' "dump application name"
  probe_tag="$(printf '%s' "$target_app" | sha256sum | awk '{print substr($1,1,8)}')"
  require_regex "$probe_tag" '^[a-f0-9]{8}$' "dump-session probe tag"
  for attempt in $(seq -w 1 30); do
    probe_app="b0_${RUN_SUFFIX}_gone_${probe_tag}_${attempt}"
    sql="BEGIN TRANSACTION READ ONLY; SET LOCAL statement_timeout='10s'; SET LOCAL lock_timeout='5s'; SELECT count(*) FROM pg_stat_activity WHERE application_name='${target_app}' AND pid <> pg_backend_pid(); COMMIT;"
    result="$(source_psql_capture "$probe_app" "$sql")" || die "could not prove dump session termination"
    [[ "$result" == "0" ]] && return 0
    sleep 1
  done
  die "run-owned dump database session remains; it was not terminated by this script"
}

capture_dump() {
  local partial="$1"
  local stderr_file="$2"
  local app="b0_${RUN_SUFFIX}_pg_dump"
  local rc
  require_run_owned_target "$partial"
  require_run_owned_target "$stderr_file"
  [[ ! -e "$partial" && ! -L "$partial" && ! -e "$stderr_file" && ! -L "$stderr_file" ]] \
    || die "dump output path already exists"
  assert_live_db_pin
  set +e
  docker exec \
    --env "PGAPPNAME=${app}" \
    --env 'PGOPTIONS=-c default_transaction_read_only=on -c statement_timeout=600000 -c lock_timeout=5000' \
    "$LIVE_DB_ID" \
    busybox timeout -s TERM -k 30 600 \
    pg_dump --host="$PG_SOCKET" --port="$PG_PORT" --username="$PG_USER" --dbname="$PG_DATABASE" \
      --format=custom --compress=9 --no-owner --no-privileges --no-password \
      >"$partial" 2>"$stderr_file"
  rc=$?
  set -e
  assert_dump_app_absent "$app"
  [[ "$rc" == "0" ]] || die "pinned pg_dump failed; raw stderr was retained without being printed"
  [[ "$(mode_of "$partial")" == "600" ]] || die "partial dump mode is not 0600"
  [[ "$(owner_of "$partial")" == "${EXPECTED_UID}:${EXPECTED_GID}" ]] || die "partial dump owner mismatch"
  (( $(size_of "$partial") > 0 )) || die "partial dump is empty"
}

generate_and_validate_toc() {
  local dump_file="$1"
  local toc_raw="${PRIMARY_DIR}/dump.toc.raw"
  local toc_err="${PRIMARY_DIR}/dump-toc.stderr.raw"
  local parsed="${PRIMARY_DIR}/dump.toc.structural.tsv"
  local table_names="${PRIMARY_DIR}/dump.public-table-names.txt"
  local data_names="${PRIMARY_DIR}/dump.public-table-data-names.txt"
  local schema_names="${PRIMARY_DIR}/dump.dumpable-schema-names.txt"
  local schema_definitions="${PRIMARY_DIR}/dump.schema-definition-names.txt"
  local table_count data_count invalid_names non_public_count schema_definition_count
  require_run_owned_target "$dump_file"
  require_run_owned_target "$toc_raw"
  require_run_owned_target "$toc_err"
  require_run_owned_target "$parsed"
  require_run_owned_target "$table_names"
  require_run_owned_target "$data_names"
  require_run_owned_target "$schema_names"
  require_run_owned_target "$schema_definitions"
  [[ ! -e "$toc_raw" && ! -L "$toc_raw" && ! -e "$toc_err" && ! -L "$toc_err" ]] || die "TOC evidence path exists"
  docker exec -i "$LIVE_DB_ID" busybox timeout -s TERM -k 30 120 pg_restore --list \
    <"$dump_file" >"$toc_raw" 2>"$toc_err" || die "pinned PostgreSQL 16.14 could not read the dump TOC"
  awk -F'; ' '
    /^;/ { next }
    NF != 2 { next }
    {
      n=split($2,a,/ +/)
      if (n >= 7 && a[3] == "TABLE" && a[4] == "DATA") {
        print "TABLE DATA|" a[5] "|" a[6]
      } else if (n >= 6 && a[3] == "TABLE") {
        print "TABLE|" a[4] "|" a[5]
      }
    }
  ' "$toc_raw" | LC_ALL=C sort >"$parsed"
  table_count="$(awk -F'|' '$1=="TABLE" {n++} END {print n+0}' "$parsed")"
  data_count="$(awk -F'|' '$1=="TABLE DATA" {n++} END {print n+0}' "$parsed")"
  [[ "$table_count" == "$EXPECTED_PUBLIC_TABLES" ]] || die "dump TOC public TABLE cardinality mismatch"
  [[ "$data_count" == "$EXPECTED_PUBLIC_TABLES" ]] || die "dump TOC public TABLE DATA cardinality mismatch"
  non_public_count="$(awk -F'|' '$2 != "public" {n++} END {print n+0}' "$parsed")"
  [[ "$non_public_count" == "0" ]] || die "dump TOC contains a non-public TABLE or TABLE DATA namespace"
  invalid_names="$(awk -F'|' '$2 !~ /^[a-z_][a-z0-9_]*$/ || $3 !~ /^[A-Za-z_][A-Za-z0-9_]*$/ {n++} END {print n+0}' "$parsed")"
  [[ "$invalid_names" == "0" ]] || die "dump TOC contained an unexpected schema or table identifier"
  [[ "$(awk -F'|' '$1=="TABLE DATA" && $2=="public" && $3=="audit_logs" {n++} END {print n+0}' "$parsed")" == "1" ]] \
    || die "dump TOC does not contain exactly one audit_logs TABLE DATA entry"
  [[ "$(awk -F'|' '$1=="TABLE DATA" && $2=="public" && $3=="_prisma_migrations" {n++} END {print n+0}' "$parsed")" == "1" ]] \
    || die "dump TOC does not contain exactly one _prisma_migrations TABLE DATA entry"
  awk -F'|' '$1=="TABLE" {print $3}' "$parsed" | LC_ALL=C sort >"$table_names"
  awk -F'|' '$1=="TABLE DATA" {print $3}' "$parsed" | LC_ALL=C sort >"$data_names"
  cmp -s "$table_names" "$data_names" || die "dump TOC TABLE and TABLE DATA name sets differ"
  awk -F'; ' '
    /^;/ { next }
    NF != 2 { next }
    {
      n=split($2,a,/ +/)
      if (n >= 6 && a[3] == "SCHEMA" && a[4] == "-") print a[5]
    }
  ' "$toc_raw" | LC_ALL=C sort >"$schema_definitions"
  schema_definition_count="$(wc -l < "$schema_definitions" | tr -d '[:space:]')"
  require_regex "$schema_definition_count" '^[0-9]+$' "dump TOC schema-definition count"
  (( schema_definition_count <= 1 )) || die "dump TOC contains multiple schema-definition entries"
  [[ "$(awk '$0 != "public" {n++} END {print n+0}' "$schema_definitions")" == "0" ]] \
    || die "dump TOC contains a non-public schema-definition entry"
  {
    awk -F'|' '$1=="TABLE" || $1=="TABLE DATA" {print $2}' "$parsed" || exit 1
    cat "$schema_definitions" || exit 1
  } | LC_ALL=C sort -u >"$schema_names"
  [[ "$(wc -l < "$schema_names" | tr -d '[:space:]')" == "1" ]] \
    || die "dump TOC namespaced object set is not public-only"
  require_line "$schema_names" "public"
  cmp -s "${PRIMARY_DIR}/source-pre-dumpable-schemas.tsv" "$schema_names" \
    || die "dump TOC schema inventory differs from the source snapshot"
}

finalize_dump() {
  local partial="$1"
  local final="$2"
  require_run_owned_target "$partial"
  require_run_owned_target "$final"
  [[ -f "$partial" && ! -L "$partial" ]] || die "partial dump vanished before finalization"
  [[ ! -e "$final" && ! -L "$final" ]] || die "final dump destination already exists"
  mv --no-clobber -- "$partial" "$final"
  [[ ! -e "$partial" && -f "$final" && ! -L "$final" ]] || die "atomic dump finalization failed"
  [[ "$(mode_of "$final")" == "600" && "$(owner_of "$final")" == "${EXPECTED_UID}:${EXPECTED_GID}" ]] \
    || die "final dump protection mismatch"
  sync -f "$final"
  sync -f "$RUN_DIR_IO"
}

record_dump_hash() {
  local dump_file="$1"
  local output="$2"
  local expected_hash="$3"
  local current_hash dump_basename
  require_run_owned_target "$dump_file"
  require_run_owned_target "$output"
  current_hash="$(sha256_of "$dump_file")"
  require_regex "$current_hash" '^[a-f0-9]{64}$' "dump SHA-256"
  dump_basename="$(basename "$dump_file")"
  [[ -n "$dump_basename" && "$dump_basename" != */* ]] || die "invalid dump basename"
  [[ -z "$expected_hash" || "$current_hash" == "$expected_hash" ]] || die "retained dump hash changed"
  write_new_lines "$output" "${current_hash}  ${dump_basename}"
  printf '%s' "$current_hash"
}

require_tmpfs_tokens() {
  local options="$1"
  shift
  local token
  for token in "$@"; do
    [[ ",${options}," == *",${token},"* ]] || die "disposable tmpfs option mismatch"
  done
}

verify_disposable_insulation() {
  local id_value="$1"
  local database="$2"
  local role="$3"
  local expected_name="$4"
  local evidence_file="$5"
  local actual api_mounts runtime_mounts cap_drop security_opt tmp_data tmp_socket tmp_temp core_limit runtime_settings runtime_sql
  [[ "$(docker_inspect_value '{{.Id}}' "$id_value")" == "$id_value" ]] || die "disposable container ID mismatch"
  [[ "$(docker_inspect_value '{{.Name}}' "$id_value")" == "/${expected_name}" ]] || die "disposable container name mismatch"
  [[ "$(docker_inspect_value '{{.Image}}' "$id_value")" == "$POSTGRES_IMAGE_ID" ]] || die "disposable image mismatch"
  [[ "$(docker_inspect_value '{{index .Config.Labels "com.saboos.b0.run"}}' "$id_value")" == "$RUN_ID" ]] || die "disposable run label mismatch"
  [[ "$(docker_inspect_value '{{index .Config.Labels "com.saboos.b0.scope"}}' "$id_value")" == "$B0_SCOPE_LABEL" ]] || die "disposable scope label mismatch"
  [[ "$(docker_inspect_value '{{index .Config.Labels "com.saboos.b0.role"}}' "$id_value")" == "$role" ]] || die "disposable role label mismatch"
  [[ "$(docker_inspect_value '{{.HostConfig.ReadonlyRootfs}}' "$id_value")" == "true" ]] || die "disposable root filesystem is not read-only"
  [[ "$(docker_inspect_value '{{.Config.User}}' "$id_value")" == "70:70" ]] || die "disposable user mismatch"
  cap_drop="$(docker_inspect_value '{{range .HostConfig.CapDrop}}{{.}} {{end}}' "$id_value" | awk '{$1=$1;print}')"
  [[ "$cap_drop" == "ALL" ]] || die "disposable capabilities are not fully dropped"
  security_opt="$(docker_inspect_value '{{range .HostConfig.SecurityOpt}}{{.}} {{end}}' "$id_value" | awk '{$1=$1;print}')"
  [[ "$security_opt" == "no-new-privileges:true" ]] || die "disposable no-new-privileges setting mismatch"
  [[ "$(docker_inspect_value '{{.HostConfig.NetworkMode}}' "$id_value")" == "none" ]] || die "disposable network mode mismatch"
  [[ "$(docker_inspect_value '{{len .HostConfig.PortBindings}}' "$id_value")" == "0" ]] || die "disposable port binding exists"
  [[ "$(docker_inspect_value '{{.HostConfig.Memory}}' "$id_value")" == "1073741824" ]] || die "disposable memory limit mismatch"
  [[ "$(docker_inspect_value '{{.HostConfig.MemorySwap}}' "$id_value")" == "1073741824" ]] || die "disposable memory-swap limit mismatch"
  [[ "$(docker_inspect_value '{{printf "%v" .HostConfig.MemorySwappiness}}' "$id_value")" == "<nil>" ]] \
    || die "disposable memory swappiness override was unexpectedly materialized"
  [[ "$(docker_inspect_value '{{.HostConfig.PidsLimit}}' "$id_value")" == "256" ]] || die "disposable PID limit mismatch"
  [[ "$(docker_inspect_value '{{.HostConfig.NanoCpus}}' "$id_value")" == "1000000000" ]] || die "disposable CPU limit mismatch"
  core_limit="$(docker_inspect_value '{{range .HostConfig.Ulimits}}{{if eq .Name "core"}}{{.Soft}}:{{.Hard}}{{end}}{{end}}' "$id_value")"
  [[ "$core_limit" == "0:0" ]] || die "disposable core-dump limit mismatch"
  [[ "$(docker_inspect_value '{{.RestartCount}}' "$id_value")" == "0" ]] || die "disposable container restarted"
  [[ "$(docker_inspect_value '{{len .HostConfig.Tmpfs}}' "$id_value")" == "3" ]] || die "disposable tmpfs declaration count mismatch"
  tmp_data="$(docker_inspect_value '{{index .HostConfig.Tmpfs "/var/lib/postgresql/data"}}' "$id_value")"
  tmp_socket="$(docker_inspect_value '{{index .HostConfig.Tmpfs "/var/run/postgresql"}}' "$id_value")"
  tmp_temp="$(docker_inspect_value '{{index .HostConfig.Tmpfs "/tmp"}}' "$id_value")"
  require_tmpfs_tokens "$tmp_data" rw noexec nosuid nodev size=536870912 uid=70 gid=70 mode=0700
  require_tmpfs_tokens "$tmp_socket" rw noexec nosuid nodev size=16777216 uid=70 gid=70 mode=03775
  require_tmpfs_tokens "$tmp_temp" rw noexec nosuid nodev size=67108864 uid=0 gid=0 mode=01777
  [[ "$(docker_inspect_value '{{len .Mounts}}' "$id_value")" == "0" ]] \
    || die "disposable Docker API mount list contains an unexpected volume or bind"
  api_mounts="$(docker_inspect_value '{{range .Mounts}}{{.Type}}|{{.Destination}}|{{.RW}}{{"\n"}}{{end}}' "$id_value")"
  [[ -z "$api_mounts" ]] || die "disposable Docker API mount list was unexpectedly nonempty"
  [[ "$(docker_inspect_value '{{.State.Status}}' "$id_value")" == "running" ]] || die "disposable container is not running"
  actual="$(docker exec "$id_value" sh -c 'tr -d "\n" </proc/1/comm' 2>/dev/null)" || die "could not inspect disposable PID 1"
  [[ "$actual" == "postgres" ]] || die "disposable PID 1 is not final postgres"
  runtime_mounts="$(
    docker exec "$id_value" awk '
      $5 == "/tmp" || $5 == "/run/postgresql" || $5 == "/var/lib/postgresql/data" {
        for (i = 6; i <= NF; i++) {
          if ($i == "-") {
            print $(i + 1) "|" $5
            found++
            break
          }
        }
      }
      END { if (found != 3) exit 71 }
    ' /proc/self/mountinfo 2>/dev/null | LC_ALL=C sort
  )" || die "could not prove all three disposable runtime tmpfs mounts"
  [[ "$runtime_mounts" == $'tmpfs|/run/postgresql\ntmpfs|/tmp\ntmpfs|/var/lib/postgresql/data' ]] \
    || die "disposable runtime mount types or paths mismatch"
  runtime_sql="BEGIN TRANSACTION READ ONLY; SET LOCAL statement_timeout='10s'; SET LOCAL lock_timeout='5s'; SELECT current_setting('listen_addresses'), current_setting('unix_socket_directories'); COMMIT;"
  runtime_settings="$(disposable_psql_capture "$id_value" "$database" "b0_${RUN_SUFFIX}_${role}_runtime" "$runtime_sql")" \
    || die "could not verify disposable listener settings"
  [[ "$runtime_settings" == "|${PG_SOCKET}" ]] || die "disposable listener settings are not socket-only"
  write_new_lines "$evidence_file" \
    "container_id=${id_value}" \
    "container_name=${expected_name}" \
    "role=${role}" \
    "image_id=${POSTGRES_IMAGE_ID}" \
    "platform=linux/amd64" \
    "readonly_root=true" \
    "user=70:70" \
    "cap_drop=ALL" \
    "no_new_privileges=true" \
    "network=none" \
    "published_ports=0" \
    "memory=1073741824" \
    "memory_swap=1073741824" \
    "memory_swappiness_override=none" \
    "swap_disabled_by_memory_swap_equal_memory=true" \
    "pids_limit=256" \
    "nano_cpus=1000000000" \
    "core_limit=0:0" \
    "restart_count=0" \
    "pid1=postgres" \
    "docker_api_volume_or_bind_mounts=0" \
    "runtime_mounts=3_expected_tmpfs_only" \
    "runtime_tmpfs_paths=/run/postgresql,/tmp,/var/lib/postgresql/data" \
    "listen_addresses=empty" \
    "socket=${PG_SOCKET}"
}

disposable_psql_capture() {
  local id_value="$1"
  local database="$2"
  local app="$3"
  local sql="$4"
  require_regex "$id_value" '^[a-f0-9]{64}$' "disposable container ID"
  require_regex "$database" '^[a-z][a-z0-9_]{1,62}$' "disposable database name"
  require_regex "$app" '^[a-z0-9_]{1,63}$' "disposable PostgreSQL application name"
  docker exec \
    --env "PGAPPNAME=${app}" \
    --env 'PGOPTIONS=-c default_transaction_read_only=on -c statement_timeout=30000 -c lock_timeout=5000' \
    "$id_value" \
    psql --no-psqlrc --no-password --set=ON_ERROR_STOP=1 --quiet --tuples-only --no-align --field-separator='|' \
      --host="$PG_SOCKET" --port="$PG_PORT" --username="$PG_USER" --dbname="$database" \
      --command="$sql" 2>/dev/null
}

assert_disposable_app_absent() {
  local id_value="$1"
  local database="$2"
  local target_app="$3"
  local attempt result sql probe_app probe_tag
  require_regex "$id_value" '^[a-f0-9]{64}$' "disposable container ID"
  require_regex "$database" '^[a-z][a-z0-9_]{1,62}$' "disposable probe database name"
  require_regex "$target_app" '^[a-z0-9_]{1,63}$' "disposable dump application name"
  probe_tag="$(printf '%s' "$target_app" | sha256sum | awk '{print substr($1,1,8)}')"
  require_regex "$probe_tag" '^[a-f0-9]{8}$' "disposable dump-session probe tag"
  for attempt in $(seq -w 1 30); do
    probe_app="b0_${RUN_SUFFIX}_gone_${probe_tag}_${attempt}"
    sql="BEGIN TRANSACTION READ ONLY; SET LOCAL statement_timeout='10s'; SET LOCAL lock_timeout='5s'; SELECT count(*) FROM pg_stat_activity WHERE application_name='${target_app}' AND pid <> pg_backend_pid(); COMMIT;"
    result="$(disposable_psql_capture "$id_value" "$database" "$probe_app" "$sql")" \
      || die "could not prove disposable schema-only dump session termination"
    [[ "$result" == "0" ]] && return 0
    sleep 1
  done
  die "run-owned disposable schema-only dump session remains"
}

# Hash the complete plain schema dump without retaining or executing its SQL.
# One run-unique --restrict-key makes PG16.14 output deterministic while every
# SQL/comment byte and its order remain covered by the SHA-256.
capture_schema_only_hash() {
  local scope="$1"
  local container_id="$2"
  local database="$3"
  local probe_database="$4"
  local app="$5"
  local output="$6"
  local error_output="$7"
  local stream_hash status_value
  local -a pipeline_status=()
  require_run_owned_target "$output"
  require_run_owned_target "$error_output"
  require_regex "$container_id" '^[a-f0-9]{64}$' "schema-only dump container ID"
  require_regex "$database" '^[a-z][a-z0-9_]{1,62}$' "schema-only dump database name"
  require_regex "$probe_database" '^[a-z][a-z0-9_]{1,62}$' "schema-only probe database name"
  require_regex "$app" '^[a-z0-9_]{1,63}$' "schema-only PostgreSQL application name"
  require_regex "$SCHEMA_RESTRICT_KEY" '^[A-Za-z0-9]{14}$' "schema-only pg_dump restrict key"
  [[ ! -e "$output" && ! -L "$output" && ! -e "$error_output" && ! -L "$error_output" ]] \
    || die "schema-only hash evidence path exists"
  if [[ "$scope" == "source" ]]; then
    [[ "$container_id" == "$LIVE_DB_ID" && "$database" == "$PG_DATABASE" && "$probe_database" == "$PG_DATABASE" ]] \
      || die "source schema-only dump endpoint mismatch"
  elif [[ "$scope" != "disposable" ]]; then
    die "invalid schema-only dump scope"
  fi
  set +e
  docker exec \
    --env "PGAPPNAME=${app}" \
    --env 'PSQLRC=/dev/null' \
    --env 'PGOPTIONS=-c default_transaction_read_only=on -c statement_timeout=240000 -c lock_timeout=5000' \
    "$container_id" \
    busybox timeout -s TERM -k 30 300 \
    pg_dump --host="$PG_SOCKET" --port="$PG_PORT" --username="$PG_USER" --dbname="$database" \
      --schema-only --format=plain --no-owner --no-privileges --no-password --quote-all-identifiers \
      --lock-wait-timeout=5000 --restrict-key="$SCHEMA_RESTRICT_KEY" \
      2>"$error_output" \
    | sha256sum >"$output"
  pipeline_status=("${PIPESTATUS[@]}")
  set -e
  if [[ "$scope" == "source" ]]; then
    assert_dump_app_absent "$app"
  else
    assert_disposable_app_absent "$container_id" "$probe_database" "$app"
  fi
  [[ "${#pipeline_status[@]}" == "2" ]] || die "schema-only hash pipeline status was not captured"
  for status_value in "${pipeline_status[@]}"; do
    [[ "$status_value" == "0" ]] || die "schema-only pg_dump/hash pipeline failed; raw stderr was retained without being printed"
  done
  [[ "$(mode_of "$output")" == "600" && "$(owner_of "$output")" == "${EXPECTED_UID}:${EXPECTED_GID}" ]] \
    || die "schema-only hash evidence protection mismatch"
  [[ "$(mode_of "$error_output")" == "600" && "$(owner_of "$error_output")" == "${EXPECTED_UID}:${EXPECTED_GID}" ]] \
    || die "schema-only raw stderr protection mismatch"
  stream_hash="$(read_stream_sha256 "$output")"
  require_regex "$stream_hash" '^[a-f0-9]{64}$' "schema-only canonical SHA-256"
}

emit_empty_database_facts_sql() {
  cat <<'SQL'
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='120s';
SET LOCAL lock_timeout='5s';
WITH facts(label,value) AS (
  SELECT 'public_base_tables', count(*)::text FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE'
  UNION ALL SELECT 'public_relations', count(*)::text FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public'
  UNION ALL SELECT 'public_routines', count(*)::text FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public'
  UNION ALL SELECT 'public_types', count(*)::text FROM pg_type t JOIN pg_namespace n ON n.oid=t.typnamespace WHERE n.nspname='public'
  UNION ALL SELECT 'dumpable_non_system_schemas', COALESCE(string_agg(nspname,',' ORDER BY nspname),'')
    FROM pg_namespace WHERE nspname <> 'information_schema' AND nspname !~ '^pg_'
  UNION ALL SELECT 'extensions', COALESCE(string_agg(extname || '|' || extversion,',' ORDER BY extname),'') FROM pg_extension
  UNION ALL SELECT 'large_objects', count(*)::text FROM pg_largeobject_metadata
  UNION ALL SELECT 'event_triggers', count(*)::text FROM pg_event_trigger
  UNION ALL SELECT 'foreign_servers', count(*)::text FROM pg_foreign_server
  UNION ALL SELECT 'user_mappings', count(*)::text FROM pg_user_mapping
  UNION ALL SELECT 'publications', count(*)::text FROM pg_publication
  UNION ALL SELECT 'subscriptions', count(*)::text FROM pg_subscription
  UNION ALL SELECT 'default_acls', count(*)::text FROM pg_default_acl
  UNION ALL SELECT 'database_role_settings', count(*)::text FROM pg_db_role_setting
    WHERE setdatabase=(SELECT oid FROM pg_database WHERE datname=current_database())
)
SELECT label, value FROM facts ORDER BY label;
COMMIT;
SQL
}

prove_empty_disposable_database() {
  local id_value="$1"
  local database="$2"
  local role="$3"
  local directory="$4"
  local target_hash_file="${directory}/empty-target-schema-dump.sha256"
  local template_hash_file="${directory}/empty-template1-schema-dump.sha256"
  local facts_file="${directory}/empty-database-facts.tsv"
  local target_hash template_hash
  require_run_owned_target "$directory"
  require_regex "$role" '^(primary|verifier)$' "empty-database proof role"
  capture_schema_only_hash "disposable" "$id_value" "$database" "$database" \
    "b0_${RUN_SUFFIX}_${role}_empty_target" "$target_hash_file" "${directory}/empty-target-schema-dump.stderr.raw"
  capture_schema_only_hash "disposable" "$id_value" "template1" "$database" \
    "b0_${RUN_SUFFIX}_${role}_empty_template" "$template_hash_file" "${directory}/empty-template1-schema-dump.stderr.raw"
  cmp -s "$target_hash_file" "$template_hash_file" \
    || die "disposable target schema differs from its fresh template1 baseline"
  emit_empty_database_facts_sql | disposable_psql_file "$id_value" "$database" \
    "b0_${RUN_SUFFIX}_${role}_empty_facts" "$facts_file" "${directory}/empty-database-facts.stderr.raw"
  require_line "$facts_file" "public_base_tables|0"
  require_line "$facts_file" "public_relations|0"
  require_line "$facts_file" "public_routines|0"
  require_line "$facts_file" "public_types|0"
  require_line "$facts_file" "dumpable_non_system_schemas|public"
  require_line "$facts_file" "extensions|plpgsql|1.0"
  require_line "$facts_file" "large_objects|0"
  require_line "$facts_file" "event_triggers|0"
  require_line "$facts_file" "foreign_servers|0"
  require_line "$facts_file" "user_mappings|0"
  require_line "$facts_file" "publications|0"
  require_line "$facts_file" "subscriptions|0"
  require_line "$facts_file" "default_acls|0"
  require_line "$facts_file" "database_role_settings|0"
  [[ "$(wc -l < "$facts_file" | tr -d '[:space:]')" == "14" ]] || die "empty-database fact cardinality mismatch"
  target_hash="$(read_stream_sha256 "$target_hash_file")"
  template_hash="$(read_stream_sha256 "$template_hash_file")"
  [[ "$target_hash" == "$template_hash" ]] || die "empty target and template1 schema hashes differ"
  write_new_lines "${directory}/empty-database.safe" \
    "target_database=${database}" \
    "public_object_counts=zero" \
    "dumpable_non_system_schemas=public_only" \
    "extensions=plpgsql_1.0_only" \
    "schema_only_dump_matches_fresh_template1=true" \
    "schema_only_dump_sha256=${target_hash}" \
    "schema_only_sql_retained=false" \
    "schema_only_sql_executed=false"
}

wait_for_final_disposable() {
  local id_value="$1"
  local database="$2"
  local role="$3"
  local attempt comm ready result app sql
  for attempt in $(seq -w 1 120); do
    [[ "$(docker_inspect_value '{{.State.Running}}' "$id_value" || true)" == "true" ]] || {
      sleep 1
      continue
    }
    [[ "$(docker_inspect_value '{{.RestartCount}}' "$id_value" || true)" == "0" ]] || die "disposable container restarted during initialization"
    comm="$(docker exec "$id_value" sh -c 'tr -d "\n" </proc/1/comm' 2>/dev/null || true)"
    [[ "$comm" == "postgres" ]] || {
      sleep 1
      continue
    }
    ready=0
    docker exec "$id_value" pg_isready --host="$PG_SOCKET" --port="$PG_PORT" --username="$PG_USER" --dbname="$database" \
      >/dev/null 2>&1 && ready=1
    [[ "$ready" == "1" ]] || {
      sleep 1
      continue
    }
    app="b0_${RUN_SUFFIX}_${role}_ready_${attempt}"
    sql="BEGIN TRANSACTION READ ONLY; SET LOCAL statement_timeout='10s'; SET LOCAL lock_timeout='5s'; SELECT current_database(), current_user, current_setting('server_version'), pg_encoding_to_char(encoding), datcollate, datctype, datlocprovider, (SELECT count(*) FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE'), (SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public'), (SELECT count(*) FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public'), (SELECT count(*) FROM pg_type t JOIN pg_namespace n ON n.oid=t.typnamespace WHERE n.nspname='public'), (SELECT string_agg(nspname,',' ORDER BY nspname) FROM pg_namespace WHERE nspname <> 'information_schema' AND nspname !~ '^pg_'), current_setting('listen_addresses'), current_setting('unix_socket_directories') FROM pg_database WHERE datname=current_database(); COMMIT;"
    result="$(disposable_psql_capture "$id_value" "$database" "$app" "$sql" || true)"
    if [[ "$result" == "${database}|${PG_USER}|${EXPECTED_PG_VERSION}|${EXPECTED_DB_ENCODING}|${EXPECTED_DB_COLLATE}|${EXPECTED_DB_CTYPE}|${EXPECTED_LOCALE_PROVIDER}|0|0|0|0|public||${PG_SOCKET}" ]]; then
      return 0
    fi
    sleep 1
  done
  die "disposable database did not reach the final empty pinned state"
}

capture_global_volumes() {
  local output="$1"
  local error_output="$2"
  require_run_owned_target "$output"
  require_run_owned_target "$error_output"
  [[ ! -e "$output" && ! -L "$output" && ! -e "$error_output" && ! -L "$error_output" ]] || die "volume evidence path exists"
  docker volume ls --format '{{.Name}}' 2>"$error_output" | LC_ALL=C sort >"$output" \
    || die "could not capture Docker volume inventory"
}

start_disposable() {
  local role="$1"
  local name="$2"
  local database="$3"
  local directory="$4"
  local cidfile="${directory}/container.cid"
  local stdout_file="${directory}/docker-run.stdout.safe"
  local stderr_file="${directory}/docker-run.stderr.raw"
  local -a command
  local rc captured_id="" cid_candidate="" stdout_candidate="" capture_consistent=0 existing_name_ids
  require_run_owned_target "$directory"
  require_run_owned_target "$cidfile"
  require_run_owned_target "$stdout_file"
  require_run_owned_target "$stderr_file"
  require_regex "$name" '^saboos-staff-b0-restore-(primary|verifier)-[a-f0-9]{12}$' "disposable container name"
  if [[ "$role" == "primary" ]]; then
    require_regex "$database" '^saboos_b0p_[a-f0-9]{12}$' "primary disposable database name"
  elif [[ "$role" == "verifier" ]]; then
    require_regex "$database" '^saboos_b0v_[a-f0-9]{12}$' "verifier disposable database name"
  else
    die "invalid disposable restore role"
  fi
  existing_name_ids="$(docker ps -aq --no-trunc --filter "name=^/${name}$")" \
    || die "could not query disposable container-name availability"
  [[ -z "$existing_name_ids" ]] || die "disposable container name already exists"
  [[ ! -e "$cidfile" && ! -L "$cidfile" && ! -e "$stdout_file" && ! -L "$stdout_file" \
    && ! -e "$stderr_file" && ! -L "$stderr_file" ]] || die "disposable launch evidence path exists"
  command=(
    docker run --rm --detach --pull=never --platform=linux/amd64
    --cidfile "$cidfile"
    --name "$name"
    --label "com.saboos.b0.run=${RUN_ID}"
    --label "com.saboos.b0.scope=${B0_SCOPE_LABEL}"
    --label "com.saboos.b0.role=${role}"
    --read-only
    --user 70:70
    --cap-drop ALL
    --security-opt no-new-privileges:true
    --network none
    --memory 1g
    --memory-swap 1g
    --pids-limit 256
    --cpus 1.0
    --ulimit core=0:0
    --tmpfs /var/lib/postgresql/data:rw,noexec,nosuid,nodev,size=536870912,uid=70,gid=70,mode=0700
    --tmpfs /var/run/postgresql:rw,noexec,nosuid,nodev,size=16777216,uid=70,gid=70,mode=03775
    --tmpfs /tmp:rw,noexec,nosuid,nodev,size=67108864,uid=0,gid=0,mode=01777
    --env "POSTGRES_USER=${PG_USER}"
    --env "POSTGRES_DB=${database}"
    --env POSTGRES_HOST_AUTH_METHOD=trust
    --env PGDATA=/var/lib/postgresql/data
    --env LANG=en_US.utf8
    --env LC_ALL=en_US.utf8
    --env 'POSTGRES_INITDB_ARGS=--encoding=UTF8 --locale-provider=libc --lc-collate=en_US.utf8 --lc-ctype=en_US.utf8'
    "$POSTGRES_IMAGE_ID"
    postgres -c 'listen_addresses=' -c "unix_socket_directories=${PG_SOCKET}"
  )
  if [[ "$role" == "primary" ]]; then
    PRIMARY_LAUNCH_ATTEMPTED=1
  else
    VERIFIER_LAUNCH_ATTEMPTED=1
  fi
  set +e
  "${command[@]}" >"$stdout_file" 2>"$stderr_file"
  rc=$?
  set -e
  if [[ -f "$cidfile" && ! -L "$cidfile" ]]; then
    cid_candidate="$(tr -d '[:space:]' < "$cidfile")"
  fi
  if [[ -f "$stdout_file" && ! -L "$stdout_file" ]]; then
    stdout_candidate="$(tr -d '[:space:]' < "$stdout_file")"
  fi
  if [[ "$cid_candidate" =~ ^[a-f0-9]{64}$ && "$stdout_candidate" =~ ^[a-f0-9]{64}$ \
    && "$cid_candidate" == "$stdout_candidate" ]]; then
    captured_id="$cid_candidate"
    capture_consistent=1
  fi
  if [[ "$captured_id" =~ ^[a-f0-9]{64}$ ]]; then
    if [[ "$role" == "primary" ]]; then
      PRIMARY_ID="$captured_id"
    else
      VERIFIER_ID="$captured_id"
    fi
  fi
  [[ "$rc" == "0" ]] || die "disposable container launch failed; raw stderr was retained without being printed"
  [[ "$capture_consistent" == "1" ]] || die "docker run ID evidence was not a consistent full-ID pair"
  require_regex "$captured_id" '^[a-f0-9]{64}$' "captured disposable container ID"
}

restore_dump() {
  local id_value="$1"
  local database="$2"
  local role="$3"
  local directory="$4"
  local dump_file="$5"
  local app="b0_${RUN_SUFFIX}_${role}_restore"
  local stdout_file="${directory}/pg-restore.stdout.raw"
  local stderr_file="${directory}/pg-restore.stderr.raw"
  local rc result sql
  require_run_owned_target "$directory"
  require_run_owned_target "$dump_file"
  require_run_owned_target "$stdout_file"
  require_run_owned_target "$stderr_file"
  [[ ! -e "$stdout_file" && ! -L "$stdout_file" && ! -e "$stderr_file" && ! -L "$stderr_file" ]] \
    || die "restore evidence path already exists"
  set +e
  docker exec -i \
    --env "PGAPPNAME=${app}" \
    --env 'PGOPTIONS=-c statement_timeout=600000 -c lock_timeout=5000' \
    "$id_value" \
    busybox timeout -s TERM -k 30 600 \
    pg_restore --host="$PG_SOCKET" --port="$PG_PORT" --username="$PG_USER" --dbname="$database" \
      --single-transaction --exit-on-error --no-owner --no-privileges --no-password \
      <"$dump_file" >"$stdout_file" 2>"$stderr_file"
  rc=$?
  set -e
  sql="BEGIN TRANSACTION READ ONLY; SET LOCAL statement_timeout='10s'; SELECT count(*) FROM pg_stat_activity WHERE application_name='${app}' AND pid <> pg_backend_pid(); COMMIT;"
  result="$(disposable_psql_capture "$id_value" "$database" "b0_${RUN_SUFFIX}_${role}_restoregone" "$sql")" \
    || die "could not prove restore session termination"
  [[ "$result" == "0" ]] || die "run-owned restore database session remains"
  [[ "$rc" == "0" ]] || die "disposable pg_restore failed; raw stderr was retained without being printed"
}

capture_restored_evidence() {
  local id_value="$1"
  local database="$2"
  local role="$3"
  local directory="$4"
  emit_schema_catalog_sql | disposable_psql_file "$id_value" "$database" "b0_${RUN_SUFFIX}_${role}_schema" \
    "${directory}/schema-catalog.tsv" "${directory}/schema.stderr.raw"
  capture_schema_only_hash "disposable" "$id_value" "$database" "$database" \
    "b0_${RUN_SUFFIX}_${role}_schemadump" "${directory}/schema-dump.sha256" "${directory}/schema-dump.stderr.raw"
  emit_migration_fingerprint_sql | disposable_psql_file "$id_value" "$database" "b0_${RUN_SUFFIX}_${role}_migrations" \
    "${directory}/migrations.tsv" "${directory}/migrations.stderr.raw"
  emit_dumpable_schema_inventory_sql | disposable_psql_file "$id_value" "$database" "b0_${RUN_SUFFIX}_${role}_schemas" \
    "${directory}/dumpable-schemas.tsv" "${directory}/dumpable-schemas.stderr.raw"
  emit_table_counts_sql | disposable_psql_file "$id_value" "$database" "b0_${RUN_SUFFIX}_${role}_counts" \
    "${directory}/table-counts.tsv" "${directory}/table-counts.stderr.raw"
  emit_logical_summary_sql | disposable_psql_file "$id_value" "$database" "b0_${RUN_SUFFIX}_${role}_summary" \
    "${directory}/logical-summary.tsv" "${directory}/logical-summary.stderr.raw"
  emit_audit_segments_sql | disposable_psql_file "$id_value" "$database" "b0_${RUN_SUFFIX}_${role}_audit" \
    "${directory}/audit-segments.tsv" "${directory}/audit-segments.stderr.raw"
  emit_sequence_values_sql | disposable_psql_file "$id_value" "$database" "b0_${RUN_SUFFIX}_${role}_sequences" \
    "${directory}/sequence-values.tsv" "${directory}/sequence-values.stderr.raw"
}

validate_restored_evidence() {
  local directory="$1"
  local table_lines migration_lines postbreak
  table_lines="$(wc -l < "${directory}/table-counts.tsv" | tr -d '[:space:]')"
  migration_lines="$(wc -l < "${directory}/migrations.tsv" | tr -d '[:space:]')"
  [[ "$table_lines" == "$EXPECTED_PUBLIC_TABLES" ]] || die "restored all-table count cardinality mismatch"
  [[ "$migration_lines" == "$EXPECTED_MIGRATIONS_TOTAL" ]] || die "restored migration fingerprint cardinality mismatch"
  [[ "$(wc -l < "${directory}/dumpable-schemas.tsv" | tr -d '[:space:]')" == "1" ]] \
    || die "restored dumpable non-system schema set is not public-only"
  require_line "${directory}/dumpable-schemas.tsv" "public"
  validate_pinned_logical_summary "${directory}/logical-summary.tsv"
  require_line "${directory}/audit-segments.tsv" "unchained_prefix|${EXPECTED_AUDIT_PREFIX}"
  require_line "${directory}/audit-segments.tsv" "non_null_before_first_break|${EXPECTED_AUDIT_PREBREAK_NON_NULL}"
  require_line "${directory}/audit-segments.tsv" "first_break_null_run|${EXPECTED_AUDIT_BREAK_NULL_RUN}"
  require_line "${directory}/audit-segments.tsv" "null_after_first_resume|0"
  require_line "${directory}/audit-segments.tsv" "first_break_id|${EXPECTED_AUDIT_FIRST_BREAK}"
  postbreak="$(awk -F'|' '$1=="non_null_after_first_break" {print $2}' "${directory}/audit-segments.tsv")"
  require_regex "$postbreak" '^[0-9]+$' "post-break audit count"
  (( postbreak >= EXPECTED_AUDIT_POSTBREAK_MIN )) || die "restored audit post-break segment predates the observed baseline"
  cmp -s "${PRIMARY_DIR}/source-pre-schema-catalog.tsv" "${directory}/schema-catalog.tsv" \
    || die "restored logical schema fingerprint differs from the source snapshot"
  cmp -s "${PRIMARY_DIR}/source-pre-schema-dump.sha256" "${directory}/schema-dump.sha256" \
    || die "restored complete schema-only dump hash differs from the source snapshot"
  cmp -s "${PRIMARY_DIR}/source-pre-migrations.tsv" "${directory}/migrations.tsv" \
    || die "restored migration name/checksum fingerprint differs from the source snapshot"
  cmp -s "${PRIMARY_DIR}/source-pre-logical-summary.tsv" "${directory}/logical-summary.tsv" \
    || die "restored logical summary differs from the source snapshot"
  cmp -s "${PRIMARY_DIR}/source-pre-dumpable-schemas.tsv" "${directory}/dumpable-schemas.tsv" \
    || die "restored dumpable schema inventory differs from the source snapshot"
}

verify_no_run_residue() {
  local role="$1"
  local id_value="$2"
  local name="$3"
  local volumes_before="$4"
  local directory="$5"
  local volumes_after="${directory}/volumes-after.txt"
  local volumes_err="${directory}/volumes-after.stderr.raw"
  local labeled_containers labeled_volumes
  if docker inspect --type container "$id_value" >/dev/null 2>&1; then
    die "captured disposable container ID remains after stop"
  fi
  prove_container_absent "$id_value" "$name" || die "captured ID/name/run-label absence was not proven"
  labeled_containers="$(docker ps -aq --no-trunc --filter "label=com.saboos.b0.run=${RUN_ID}")" \
    || die "could not query run-labeled container residue"
  [[ -z "$labeled_containers" ]] || die "run-labeled container residue remains"
  labeled_volumes="$(docker volume ls -q --filter "label=com.saboos.b0.run=${RUN_ID}")" \
    || die "could not query run-labeled Docker volume residue"
  [[ -z "$labeled_volumes" ]] || die "run-labeled Docker volume residue exists"
  capture_global_volumes "$volumes_after" "$volumes_err"
  cmp -s "$volumes_before" "$volumes_after" || die "Docker volume inventory changed during disposable restore; no volume was deleted"
  write_new_lines "${directory}/cleanup.safe" \
    "role=${role}" \
    "captured_id_absent=true" \
    "exact_name_absent=true" \
    "run_label_absent=true" \
    "run_labeled_volumes_absent=true" \
    "global_volume_inventory_unchanged=true"
}

make_manifest() {
  local subtree="$1"
  local target="$2"
  require_run_owned_target "${RUN_DIR_IO}/${subtree}"
  require_run_owned_target "$target"
  [[ -d "${RUN_DIR_IO}/${subtree}" ]] || die "manifest subtree is absent"
  [[ ! -e "$target" && ! -L "$target" ]] || die "manifest path exists"
  (
    cd "$RUN_DIR_IO"
    find "$subtree" -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum
  ) >"$target"
  [[ "$(mode_of "$target")" == "600" ]] || die "manifest mode is not 0600"
}

assert_evidence_protection() {
  local subtree="$1"
  local path inventory
  require_run_owned_target "$subtree"
  [[ -d "$subtree" && ! -L "$subtree" ]] || die "evidence subtree boundary is invalid"
  [[ "$(owner_of "$subtree")" == "${EXPECTED_UID}:${EXPECTED_GID}" ]] || die "evidence subtree owner mismatch"
  [[ "$(mode_of "$subtree")" == "700" ]] || die "evidence subtree mode is not 0700"
  inventory="${subtree}/protection-inventory.paths0"
  [[ ! -e "$inventory" && ! -L "$inventory" ]] || die "evidence protection inventory path exists"
  find "$subtree" -mindepth 1 ! -path "$inventory" -print0 >"$inventory" \
    || die "evidence protection traversal failed"
  [[ "$(owner_of "$inventory")" == "${EXPECTED_UID}:${EXPECTED_GID}" ]] || die "evidence protection inventory owner mismatch"
  [[ "$(mode_of "$inventory")" == "600" ]] || die "evidence protection inventory mode is not 0600"
  while IFS= read -r -d '' path; do
    [[ ! -L "$path" ]] || die "symlink found in run-owned evidence"
    [[ "$(owner_of "$path")" == "${EXPECTED_UID}:${EXPECTED_GID}" ]] || die "run-owned evidence owner mismatch"
    if [[ -d "$path" ]]; then
      [[ "$(mode_of "$path")" == "700" ]] || die "run-owned evidence directory mode is not 0700"
    elif [[ -f "$path" ]]; then
      [[ "$(mode_of "$path")" == "600" ]] || die "run-owned evidence file mode is not 0600"
    else
      die "unexpected non-file object in run-owned evidence"
    fi
  done <"$inventory"
}

# Preflight performs no filesystem, Docker, or database mutation. The exclusive
# advisory lock is taken on the already-existing directory file descriptor;
# no replacement lock file or directory is created.
random_hex="$(od -An -N6 -tx1 /dev/urandom | tr -d '[:space:]')"
require_regex "$random_hex" '^[a-f0-9]{12}$' "random run suffix"
RUN_SUFFIX="$random_hex"
SCHEMA_RESTRICT_KEY="b0${RUN_SUFFIX}"
require_regex "$SCHEMA_RESTRICT_KEY" '^[A-Za-z0-9]{14}$' "schema-only pg_dump restrict key"
readonly SCHEMA_RESTRICT_KEY
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)-${RUN_SUFFIX}"
require_regex "$RUN_ID" '^[0-9]{8}T[0-9]{6}Z-[a-f0-9]{12}$' "run ID"
RUN_DIR="${BACKUP_PARENT}/b0-logical-restore-${RUN_ID}"
RUN_DIR_BASENAME="${RUN_DIR##*/}"
require_regex "$RUN_DIR_BASENAME" '^b0-logical-restore-[0-9]{8}T[0-9]{6}Z-[a-f0-9]{12}$' "run directory basename"
PRIMARY_CANONICAL_DIR="${RUN_DIR}/primary"
VERIFIER_CANONICAL_DIR="${RUN_DIR}/verifier"
PRIMARY_NAME="saboos-staff-b0-restore-primary-${RUN_SUFFIX}"
VERIFIER_NAME="saboos-staff-b0-restore-verifier-${RUN_SUFFIX}"
PRIMARY_DB="saboos_b0p_${RUN_SUFFIX}"
VERIFIER_DB="saboos_b0v_${RUN_SUFFIX}"
require_regex "$PRIMARY_NAME" '^saboos-staff-b0-restore-primary-[a-f0-9]{12}$' "primary container name"
require_regex "$VERIFIER_NAME" '^saboos-staff-b0-restore-verifier-[a-f0-9]{12}$' "verifier container name"
require_regex "$PRIMARY_DB" '^saboos_b0p_[a-f0-9]{12}$' "primary database name"
require_regex "$VERIFIER_DB" '^saboos_b0v_[a-f0-9]{12}$' "verifier database name"

assert_preflight
exec {B0_LOCK_FD}<"$BACKUP_PARENT"
BACKUP_PARENT_IO="/proc/self/fd/${B0_LOCK_FD}"
[[ -d "$BACKUP_PARENT_IO" ]] || die "retained Staff backup-parent descriptor is not a directory"
[[ "$(stat -Lc '%d:%i' -- "$BACKUP_PARENT_IO")" == "$BACKUP_PARENT_DEVICE_INODE" ]] \
  || die "retained Staff backup-parent descriptor identity drifted"
[[ "$(stat -Lc '%u:%g' -- "$BACKUP_PARENT_IO")" == "$BACKUP_PARENT_OWNER" ]] \
  || die "retained Staff backup-parent descriptor owner drifted"
[[ "$(stat -Lc '%a' -- "$BACKUP_PARENT_IO")" == "$EXPECTED_BACKUP_PARENT_MODE" ]] \
  || die "retained Staff backup-parent descriptor mode drifted"
[[ "$(realpath -e -- "$BACKUP_PARENT_IO")" == "$BACKUP_PARENT_RESOLVED" ]] \
  || die "retained Staff backup-parent descriptor resolution drifted"
flock -n "$B0_LOCK_FD" || die "another cooperating B0 run holds the backup-parent lock"

# Recheck every identity and concurrency pin immediately before the first
# mutation. Exact prior absence includes both lstat-visible and symlink cases.
assert_compose_pin
assert_image_pin
assert_live_db_pin
assert_health_endpoint
assert_no_b0_containers
assert_no_host_deploy_or_migration
assert_source_identity "premutation"
assert_source_quiescent_for_b0 "premutation"
[[ "$(owner_of "$BACKUP_PARENT")" == "$BACKUP_PARENT_OWNER" ]] || die "Staff backup parent owner changed after preflight"
[[ "$(mode_of "$BACKUP_PARENT")" == "$EXPECTED_BACKUP_PARENT_MODE" ]] || die "Staff backup parent mode changed after preflight"
[[ "$(stat -c '%d:%i' -- "$BACKUP_PARENT")" == "$BACKUP_PARENT_DEVICE_INODE" ]] || die "Staff backup parent identity changed after preflight"
[[ "$(realpath -e -- "$BACKUP_PARENT")" == "$BACKUP_PARENT_RESOLVED" ]] || die "Staff backup parent resolution changed after preflight"
[[ "$(stat -Lc '%d:%i' -- "$BACKUP_PARENT_IO")" == "$BACKUP_PARENT_DEVICE_INODE" ]] || die "retained backup-parent descriptor changed"
[[ ! -e "$RUN_DIR" && ! -L "$RUN_DIR" ]] || die "unique B0 run directory already exists"
RUN_CREATE_PATH="${BACKUP_PARENT_IO}/${RUN_DIR_BASENAME}"
[[ ! -e "$RUN_CREATE_PATH" && ! -L "$RUN_CREATE_PATH" ]] || die "unique B0 run directory exists through the retained parent descriptor"
[[ ! -e "/proc/$$/fd/${RUN_DIR_FD}" && ! -L "/proc/$$/fd/${RUN_DIR_FD}" ]] \
  || die "reserved run-directory file descriptor is already open"
ABORT_REASON="create_run_directory"
mkdir --mode=0700 -- "$RUN_CREATE_PATH"
# Keep the newly created directory open for the entire run. Every run-owned
# read/write path below is rooted at this descriptor, so a rename or pathname
# substitution in the group-writable parent cannot redirect later I/O.
exec 9<"$RUN_CREATE_PATH"
RUN_DIR_IO="/proc/self/fd/${RUN_DIR_FD}"
RUN_DIR_DEVICE_INODE="$(stat -Lc '%d:%i' -- "$RUN_DIR_IO")"
RUN_DIR_OWNER="$(stat -Lc '%u:%g' -- "$RUN_DIR_IO")"
RUN_DIR_MODE="$(stat -Lc '%a' -- "$RUN_DIR_IO")"
RUN_DIR_RESOLVED="$(realpath -e -- "$RUN_DIR_IO")"
[[ -d "$RUN_DIR" && ! -L "$RUN_DIR" ]] || die "B0 run directory creation failed"
[[ "$RUN_DIR_OWNER" == "${EXPECTED_UID}:${EXPECTED_GID}" ]] || die "B0 run directory owner mismatch"
[[ "$RUN_DIR_MODE" == "700" ]] || die "B0 run directory mode mismatch"
[[ "$RUN_DIR_RESOLVED" == "$RUN_DIR" ]] || die "B0 run directory resolution mismatch"
require_regex "$RUN_DIR_DEVICE_INODE" '^[0-9]+:[0-9]+$' "B0 run directory device and inode"
[[ "$(stat -c '%d:%i' -- "$RUN_DIR")" == "$RUN_DIR_DEVICE_INODE" ]] || die "opened run-directory descriptor does not match the canonical path"
RUN_DIR_CREATED=1
require_run_dir_identity
PRIMARY_DIR="${RUN_DIR_IO}/primary"
VERIFIER_DIR="${RUN_DIR_IO}/verifier"
require_run_owned_target "$PRIMARY_DIR"
mkdir --mode=0700 -- "$PRIMARY_DIR"
require_run_owned_target "$VERIFIER_DIR"
mkdir --mode=0700 -- "$VERIFIER_DIR"
[[ "$(owner_of "$PRIMARY_DIR")" == "${EXPECTED_UID}:${EXPECTED_GID}" && "$(mode_of "$PRIMARY_DIR")" == "700" ]] \
  || die "primary evidence directory protection mismatch"
[[ "$(owner_of "$VERIFIER_DIR")" == "${EXPECTED_UID}:${EXPECTED_GID}" && "$(mode_of "$VERIFIER_DIR")" == "700" ]] \
  || die "verifier evidence directory protection mismatch"

write_new_lines "${PRIMARY_DIR}/scope.safe" \
  "proof=Staff database logical schema/data restore proven in an isolated disposable PostgreSQL 16.14 instance." \
  "not_proven=cluster roles, ownership, grants, authentication, physical recovery, or application recovery" \
  "restore_flags=single-transaction,exit-on-error,no-owner,no-privileges,no-password" \
  "schema_only_comparison=hash_only_with_run_unique_restrict_key; SQL neither retained nor executed" \
  "dumpable_non_system_schema_scope=public_only" \
  "live_database_writes=none" \
  "live_service_restarts=none" \
  "old_backup_deletions=none" \
  "docker_volume_mutations=none"
write_new_lines "${PRIMARY_DIR}/preflight.safe" \
  "run_id=${RUN_ID}" \
  "host=${EXPECTED_HOST}" \
  "operator=${EXPECTED_USER}" \
  "operator_uid_gid=${EXPECTED_UID}:${EXPECTED_GID}" \
  "backup_parent=${BACKUP_PARENT}" \
  "backup_parent_owner=${BACKUP_PARENT_OWNER}" \
  "backup_parent_mode=${EXPECTED_BACKUP_PARENT_MODE}" \
  "backup_parent_device_inode=${BACKUP_PARENT_DEVICE_INODE}" \
  "backup_parent_resolved=${BACKUP_PARENT_RESOLVED}" \
  "run_directory_owner=${RUN_DIR_OWNER}" \
  "run_directory_mode=${RUN_DIR_MODE}" \
  "run_directory_device_inode=${RUN_DIR_DEVICE_INODE}" \
  "run_directory_resolved=${RUN_DIR_RESOLVED}" \
  "compose_sha256=${EXPECTED_COMPOSE_SHA256}" \
  "live_db_container_id=${LIVE_DB_ID}" \
  "live_db_image_id=${POSTGRES_IMAGE_ID}" \
  "live_db_mount=${LIVE_VOLUME_NAME}|/var/lib/postgresql/data|true" \
  "source_database=${PG_DATABASE}" \
  "source_role=${PG_USER}" \
  "source_endpoint=unix_socket:${PG_SOCKET}:${PG_PORT}" \
  "source_primary=true" \
  "staff_health_http_status=200" \
  "concurrency_gate=clear"

ABORT_REASON="capture_source_pre_snapshot"
capture_source_evidence "pre"

assert_compose_pin
assert_live_db_pin
assert_health_endpoint
assert_no_b0_containers
assert_no_host_deploy_or_migration
assert_source_identity "predump"
assert_source_quiescent_for_b0 "predump"

readonly DUMP_PARTIAL="${PRIMARY_DIR}/saboos-staff-${RUN_ID}.dump.partial"
readonly DUMP_FINAL="${PRIMARY_DIR}/saboos-staff-${RUN_ID}.dump"
ABORT_REASON="capture_dump"
capture_dump "$DUMP_PARTIAL" "${PRIMARY_DIR}/pg-dump.stderr.raw"
generate_and_validate_toc "$DUMP_PARTIAL"

ABORT_REASON="capture_source_post_snapshot"
capture_source_evidence "post"
cmp -s "${PRIMARY_DIR}/source-pre-schema-catalog.tsv" "${PRIMARY_DIR}/source-post-schema-catalog.tsv" \
  || die "source schema catalog changed during backup"
cmp -s "${PRIMARY_DIR}/source-pre-schema-dump.sha256" "${PRIMARY_DIR}/source-post-schema-dump.sha256" \
  || die "source complete schema-only dump hash changed during backup"
cmp -s "${PRIMARY_DIR}/source-pre-migrations.tsv" "${PRIMARY_DIR}/source-post-migrations.tsv" \
  || die "source migration ledger changed during backup"
cmp -s "${PRIMARY_DIR}/source-pre-dumpable-schemas.tsv" "${PRIMARY_DIR}/source-post-dumpable-schemas.tsv" \
  || die "source dumpable schema inventory changed during backup"
cmp -s "${PRIMARY_DIR}/source-pre-logical-summary.tsv" "${PRIMARY_DIR}/source-post-logical-summary.tsv" \
  || die "source logical summary changed during backup"
SOURCE_SCHEMA_PRE_SHA256="$(sha256_of "${PRIMARY_DIR}/source-pre-schema-catalog.tsv")"
SOURCE_SCHEMA_POST_SHA256="$(sha256_of "${PRIMARY_DIR}/source-post-schema-catalog.tsv")"
SOURCE_SCHEMA_DUMP_PRE_SHA256="$(read_stream_sha256 "${PRIMARY_DIR}/source-pre-schema-dump.sha256")"
SOURCE_SCHEMA_DUMP_POST_SHA256="$(read_stream_sha256 "${PRIMARY_DIR}/source-post-schema-dump.sha256")"
SOURCE_MIGRATIONS_PRE_SHA256="$(sha256_of "${PRIMARY_DIR}/source-pre-migrations.tsv")"
SOURCE_MIGRATIONS_POST_SHA256="$(sha256_of "${PRIMARY_DIR}/source-post-migrations.tsv")"
SOURCE_SCHEMAS_PRE_SHA256="$(sha256_of "${PRIMARY_DIR}/source-pre-dumpable-schemas.tsv")"
SOURCE_SCHEMAS_POST_SHA256="$(sha256_of "${PRIMARY_DIR}/source-post-dumpable-schemas.tsv")"
SOURCE_SUMMARY_PRE_SHA256="$(sha256_of "${PRIMARY_DIR}/source-pre-logical-summary.tsv")"
SOURCE_SUMMARY_POST_SHA256="$(sha256_of "${PRIMARY_DIR}/source-post-logical-summary.tsv")"
for source_hash in \
  "$SOURCE_SCHEMA_PRE_SHA256" "$SOURCE_SCHEMA_POST_SHA256" \
  "$SOURCE_SCHEMA_DUMP_PRE_SHA256" "$SOURCE_SCHEMA_DUMP_POST_SHA256" \
  "$SOURCE_MIGRATIONS_PRE_SHA256" "$SOURCE_MIGRATIONS_POST_SHA256" \
  "$SOURCE_SCHEMAS_PRE_SHA256" "$SOURCE_SCHEMAS_POST_SHA256" \
  "$SOURCE_SUMMARY_PRE_SHA256" "$SOURCE_SUMMARY_POST_SHA256"; do
  require_regex "$source_hash" '^[a-f0-9]{64}$' "source-binding SHA-256"
done
write_new_lines "${PRIMARY_DIR}/source-binding.safe" \
  "schema_pre_sha256=${SOURCE_SCHEMA_PRE_SHA256}" \
  "schema_post_sha256=${SOURCE_SCHEMA_POST_SHA256}" \
  "schema_equal=true" \
  "complete_schema_dump_pre_sha256=${SOURCE_SCHEMA_DUMP_PRE_SHA256}" \
  "complete_schema_dump_post_sha256=${SOURCE_SCHEMA_DUMP_POST_SHA256}" \
  "complete_schema_dump_equal=true" \
  "migrations_pre_sha256=${SOURCE_MIGRATIONS_PRE_SHA256}" \
  "migrations_post_sha256=${SOURCE_MIGRATIONS_POST_SHA256}" \
  "migrations_equal=true" \
  "dumpable_schemas_pre_sha256=${SOURCE_SCHEMAS_PRE_SHA256}" \
  "dumpable_schemas_post_sha256=${SOURCE_SCHEMAS_POST_SHA256}" \
  "dumpable_schemas_equal=true" \
  "logical_summary_pre_sha256=${SOURCE_SUMMARY_PRE_SHA256}" \
  "logical_summary_post_sha256=${SOURCE_SUMMARY_POST_SHA256}" \
  "logical_summary_equal=true" \
  "pre_post_table_counts_are_nonbinding_drift_observations=true"

ABORT_REASON="finalize_dump"
finalize_dump "$DUMP_PARTIAL" "$DUMP_FINAL"
DUMP_SHA256="$(record_dump_hash "$DUMP_FINAL" "${PRIMARY_DIR}/dump.final.sha256" "")"
require_regex "$DUMP_SHA256" '^[a-f0-9]{64}$' "retained dump hash"

# Primary restore.
ABORT_REASON="start_primary_restore"
capture_global_volumes "${PRIMARY_DIR}/volumes-before.txt" "${PRIMARY_DIR}/volumes-before.stderr.raw"
start_disposable "primary" "$PRIMARY_NAME" "$PRIMARY_DB" "$PRIMARY_DIR"
wait_for_final_disposable "$PRIMARY_ID" "$PRIMARY_DB" "primary"
verify_disposable_insulation "$PRIMARY_ID" "$PRIMARY_DB" "primary" "$PRIMARY_NAME" "${PRIMARY_DIR}/container-insulation.safe"
ABORT_REASON="prove_primary_empty_target"
prove_empty_disposable_database "$PRIMARY_ID" "$PRIMARY_DB" "primary" "$PRIMARY_DIR"
record_dump_hash "$DUMP_FINAL" "${PRIMARY_DIR}/dump.pre-restore.sha256" "$DUMP_SHA256" >/dev/null
ABORT_REASON="restore_primary"
restore_dump "$PRIMARY_ID" "$PRIMARY_DB" "primary" "$PRIMARY_DIR" "$DUMP_FINAL"
record_dump_hash "$DUMP_FINAL" "${PRIMARY_DIR}/dump.post-restore.sha256" "$DUMP_SHA256" >/dev/null
ABORT_REASON="verify_primary_restore"
capture_restored_evidence "$PRIMARY_ID" "$PRIMARY_DB" "primary" "$PRIMARY_DIR"
validate_restored_evidence "$PRIMARY_DIR"
cleanup_owned_container "primary" "$PRIMARY_ID" "$PRIMARY_NAME" "${PRIMARY_DIR}/cleanup.stderr.raw" \
  || die "primary container cleanup was not proven"
verify_no_run_residue "primary" "$PRIMARY_ID" "$PRIMARY_NAME" "${PRIMARY_DIR}/volumes-before.txt" "$PRIMARY_DIR"
PRIMARY_ID=""
PRIMARY_LAUNCH_ATTEMPTED=0
write_new_lines "${PRIMARY_DIR}/status.safe" \
  "restore=passed" \
  "logical_schema_matches_source=true" \
  "complete_schema_only_dump_hash_matches_source=true" \
  "pre_restore_target_schema_matched_fresh_template1=true" \
  "migration_fingerprint_matches_source=true" \
  "dumpable_non_system_schema_inventory=public_only_and_matches_source" \
  "canonical_table_counts_captured=true" \
  "audit_segmentation_captured_without_row_contents=true" \
  "container_cleanup=proven" \
  "dump_sha256=${DUMP_SHA256}"

ABORT_REASON="primary_manifest"
assert_evidence_protection "$PRIMARY_DIR"
make_manifest "primary" "${RUN_DIR_IO}/primary.manifest.sha256"
require_run_dir_identity
PRIMARY_MANIFEST_SHA256="$(sha256_of "${RUN_DIR_IO}/primary.manifest.sha256")"
require_regex "$PRIMARY_MANIFEST_SHA256" '^[a-f0-9]{64}$' "primary manifest SHA-256"

# Independent second restore from zero, with a distinct name, database, label,
# and captured full container ID.
ABORT_REASON="start_verifier_restore"
capture_global_volumes "${VERIFIER_DIR}/volumes-before.txt" "${VERIFIER_DIR}/volumes-before.stderr.raw"
record_dump_hash "$DUMP_FINAL" "${VERIFIER_DIR}/dump.pre-restore.sha256" "$DUMP_SHA256" >/dev/null
start_disposable "verifier" "$VERIFIER_NAME" "$VERIFIER_DB" "$VERIFIER_DIR"
wait_for_final_disposable "$VERIFIER_ID" "$VERIFIER_DB" "verifier"
verify_disposable_insulation "$VERIFIER_ID" "$VERIFIER_DB" "verifier" "$VERIFIER_NAME" "${VERIFIER_DIR}/container-insulation.safe"
ABORT_REASON="prove_verifier_empty_target"
prove_empty_disposable_database "$VERIFIER_ID" "$VERIFIER_DB" "verifier" "$VERIFIER_DIR"
ABORT_REASON="restore_verifier"
restore_dump "$VERIFIER_ID" "$VERIFIER_DB" "verifier" "$VERIFIER_DIR" "$DUMP_FINAL"
record_dump_hash "$DUMP_FINAL" "${VERIFIER_DIR}/dump.post-restore.sha256" "$DUMP_SHA256" >/dev/null
ABORT_REASON="verify_verifier_restore"
capture_restored_evidence "$VERIFIER_ID" "$VERIFIER_DB" "verifier" "$VERIFIER_DIR"
validate_restored_evidence "$VERIFIER_DIR"

for canonical_name in schema-catalog.tsv schema-dump.sha256 migrations.tsv dumpable-schemas.tsv table-counts.tsv logical-summary.tsv audit-segments.tsv sequence-values.tsv; do
  cmp -s "${PRIMARY_DIR}/${canonical_name}" "${VERIFIER_DIR}/${canonical_name}" \
    || die "independent verifier canonical logical evidence differs from primary"
done

cleanup_owned_container "verifier" "$VERIFIER_ID" "$VERIFIER_NAME" "${VERIFIER_DIR}/cleanup.stderr.raw" \
  || die "verifier container cleanup was not proven"
verify_no_run_residue "verifier" "$VERIFIER_ID" "$VERIFIER_NAME" "${VERIFIER_DIR}/volumes-before.txt" "$VERIFIER_DIR"
VERIFIER_ID=""
VERIFIER_LAUNCH_ATTEMPTED=0
record_dump_hash "$DUMP_FINAL" "${VERIFIER_DIR}/dump.final-recheck.sha256" "$DUMP_SHA256" >/dev/null
write_new_lines "${VERIFIER_DIR}/primary-manifest.binding" \
  "primary_manifest_path=${RUN_DIR}/primary.manifest.sha256" \
  "primary_manifest_sha256=${PRIMARY_MANIFEST_SHA256}"
write_new_lines "${VERIFIER_DIR}/status.safe" \
  "restore=passed" \
  "primary_verifier_logical_summary_byte_identical=true" \
  "primary_verifier_table_counts_byte_identical=true" \
  "primary_verifier_migration_fingerprint_byte_identical=true" \
  "primary_verifier_dumpable_schema_inventory_byte_identical=true" \
  "primary_verifier_schema_fingerprint_byte_identical=true" \
  "primary_verifier_complete_schema_dump_hash_byte_identical=true" \
  "primary_verifier_audit_segments_byte_identical=true" \
  "primary_verifier_sequence_values_byte_identical=true" \
  "container_cleanup=proven" \
  "dump_sha256=${DUMP_SHA256}" \
  "proof=Staff database logical schema/data restore proven in an isolated disposable PostgreSQL 16.14 instance."

ABORT_REASON="verifier_manifest"
assert_evidence_protection "$VERIFIER_DIR"
make_manifest "verifier" "${RUN_DIR_IO}/verifier.manifest.sha256"
require_run_dir_identity
VERIFIER_MANIFEST_SHA256="$(sha256_of "${RUN_DIR_IO}/verifier.manifest.sha256")"
require_regex "$VERIFIER_MANIFEST_SHA256" '^[a-f0-9]{64}$' "verifier manifest SHA-256"
require_run_dir_identity
sync -f "$DUMP_FINAL"
sync -f "$RUN_DIR_IO"

require_run_dir_identity
ABORT_REASON="final_canonical_identity"
canonical_run_path_ok || die "canonical run-directory path no longer names the retained inode"
ABORT_REASON="complete"
printf 'status=SUCCESS\n'
printf 'proof=Staff database logical schema/data restore proven in an isolated disposable PostgreSQL 16.14 instance.\n'
printf 'run_directory=%s\n' "$RUN_DIR"
printf 'dump_path=%s\n' "${PRIMARY_CANONICAL_DIR}/$(basename "$DUMP_FINAL")"
printf 'dump_sha256=%s\n' "$DUMP_SHA256"
printf 'primary_manifest_path=%s\n' "${RUN_DIR}/primary.manifest.sha256"
printf 'primary_manifest_sha256=%s\n' "$PRIMARY_MANIFEST_SHA256"
printf 'verifier_manifest_path=%s\n' "${RUN_DIR}/verifier.manifest.sha256"
printf 'verifier_manifest_sha256=%s\n' "$VERIFIER_MANIFEST_SHA256"
printf 'cleanup=both captured IDs absent; exact names/labels absent; Docker volume inventory unchanged\n'
