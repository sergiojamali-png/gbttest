#requires -Version 7.0

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidatePattern('(?-i)^[a-f0-9]{64}$')]
    [string] $ReviewedHarnessSha256,

    [Parameter(Mandatory)]
    [ValidateRange(1, 104857600)]
    [long] $ReviewedHarnessBytes
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$ExpectedHarnessPath = 'C:\Users\SJ\Documents\ChatGPT\Saboos\deliverables\staff-b0-verified-ssh-executor-20260825.ps1'
$SourcePath = 'C:\Users\SJ\Documents\ChatGPT\Saboos\deliverables\staff-b0-backup-restore-execute-20260825.sh'
$ExpectedSourceSha256 = '5c09057154a208066c408c18b155db9f90fae32d546fdc05290b4dcd3627f3b6'
$ExpectedSourceBytes = 147481
$ExpectedSourceLf = 3041
$SshPath = 'C:\Windows\System32\OpenSSH\ssh.exe'
$SshAlias = 'saboos'
$EvidenceParent = 'C:\Users\SJ\Documents\ChatGPT\Saboos\deliverables\evidence'
$ValidationTimeoutSeconds = 60
$ExecutionTimeoutSeconds = 3600
$Utf8Strict = [System.Text.UTF8Encoding]::new($false, $true)

function Get-ByteSha256 {
    param([Parameter(Mandatory)][AllowEmptyCollection()][byte[]] $Bytes)

    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        return [System.Convert]::ToHexString($sha.ComputeHash($Bytes)).ToLowerInvariant()
    }
    finally {
        $sha.Dispose()
    }
}

function Get-FileSha256 {
    param([Parameter(Mandatory)][string] $LiteralPath)

    $stream = [System.IO.File]::Open(
        $LiteralPath,
        [System.IO.FileMode]::Open,
        [System.IO.FileAccess]::Read,
        [System.IO.FileShare]::Read
    )
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        return [System.Convert]::ToHexString($sha.ComputeHash($stream)).ToLowerInvariant()
    }
    finally {
        $sha.Dispose()
        $stream.Dispose()
    }
}

function Get-LfCount {
    param([Parameter(Mandatory)][AllowEmptyCollection()][byte[]] $Bytes)

    $count = 0
    foreach ($value in $Bytes) {
        if ($value -eq 10) {
            $count++
        }
    }
    return $count
}

function Test-ByteArrayEqual {
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][byte[]] $Left,
        [Parameter(Mandatory)][AllowEmptyCollection()][byte[]] $Right
    )

    if ($Left.Length -ne $Right.Length) {
        return $false
    }
    for ($index = 0; $index -lt $Left.Length; $index++) {
        if ($Left[$index] -ne $Right[$index]) {
            return $false
        }
    }
    return $true
}

function Test-ByteArrayPrefix {
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][byte[]] $Value,
        [Parameter(Mandatory)][AllowEmptyCollection()][byte[]] $Prefix
    )

    if ($Value.Length -lt $Prefix.Length) {
        return $false
    }
    for ($index = 0; $index -lt $Prefix.Length; $index++) {
        if ($Value[$index] -ne $Prefix[$index]) {
            return $false
        }
    }
    return $true
}

function Test-ByteArraySuffix {
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][byte[]] $Value,
        [Parameter(Mandatory)][AllowEmptyCollection()][byte[]] $Suffix
    )

    if ($Value.Length -lt $Suffix.Length) {
        return $false
    }
    $offset = $Value.Length - $Suffix.Length
    for ($index = 0; $index -lt $Suffix.Length; $index++) {
        if ($Value[$offset + $index] -ne $Suffix[$index]) {
            return $false
        }
    }
    return $true
}

function Write-NewUtf8Lines {
    param(
        [Parameter(Mandatory)][string] $LiteralPath,
        [Parameter(Mandatory)][string[]] $Lines
    )

    $stream = [System.IO.FileStream]::new(
        $LiteralPath,
        [System.IO.FileMode]::CreateNew,
        [System.IO.FileAccess]::Write,
        [System.IO.FileShare]::None
    )
    $writer = [System.IO.StreamWriter]::new($stream, [System.Text.UTF8Encoding]::new($false))
    $writer.NewLine = "`n"
    try {
        foreach ($line in $Lines) {
            if ($line.Contains("`r") -or $line.Contains("`n")) {
                throw 'A safe evidence line contained a newline.'
            }
            $writer.WriteLine($line)
        }
        $writer.Flush()
        $stream.Flush($true)
    }
    finally {
        $writer.Dispose()
        $stream.Dispose()
    }
}

function New-UniqueEvidenceDirectory {
    param([Parameter(Mandatory)][string] $Parent)

    [void][System.IO.Directory]::CreateDirectory($Parent)
    $random = [byte[]]::new(12)
    [System.Security.Cryptography.RandomNumberGenerator]::Fill($random)
    $suffix = [System.Convert]::ToHexString($random).ToLowerInvariant()
    $timestamp = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ', [Globalization.CultureInfo]::InvariantCulture)
    $candidate = [System.IO.Path]::Combine($Parent, "b0-verified-ssh-execution-$timestamp-$suffix")
    if ([System.IO.Directory]::Exists($candidate) -or [System.IO.File]::Exists($candidate)) {
        throw 'The random evidence path already exists; no retry was attempted.'
    }
    [void][System.IO.Directory]::CreateDirectory($candidate)
    Write-NewUtf8Lines -LiteralPath ([System.IO.Path]::Combine($candidate, 'claim.safe')) -Lines @(
        "claim_suffix=$suffix",
        "created_utc=$timestamp",
        'creation_api=System.IO.Directory.CreateDirectory plus FileMode.CreateNew'
    )
    return $candidate
}

function Get-SafeExceptionType {
    param([System.Exception] $Exception)

    if ($null -eq $Exception) {
        return 'none'
    }
    return $Exception.GetType().FullName
}

function Invoke-VerifiedSshCapture {
    param(
        [Parameter(Mandatory)][ValidateSet('validate', 'execute')][string] $Label,
        [Parameter(Mandatory)][string] $PythonCode,
        [Parameter(Mandatory)][byte[]] $Payload,
        [Parameter(Mandatory)][string] $EvidenceDirectory,
        [Parameter(Mandatory)][ValidateRange(1, 86400)][int] $TimeoutSeconds
    )

    if ($PythonCode.Contains("'")) {
        throw 'Remote Python wrapper code contains a forbidden single quote.'
    }
    if ($PythonCode.Contains("`r") -or $PythonCode.Contains("`n")) {
        throw 'Remote Python wrapper code must be exactly one line.'
    }

    $stdoutPath = [System.IO.Path]::Combine($EvidenceDirectory, "$Label.stdout.raw")
    $stderrPath = [System.IO.Path]::Combine($EvidenceDirectory, "$Label.stderr.raw")
    $stdoutStream = $null
    $stderrStream = $null
    $process = $null
    $stdoutTask = $null
    $stderrTask = $null
    $writeTask = $null
    $started = $false
    $timedOut = $false
    $captureComplete = $false
    $localProcessTerminated = $true
    $exitCode = $null
    $inputErrorType = 'none'
    $captureErrorType = 'none'
    $killErrorType = 'none'
    $processErrorType = 'none'

    try {
        $stdoutStream = [System.IO.FileStream]::new(
            $stdoutPath,
            [System.IO.FileMode]::CreateNew,
            [System.IO.FileAccess]::Write,
            [System.IO.FileShare]::None
        )
        $stderrStream = [System.IO.FileStream]::new(
            $stderrPath,
            [System.IO.FileMode]::CreateNew,
            [System.IO.FileAccess]::Write,
            [System.IO.FileShare]::None
        )

        $startInfo = [System.Diagnostics.ProcessStartInfo]::new()
        $startInfo.FileName = $SshPath
        $startInfo.UseShellExecute = $false
        $startInfo.CreateNoWindow = $true
        $startInfo.RedirectStandardInput = $true
        $startInfo.RedirectStandardOutput = $true
        $startInfo.RedirectStandardError = $true
        [void]$startInfo.ArgumentList.Add('-T')
        [void]$startInfo.ArgumentList.Add('-o')
        [void]$startInfo.ArgumentList.Add('BatchMode=yes')
        [void]$startInfo.ArgumentList.Add('-o')
        [void]$startInfo.ArgumentList.Add('ConnectTimeout=15')
        [void]$startInfo.ArgumentList.Add('-o')
        [void]$startInfo.ArgumentList.Add('ConnectionAttempts=1')
        [void]$startInfo.ArgumentList.Add('-o')
        [void]$startInfo.ArgumentList.Add('LogLevel=ERROR')
        [void]$startInfo.ArgumentList.Add($SshAlias)
        [void]$startInfo.ArgumentList.Add('/usr/bin/python3')
        [void]$startInfo.ArgumentList.Add('-c')
        [void]$startInfo.ArgumentList.Add("'$PythonCode'")

        $process = [System.Diagnostics.Process]::new()
        $process.StartInfo = $startInfo
        $started = $process.Start()
        if (-not $started) {
            throw 'The SSH process did not start.'
        }

        $stdoutTask = $process.StandardOutput.BaseStream.CopyToAsync($stdoutStream)
        $stderrTask = $process.StandardError.BaseStream.CopyToAsync($stderrStream)
        $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
        $writeTask = $process.StandardInput.BaseStream.WriteAsync($Payload, 0, $Payload.Length)

        while (-not $writeTask.IsCompleted -and [DateTime]::UtcNow -lt $deadline) {
            [System.Threading.Thread]::Sleep(100)
        }
        if (-not $writeTask.IsCompleted) {
            $timedOut = $true
            $inputErrorType = 'payload_write_timeout'
        }
        else {
            try {
                [void]$writeTask.GetAwaiter().GetResult()
                $process.StandardInput.BaseStream.Flush()
            }
            catch {
                $inputErrorType = Get-SafeExceptionType -Exception $_.Exception
            }
        }

        try {
            $process.StandardInput.Close()
        }
        catch {
            if ($inputErrorType -eq 'none') {
                $inputErrorType = Get-SafeExceptionType -Exception $_.Exception
            }
        }

        while (-not $timedOut -and -not $process.HasExited -and [DateTime]::UtcNow -lt $deadline) {
            [void]$process.WaitForExit(1000)
        }
        if (-not $process.HasExited) {
            $timedOut = $true
            try {
                $process.Kill($true)
            }
            catch {
                $killErrorType = Get-SafeExceptionType -Exception $_.Exception
            }
            $localProcessTerminated = $process.WaitForExit(10000)
        }

        if ($process.HasExited) {
            $process.WaitForExit()
            $exitCode = $process.ExitCode
            try {
                $copyAll = [System.Threading.Tasks.Task]::WhenAll(
                    [System.Threading.Tasks.Task[]]@($stdoutTask, $stderrTask)
                )
                [void]$copyAll.GetAwaiter().GetResult()
                $captureComplete = $true
            }
            catch {
                $captureErrorType = Get-SafeExceptionType -Exception $_.Exception
            }
        }
    }
    catch {
        $processErrorType = Get-SafeExceptionType -Exception $_.Exception
        if ($null -ne $process -and $started -and -not $process.HasExited) {
            try {
                $process.Kill($true)
                $localProcessTerminated = $process.WaitForExit(10000)
            }
            catch {
                $killErrorType = Get-SafeExceptionType -Exception $_.Exception
                $localProcessTerminated = $false
            }
        }
        if ($null -ne $process -and $started -and $process.HasExited) {
            $exitCode = $process.ExitCode
        }
    }
    finally {
        if ($null -ne $stdoutStream) {
            try { $stdoutStream.Flush($true) } catch { }
            $stdoutStream.Dispose()
        }
        if ($null -ne $stderrStream) {
            try { $stderrStream.Flush($true) } catch { }
            $stderrStream.Dispose()
        }
        if ($null -ne $process) {
            $process.Dispose()
        }
    }

    $stdoutBytes = [System.IO.File]::ReadAllBytes($stdoutPath)
    $stderrBytes = [System.IO.File]::ReadAllBytes($stderrPath)
    return [pscustomobject]@{
        Label = $Label
        Started = $started
        TimedOut = $timedOut
        CaptureComplete = $captureComplete
        LocalProcessTerminated = $localProcessTerminated
        ExitCode = $exitCode
        InputErrorType = $inputErrorType
        CaptureErrorType = $captureErrorType
        KillErrorType = $killErrorType
        ProcessErrorType = $processErrorType
        StdoutPath = $stdoutPath
        StderrPath = $stderrPath
        StdoutBytes = $stdoutBytes.Length
        StderrBytes = $stderrBytes.Length
        StdoutLf = Get-LfCount -Bytes $stdoutBytes
        StderrLf = Get-LfCount -Bytes $stderrBytes
        StdoutSha256 = Get-ByteSha256 -Bytes $stdoutBytes
        StderrSha256 = Get-ByteSha256 -Bytes $stderrBytes
    }
}

function Add-CaptureManifestFields {
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary] $Manifest,
        [Parameter(Mandatory)][pscustomobject] $Capture
    )

    $prefix = $Capture.Label
    $Manifest["$prefix.started"] = $Capture.Started.ToString().ToLowerInvariant()
    $Manifest["$prefix.timed_out"] = $Capture.TimedOut.ToString().ToLowerInvariant()
    $Manifest["$prefix.capture_complete"] = $Capture.CaptureComplete.ToString().ToLowerInvariant()
    $Manifest["$prefix.local_process_terminated"] = $Capture.LocalProcessTerminated.ToString().ToLowerInvariant()
    $Manifest["$prefix.exit_code"] = if ($null -eq $Capture.ExitCode) { 'unavailable' } else { [string]$Capture.ExitCode }
    $Manifest["$prefix.input_error_type"] = $Capture.InputErrorType
    $Manifest["$prefix.capture_error_type"] = $Capture.CaptureErrorType
    $Manifest["$prefix.kill_error_type"] = $Capture.KillErrorType
    $Manifest["$prefix.process_error_type"] = $Capture.ProcessErrorType
    $Manifest["$prefix.stdout_file"] = [System.IO.Path]::GetFileName($Capture.StdoutPath)
    $Manifest["$prefix.stdout_bytes"] = [string]$Capture.StdoutBytes
    $Manifest["$prefix.stdout_lf"] = [string]$Capture.StdoutLf
    $Manifest["$prefix.stdout_sha256"] = $Capture.StdoutSha256
    $Manifest["$prefix.stderr_file"] = [System.IO.Path]::GetFileName($Capture.StderrPath)
    $Manifest["$prefix.stderr_bytes"] = [string]$Capture.StderrBytes
    $Manifest["$prefix.stderr_lf"] = [string]$Capture.StderrLf
    $Manifest["$prefix.stderr_sha256"] = $Capture.StderrSha256
}

function Test-B0SuccessTerminalOutput {
    param([Parameter(Mandatory)][AllowEmptyCollection()][byte[]] $Bytes)

    try {
        $text = $Utf8Strict.GetString($Bytes)
    }
    catch {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'invalid_utf8' }
    }
    if ($text.Length -eq 0 -or -not $text.EndsWith("`n", [StringComparison]::Ordinal)) {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'missing_terminal_lf' }
    }
    if ($text.Contains("`r") -or $text.Contains([char]0) -or $text[0] -eq [char]0xFEFF) {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'forbidden_character' }
    }

    $body = $text.Substring(0, $text.Length - 1)
    $lines = [string[]]$body.Split([char]10, [StringSplitOptions]::None)
    if ($lines.Length -ne 10) {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'terminal_line_count' }
    }

    $expectedKeys = [string[]]@(
        'status',
        'proof',
        'run_directory',
        'dump_path',
        'dump_sha256',
        'primary_manifest_path',
        'primary_manifest_sha256',
        'verifier_manifest_path',
        'verifier_manifest_sha256',
        'cleanup'
    )
    $keys = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    for ($index = 0; $index -lt $lines.Length; $index++) {
        $separator = $lines[$index].IndexOf('=', [StringComparison]::Ordinal)
        if ($separator -le 0) {
            return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'missing_key_separator' }
        }
        $key = $lines[$index].Substring(0, $separator)
        if ($key -cne $expectedKeys[$index] -or -not $keys.Add($key)) {
            return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'key_identity_or_uniqueness' }
        }
    }

    if ($lines[0] -cne 'status=SUCCESS') {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'status' }
    }
    if ($lines[1] -cne 'proof=Staff database logical schema/data restore proven in an isolated disposable PostgreSQL 16.14 instance.') {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'proof' }
    }

    $runMatch = [regex]::Match(
        $lines[2],
        '^run_directory=/srv/saboos-storage/backups/staff-staging/b0-logical-restore-(?<id>[0-9]{8}T[0-9]{6}Z-[a-f0-9]{12})$',
        [Text.RegularExpressions.RegexOptions]::CultureInvariant
    )
    if (-not $runMatch.Success) {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'run_directory' }
    }
    $runId = $runMatch.Groups['id'].Value
    $runDirectory = "/srv/saboos-storage/backups/staff-staging/b0-logical-restore-$runId"
    if ($lines[3] -cne "dump_path=$runDirectory/primary/saboos-staff-$runId.dump") {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'dump_path_binding' }
    }
    if ($lines[4] -cnotmatch '^dump_sha256=[a-f0-9]{64}$') {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'dump_sha256' }
    }
    if ($lines[5] -cne "primary_manifest_path=$runDirectory/primary.manifest.sha256") {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'primary_manifest_path_binding' }
    }
    if ($lines[6] -cnotmatch '^primary_manifest_sha256=[a-f0-9]{64}$') {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'primary_manifest_sha256' }
    }
    if ($lines[7] -cne "verifier_manifest_path=$runDirectory/verifier.manifest.sha256") {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'verifier_manifest_path_binding' }
    }
    if ($lines[8] -cnotmatch '^verifier_manifest_sha256=[a-f0-9]{64}$') {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'verifier_manifest_sha256' }
    }
    if ($lines[9] -cne 'cleanup=both captured IDs absent; exact names/labels absent; Docker volume inventory unchanged') {
        return [pscustomobject]@{ IsValid = $false; Lines = [string[]]@(); Reason = 'cleanup' }
    }

    return [pscustomobject]@{ IsValid = $true; Lines = $lines; Reason = 'exact' }
}

function Write-SafeManifest {
    param(
        [Parameter(Mandatory)][string] $EvidenceDirectory,
        [Parameter(Mandatory)][System.Collections.IDictionary] $Manifest
    )

    $lines = [System.Collections.Generic.List[string]]::new()
    foreach ($key in $Manifest.Keys) {
        $keyText = [string]$key
        $valueText = [string]$Manifest[$key]
        if ($keyText -notmatch '^[A-Za-z0-9_.-]+$') {
            throw 'A manifest key was not allowlisted.'
        }
        if ($valueText.Contains("`r") -or $valueText.Contains("`n") -or $valueText.Contains([char]0)) {
            throw 'A manifest value contained a forbidden character.'
        }
        [void]$lines.Add("$keyText=$valueText")
    }
    $manifestPath = [System.IO.Path]::Combine($EvidenceDirectory, 'manifest.safe')
    Write-NewUtf8Lines -LiteralPath $manifestPath -Lines $lines.ToArray()
    $manifestSha256 = Get-FileSha256 -LiteralPath $manifestPath
    $manifestHashPath = [System.IO.Path]::Combine($EvidenceDirectory, 'manifest.sha256')
    Write-NewUtf8Lines -LiteralPath $manifestHashPath -Lines @("$manifestSha256  manifest.safe")
    return $manifestSha256
}

function Write-CaptureSummary {
    param(
        [Parameter(Mandatory)][string] $Prefix,
        [Parameter(Mandatory)][pscustomobject] $Capture
    )

    [Console]::Out.WriteLine("B0_EXECUTOR_${Prefix}_STDOUT_BYTES=$($Capture.StdoutBytes)")
    [Console]::Out.WriteLine("B0_EXECUTOR_${Prefix}_STDOUT_LF=$($Capture.StdoutLf)")
    [Console]::Out.WriteLine("B0_EXECUTOR_${Prefix}_STDOUT_SHA256=$($Capture.StdoutSha256)")
    [Console]::Out.WriteLine("B0_EXECUTOR_${Prefix}_STDERR_BYTES=$($Capture.StderrBytes)")
    [Console]::Out.WriteLine("B0_EXECUTOR_${Prefix}_STDERR_LF=$($Capture.StderrLf)")
    [Console]::Out.WriteLine("B0_EXECUTOR_${Prefix}_STDERR_SHA256=$($Capture.StderrSha256)")
    $exitText = if ($null -eq $Capture.ExitCode) { 'unavailable' } else { [string]$Capture.ExitCode }
    [Console]::Out.WriteLine("B0_EXECUTOR_${Prefix}_EXIT=$exitText")
}

function Get-FailureExitCode {
    param(
        [Parameter(Mandatory)][pscustomobject] $Capture,
        [Parameter(Mandatory)][ValidateRange(1, 255)][int] $Fallback
    )

    if ($Capture.TimedOut) {
        return 124
    }
    if ($null -ne $Capture.ExitCode -and $Capture.ExitCode -ge 1 -and $Capture.ExitCode -le 255) {
        return [int]$Capture.ExitCode
    }
    return $Fallback
}

$EvidenceDirectory = $null
$ManifestWritten = $false
$Manifest = [ordered]@{}
$CurrentStage = 'local_identity'
$ExecutionAttempted = $false

try {
    $actualHarnessPath = [System.IO.Path]::GetFullPath($PSCommandPath)
    if (-not [string]::Equals($actualHarnessPath, $ExpectedHarnessPath, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Harness path identity mismatch.'
    }
    if (-not [System.IO.File]::Exists($ExpectedHarnessPath)) {
        throw 'Harness file identity is absent.'
    }
    $actualHarnessBytes = [System.IO.File]::ReadAllBytes($ExpectedHarnessPath)
    $actualHarnessSha256 = Get-ByteSha256 -Bytes $actualHarnessBytes
    if ($actualHarnessBytes.Length -ne $ReviewedHarnessBytes) {
        throw 'Harness byte length does not match the reviewed invocation identity.'
    }
    if ($actualHarnessSha256 -cne $ReviewedHarnessSha256) {
        throw 'Harness SHA-256 does not match the reviewed invocation identity.'
    }
    if (-not [System.IO.File]::Exists($SshPath)) {
        throw 'Pinned OpenSSH executable is absent.'
    }
    if (-not [string]::Equals([System.IO.Path]::GetFullPath($SshPath), $SshPath, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Pinned OpenSSH path identity mismatch.'
    }
    if (-not [System.IO.File]::Exists($SourcePath)) {
        throw 'Pinned B0 source script is absent.'
    }

    $sourceBytes = [System.IO.File]::ReadAllBytes($SourcePath)
    $sourceSha256 = Get-ByteSha256 -Bytes $sourceBytes
    $sourceLf = Get-LfCount -Bytes $sourceBytes
    if ($sourceBytes.Length -ne $ExpectedSourceBytes) {
        throw 'Pinned B0 source byte length mismatch.'
    }
    if ($sourceSha256 -cne $ExpectedSourceSha256) {
        throw 'Pinned B0 source SHA-256 mismatch.'
    }
    if ($sourceLf -ne $ExpectedSourceLf) {
        throw 'Pinned B0 source LF count mismatch.'
    }
    if ($sourceBytes.Length -ge 3 -and $sourceBytes[0] -eq 0xEF -and $sourceBytes[1] -eq 0xBB -and $sourceBytes[2] -eq 0xBF) {
        throw 'Pinned B0 source unexpectedly has a UTF-8 BOM.'
    }
    foreach ($value in $sourceBytes) {
        if ($value -eq 0 -or $value -eq 13) {
            throw 'Pinned B0 source contains a forbidden NUL or CR byte.'
        }
    }
    $sourceText = $Utf8Strict.GetString($sourceBytes)
    $roundTripBytes = [System.Text.UTF8Encoding]::new($false, $true).GetBytes($sourceText)
    if (-not (Test-ByteArrayEqual -Left $sourceBytes -Right $roundTripBytes)) {
        throw 'Pinned B0 source failed strict UTF-8 round-trip identity.'
    }

    $expectedReceiptText = "B0_WRAPPER_BYTES=$ExpectedSourceBytes`nB0_WRAPPER_SHA256=$ExpectedSourceSha256`nB0_WRAPPER_IDENTITY_OK=true`n"
    $expectedReceiptBytes = [System.Text.Encoding]::UTF8.GetBytes($expectedReceiptText)
    $expectedExecutionSuccessReceiptText = "${expectedReceiptText}B0_WRAPPER_BASH_EXIT=0`n"
    $expectedExecutionSuccessReceiptBytes = [System.Text.Encoding]::UTF8.GetBytes($expectedExecutionSuccessReceiptText)
    $validationPython = 'import hashlib,sys;d=sys.stdin.buffer.read();h=hashlib.sha256(d).hexdigest();ok=len(d)==147481 and h=="5c09057154a208066c408c18b155db9f90fae32d546fdc05290b4dcd3627f3b6";sys.stderr.write("B0_WRAPPER_BYTES="+str(len(d))+"\nB0_WRAPPER_SHA256="+h+"\nB0_WRAPPER_IDENTITY_OK="+("true" if ok else "false")+"\n");sys.stderr.flush();sys.exit(0 if ok else 91)'
    $executionPython = 'import hashlib,subprocess,sys;d=sys.stdin.buffer.read();h=hashlib.sha256(d).hexdigest();ok=len(d)==147481 and h=="5c09057154a208066c408c18b155db9f90fae32d546fdc05290b4dcd3627f3b6";sys.stderr.write("B0_WRAPPER_BYTES="+str(len(d))+"\nB0_WRAPPER_SHA256="+h+"\nB0_WRAPPER_IDENTITY_OK="+("true" if ok else "false")+"\n");sys.stderr.flush();ok or sys.exit(91);r=subprocess.run(["/usr/bin/bash","-s"],input=d);sys.stderr.write("B0_WRAPPER_BASH_EXIT="+str(r.returncode)+"\n");sys.stderr.flush();sys.exit(r.returncode)'
    foreach ($wrapperCode in @($validationPython, $executionPython)) {
        if ($wrapperCode.Contains("'") -or $wrapperCode.Contains("`r") -or $wrapperCode.Contains("`n")) {
            throw 'A remote wrapper violated the one-line single-quote-free contract.'
        }
    }

    $EvidenceDirectory = New-UniqueEvidenceDirectory -Parent $EvidenceParent
    $sshInfo = [System.IO.FileInfo]::new($SshPath)
    $sshVersion = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($SshPath).FileVersion
    if ([string]::IsNullOrWhiteSpace($sshVersion)) {
        $sshVersion = 'unavailable'
    }

    $Manifest['schema'] = 'saboos-b0-verified-ssh-executor-v1'
    $Manifest['created_utc'] = [DateTime]::UtcNow.ToString('o', [Globalization.CultureInfo]::InvariantCulture)
    $Manifest['outcome'] = 'IN_PROGRESS'
    $Manifest['auto_retry'] = 'false'
    $Manifest['harness_path'] = $ExpectedHarnessPath
    $Manifest['reviewed_harness_bytes'] = [string]$ReviewedHarnessBytes
    $Manifest['reviewed_harness_sha256'] = $ReviewedHarnessSha256
    $Manifest['actual_harness_bytes'] = [string]$actualHarnessBytes.Length
    $Manifest['actual_harness_sha256'] = $actualHarnessSha256
    $Manifest['harness_review_identity_match'] = 'true'
    $Manifest['powershell_version'] = $PSVersionTable.PSVersion.ToString()
    $Manifest['source_path'] = $SourcePath
    $Manifest['source_bytes'] = [string]$sourceBytes.Length
    $Manifest['source_lf'] = [string]$sourceLf
    $Manifest['source_cr'] = '0'
    $Manifest['source_nul'] = '0'
    $Manifest['source_bom'] = 'false'
    $Manifest['source_utf8_roundtrip'] = 'true'
    $Manifest['source_sha256'] = $sourceSha256
    $Manifest['ssh_path'] = $SshPath
    $Manifest['ssh_bytes'] = [string]$sshInfo.Length
    $Manifest['ssh_sha256'] = Get-FileSha256 -LiteralPath $SshPath
    $Manifest['ssh_file_version'] = $sshVersion
    $Manifest['ssh_alias'] = $SshAlias
    $Manifest['remote_python'] = '/usr/bin/python3'
    $Manifest['remote_bash'] = '/usr/bin/bash'
    $Manifest['remote_shell_wrapper'] = 'single-quoted-one-line-python-with-no-internal-single-quote'
    $Manifest['validation_wrapper_bytes'] = [string][System.Text.Encoding]::UTF8.GetByteCount($validationPython)
    $Manifest['validation_wrapper_sha256'] = Get-ByteSha256 -Bytes ([System.Text.Encoding]::UTF8.GetBytes($validationPython))
    $Manifest['execution_wrapper_bytes'] = [string][System.Text.Encoding]::UTF8.GetByteCount($executionPython)
    $Manifest['execution_wrapper_sha256'] = Get-ByteSha256 -Bytes ([System.Text.Encoding]::UTF8.GetBytes($executionPython))
    $Manifest['validation_timeout_seconds'] = [string]$ValidationTimeoutSeconds
    $Manifest['execution_timeout_seconds'] = [string]$ExecutionTimeoutSeconds
    $Manifest['execution.attempted'] = 'false'

    $CurrentStage = 'validation_ssh'
    $validationArguments = @{
        Label = 'validate'
        PythonCode = $validationPython
        Payload = $sourceBytes
        EvidenceDirectory = $EvidenceDirectory
        TimeoutSeconds = $ValidationTimeoutSeconds
    }
    $validation = Invoke-VerifiedSshCapture @validationArguments
    Add-CaptureManifestFields -Manifest $Manifest -Capture $validation
    $validationStdout = [System.IO.File]::ReadAllBytes($validation.StdoutPath)
    $validationStderr = [System.IO.File]::ReadAllBytes($validation.StderrPath)
    $validationReceiptExact = (
        $validation.Started -and
        -not $validation.TimedOut -and
        $validation.CaptureComplete -and
        $validation.LocalProcessTerminated -and
        $validation.ExitCode -eq 0 -and
        $validation.InputErrorType -eq 'none' -and
        $validation.CaptureErrorType -eq 'none' -and
        $validation.KillErrorType -eq 'none' -and
        $validation.ProcessErrorType -eq 'none' -and
        $validationStdout.Length -eq 0 -and
        (Test-ByteArrayEqual -Left $validationStderr -Right $expectedReceiptBytes)
    )
    $Manifest['validation.stdout_empty'] = ($validationStdout.Length -eq 0).ToString().ToLowerInvariant()
    $Manifest['validation.receipt_exact'] = $validationReceiptExact.ToString().ToLowerInvariant()
    $Manifest['execution.started'] = 'false'

    if (-not $validationReceiptExact) {
        $Manifest['outcome'] = if ($validation.TimedOut) { 'VALIDATION_TIMEOUT_NO_EXECUTION' } else { 'VALIDATION_FAILED_NO_EXECUTION' }
        $Manifest['remote_mutation_attempted'] = 'false'
        $CurrentStage = 'validation_manifest'
        $manifestSha256 = Write-SafeManifest -EvidenceDirectory $EvidenceDirectory -Manifest $Manifest
        $ManifestWritten = $true
        [Console]::Out.WriteLine("B0_EXECUTOR_EVIDENCE_DIR=$EvidenceDirectory")
        [Console]::Out.WriteLine("B0_EXECUTOR_SOURCE_BYTES=$($sourceBytes.Length)")
        [Console]::Out.WriteLine("B0_EXECUTOR_SOURCE_LF=$sourceLf")
        [Console]::Out.WriteLine("B0_EXECUTOR_SOURCE_SHA256=$sourceSha256")
        Write-CaptureSummary -Prefix 'VALIDATE' -Capture $validation
        [Console]::Out.WriteLine("B0_EXECUTOR_MANIFEST_SHA256=$manifestSha256")
        [Console]::Out.WriteLine("B0_EXECUTOR_OUTCOME=$($Manifest['outcome'])")
        exit (Get-FailureExitCode -Capture $validation -Fallback 92)
    }

    $CurrentStage = 'execution_ssh'
    $executionArguments = @{
        Label = 'execute'
        PythonCode = $executionPython
        Payload = $sourceBytes
        EvidenceDirectory = $EvidenceDirectory
        TimeoutSeconds = $ExecutionTimeoutSeconds
    }
    $Manifest['execution.attempted'] = 'true'
    $ExecutionAttempted = $true
    $execution = Invoke-VerifiedSshCapture @executionArguments
    Add-CaptureManifestFields -Manifest $Manifest -Capture $execution
    $Manifest['execution.started'] = $execution.Started.ToString().ToLowerInvariant()
    $executionStdout = [System.IO.File]::ReadAllBytes($execution.StdoutPath)
    $executionStderr = [System.IO.File]::ReadAllBytes($execution.StderrPath)
    $executionReceiptPresent = Test-ByteArrayPrefix -Value $executionStderr -Prefix $expectedReceiptBytes
    $executionSuccessReceiptsExact = Test-ByteArrayEqual -Left $executionStderr -Right $expectedExecutionSuccessReceiptBytes
    $executionCompletionReceiptMatchesExit = $false
    $executionCompletionExitValue = 'unavailable'
    if ($null -ne $execution.ExitCode) {
        $executionCompletionExitValue = [string]$execution.ExitCode
        $expectedCompletionReceiptText = "B0_WRAPPER_BASH_EXIT=$($execution.ExitCode)`n"
        $expectedCompletionReceiptBytes = [System.Text.Encoding]::UTF8.GetBytes($expectedCompletionReceiptText)
        $executionCompletionReceiptMatchesExit = Test-ByteArraySuffix -Value $executionStderr -Suffix $expectedCompletionReceiptBytes
    }
    $executionTransportCertain = (
        $execution.Started -and
        -not $execution.TimedOut -and
        $execution.CaptureComplete -and
        $execution.LocalProcessTerminated -and
        $execution.InputErrorType -eq 'none' -and
        $execution.CaptureErrorType -eq 'none' -and
        $execution.KillErrorType -eq 'none' -and
        $execution.ProcessErrorType -eq 'none'
    )
    $Manifest['execution.receipt_prefix_exact'] = $executionReceiptPresent.ToString().ToLowerInvariant()
    $Manifest['execution.success_receipts_exact'] = $executionSuccessReceiptsExact.ToString().ToLowerInvariant()
    $Manifest['execution.completion_receipt_exit_value'] = $executionCompletionExitValue
    $Manifest['execution.completion_receipt_matches_exit'] = $executionCompletionReceiptMatchesExit.ToString().ToLowerInvariant()
    $Manifest['execution.transport_capture_certain'] = $executionTransportCertain.ToString().ToLowerInvariant()
    $terminal = Test-B0SuccessTerminalOutput -Bytes $executionStdout
    $Manifest['execution.success_terminal_exact'] = $terminal.IsValid.ToString().ToLowerInvariant()
    $Manifest['execution.success_terminal_reason'] = $terminal.Reason
    $Manifest['execution.success_terminal_lines'] = if ($terminal.IsValid) { [string]$terminal.Lines.Length } else { '0' }
    $Manifest['execution.success_terminal_sha256'] = if ($terminal.IsValid) { $execution.StdoutSha256 } else { 'unverified' }

    $executionSuccess = (
        $executionTransportCertain -and
        $execution.ExitCode -eq 0 -and
        $executionSuccessReceiptsExact -and
        $terminal.IsValid
    )
    $executionConfirmedFailure = (
        $executionTransportCertain -and
        $null -ne $execution.ExitCode -and
        $execution.ExitCode -ge 1 -and
        $execution.ExitCode -le 254 -and
        $executionReceiptPresent -and
        $executionCompletionReceiptMatchesExit
    )
    $Manifest['execution.confirmed_failure'] = $executionConfirmedFailure.ToString().ToLowerInvariant()

    if ($executionSuccess) {
        $Manifest['outcome'] = 'SUCCESS'
        $Manifest['remote_outcome'] = 'BASH_EXIT_0_WITH_EXACT_COMPLETION_AND_TERMINAL_EVIDENCE'
    }
    elseif ($execution.TimedOut) {
        $Manifest['outcome'] = 'UNKNOWN_TIMEOUT_NO_RETRY'
        $Manifest['remote_outcome'] = 'UNKNOWN_AFTER_SSH_TIMEOUT'
    }
    elseif ($execution.ExitCode -eq 255) {
        $Manifest['outcome'] = 'UNKNOWN_SSH_EXIT_255_NO_RETRY'
        $Manifest['remote_outcome'] = 'UNKNOWN_TRANSPORT_EXIT_255'
    }
    elseif (-not $executionTransportCertain) {
        $Manifest['outcome'] = 'UNKNOWN_TRANSPORT_OR_CAPTURE_NO_RETRY'
        $Manifest['remote_outcome'] = 'UNKNOWN_TRANSPORT_OR_CAPTURE_STATE'
    }
    elseif (-not $executionReceiptPresent) {
        $Manifest['outcome'] = 'UNKNOWN_IDENTITY_RECEIPT_NO_RETRY'
        $Manifest['remote_outcome'] = 'UNKNOWN_MISSING_OR_MISMATCHED_IDENTITY_RECEIPT'
    }
    elseif (-not $executionCompletionReceiptMatchesExit) {
        $Manifest['outcome'] = 'UNKNOWN_COMPLETION_RECEIPT_NO_RETRY'
        $Manifest['remote_outcome'] = 'UNKNOWN_MISSING_OR_MISMATCHED_COMPLETION_RECEIPT'
    }
    elseif ($executionConfirmedFailure) {
        $Manifest['outcome'] = 'EXECUTION_CONFIRMED_FAILED_NO_RETRY'
        $Manifest['remote_outcome'] = 'BASH_NONZERO_EXIT_WITH_MATCHED_COMPLETION_RECEIPT'
    }
    elseif ($execution.ExitCode -eq 0) {
        $Manifest['outcome'] = 'UNKNOWN_SUCCESS_EVIDENCE_NO_RETRY'
        $Manifest['remote_outcome'] = 'BASH_EXIT_0_WITHOUT_EXACT_SUCCESS_EVIDENCE'
    }
    else {
        $Manifest['outcome'] = 'UNKNOWN_UNCLASSIFIED_EXECUTION_NO_RETRY'
        $Manifest['remote_outcome'] = 'UNKNOWN_UNCLASSIFIED_EXECUTION_STATE'
    }

    $CurrentStage = 'final_manifest'
    $manifestSha256 = Write-SafeManifest -EvidenceDirectory $EvidenceDirectory -Manifest $Manifest
    $ManifestWritten = $true
    [Console]::Out.WriteLine("B0_EXECUTOR_EVIDENCE_DIR=$EvidenceDirectory")
    [Console]::Out.WriteLine("B0_EXECUTOR_SOURCE_BYTES=$($sourceBytes.Length)")
    [Console]::Out.WriteLine("B0_EXECUTOR_SOURCE_LF=$sourceLf")
    [Console]::Out.WriteLine("B0_EXECUTOR_SOURCE_SHA256=$sourceSha256")
    Write-CaptureSummary -Prefix 'VALIDATE' -Capture $validation
    Write-CaptureSummary -Prefix 'EXECUTE' -Capture $execution
    [Console]::Out.WriteLine("B0_EXECUTOR_MANIFEST_SHA256=$manifestSha256")
    [Console]::Out.WriteLine("B0_EXECUTOR_OUTCOME=$($Manifest['outcome'])")

    if ($executionSuccess) {
        foreach ($line in $terminal.Lines) {
            [Console]::Out.WriteLine($line)
        }
        exit 0
    }
    if ($executionConfirmedFailure) {
        exit ([int]$execution.ExitCode)
    }
    if ($execution.TimedOut) {
        exit 124
    }
    if ($execution.ExitCode -eq 255) {
        exit 255
    }
    exit 94
}
catch {
    $safeType = Get-SafeExceptionType -Exception $_.Exception
    $catchOutcome = if ($ExecutionAttempted) { 'UNKNOWN_AFTER_LOCAL_HARNESS_FAILURE_POST_EXECUTION' } else { 'LOCAL_HARNESS_FAILURE_NO_RETRY' }
    if ($null -ne $EvidenceDirectory) {
        if (-not $ManifestWritten) {
            try {
                $Manifest['outcome'] = $catchOutcome
                $Manifest['failure_stage'] = $CurrentStage
                $Manifest['failure_type'] = $safeType
                $Manifest['execution.attempted'] = $ExecutionAttempted.ToString().ToLowerInvariant()
                $Manifest['remote_outcome'] = if ($ExecutionAttempted) { 'UNKNOWN_AFTER_LOCAL_HARNESS_FAILURE_POST_EXECUTION' } else { 'EXECUTION_NOT_REACHED_OR_NOT_STARTED' }
                $manifestSha256 = Write-SafeManifest -EvidenceDirectory $EvidenceDirectory -Manifest $Manifest
                $ManifestWritten = $true
                [Console]::Out.WriteLine("B0_EXECUTOR_MANIFEST_SHA256=$manifestSha256")
            }
            catch {
                [Console]::Out.WriteLine('B0_EXECUTOR_MANIFEST_SHA256=unavailable')
            }
        }
        [Console]::Out.WriteLine("B0_EXECUTOR_EVIDENCE_DIR=$EvidenceDirectory")
    }
    [Console]::Out.WriteLine('B0_EXECUTOR_EXIT=99')
    [Console]::Out.WriteLine("B0_EXECUTOR_OUTCOME=$catchOutcome")
    exit 99
}
