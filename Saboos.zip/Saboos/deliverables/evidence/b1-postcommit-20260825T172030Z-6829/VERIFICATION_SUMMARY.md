# B1 immutable post-commit verification

Verdict: **PASS** for the focused B1 atomic refresh/session-revocation package. This is source/disposable-test evidence only; nothing was deployed.

## Immutable identity and scope

- Commit: `267262cb145ffcb08fbab16ee9a9937f93e4371e`
- Tree: `84cec109f49523e4ca4940c2e00ca526820d5b56`
- Parent: `6565612a6000f2fc8b2ae5bc5bf009a28ad99fe1`
- Subject: `fix(backend): serialize refresh and session revocation`
- Exact changed files:
  - `backend/src/staff/services/sessions.ts` - 159 additions, 50 deletions; SHA-256 `63a1442a07a71a2694857416dd3b83de037f50958e3e51040f1bcde0c8194c8b`
  - `backend/test/staff/sessions.test.ts` - 601 additions, 1 deletion; SHA-256 `07e21a654524afa85cf6291185176dc34b635d7a778bddae0f696138783ed4d9`
- Total: 760 additions, 51 deletions across exactly two authorized files.
- Working-file Git blobs exactly matched the committed blobs; `git diff --check` passed; the detached verification worktree was clean.

## Functional evidence

- Accepted database: `saboos_ci_b1_post_6829_r2_1720` on `127.0.0.1:54329`
- Database role: `saboos_test`
- PostgreSQL: 16.14
- Migrations: 28 total, 28 successfully applied, 0 incomplete or rolled back
- Explicit Prisma generation: passed with Prisma Client 5.22.0
- Exact suite: `backend/test/staff/sessions.test.ts`
- Source-selected tests: 11
- Passed: 11
- Failed: 0
- Skipped: 0
- Todo: 0
- Flaky: 0
- Retried: 0 (no retry configured)
- Test files: 1 passed, 0 failed
- API: PID `44060`, `[::]:50548`, exact command `node --import tsx src/index.ts`
- Test parent: PID `44388`, exact Vitest sessions-file command
- Health: HTTP 200, `{"ok":true}`
- Backend TypeScript build: passed

The tests directly exercised normal logout/revocation, concurrent single-use rotation, replay tripwire behavior, refresh versus revoke-all in both lock orderings, refresh versus single-session revoke in both lock orderings, disable/reactivate exclusion, security-event insertion rollback, and deferred commit failure rollback.

## Security and cleanliness

- Full manual review was performed on both committed files.
- High-confidence scans found 0 private-key, AWS, Stripe, GitHub, Slack, Google API, JWT literal, credential-URL, assigned-secret-literal, or long entropy-literal matches in the committed diff.
- `gitleaks`, `trufflehog`, and `detect-secrets` were not installed; this limitation is recorded in `secret-scan.log`.
- Runtime identifiers such as `accessToken`, `refreshToken`, and test users' generated passwords are code references, not embedded values.
- Fault-injection trigger/function residue: 0.
- Run-owned database, process, port, and worktree residue: 0.

## Evidence files

Core evidence is in this directory: commit identity/scope and patch, source hashes, Prisma reset/generation output, exact test stdout/stderr and counts, API process identity, database state, build output, secret scan, attempt ledger, and cleanup proof. `SHA256SUMS.txt` binds the evidence files.

