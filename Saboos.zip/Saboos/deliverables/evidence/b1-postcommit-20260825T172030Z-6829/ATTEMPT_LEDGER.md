# B1 post-commit verification attempt ledger

Immutable target:

- Commit: `267262cb145ffcb08fbab16ee9a9937f93e4371e`
- Tree: `84cec109f49523e4ca4940c2e00ca526820d5b56`
- Parent: `6565612a6000f2fc8b2ae5bc5bf009a28ad99fe1`

## Environment setup

- Fresh detached worktree: `D:\conductor-worktrees\saboos-staff-b1-postcommit-20260825T172030Z-6829`
- PostgreSQL listener: `127.0.0.1:54329`, Windows PID `39028`, PostgreSQL 16.14, data directory `D:/codex-tools/pg-audit-20aff071-frozen`
- Docker CLI was unavailable, so the required already-running local disposable PostgreSQL path was used.
- `npm --prefix backend ci` exited 0 and installed 314 packages from the committed lockfile. NPM reported one moderate and two high dependency advisories; no dependency mutation was made. NPM also warned that seven lifecycle scripts were not allow-listed. Explicit Prisma generation, the database-backed suite, Argon2-backed login coverage, Redis-backed harness startup, and TypeScript build all subsequently succeeded.

## Attempt 1 - test outcome valid, process binding incomplete

- Database: `saboos_ci_b1_post_6829_172030`
- Intended run-owned API port: `53862` (confirmed unbound before the run)
- Prisma reset: exit 0, `--skip-generate --skip-seed`
- Explicit Prisma generate: exit 0
- Applied migrations: 28/28, failed or rolled back: 0
- Selected file: `test/staff/sessions.test.ts`
- Result: 1/1 file passed; 11/11 tests passed; 0 failed, 0 skipped, 0 todo
- Evidence limitation: the independent listener probe began during migration setup and did not capture the short-lived API listener before teardown. This attempt is retained as valid test output but was not accepted as the final process-bound verification.
- Raw output: `sessions-test.log`

## Attempt 2 - accepted verification run

- Database: `saboos_ci_b1_post_6829_r2_1720`
- Run-owned API port: `50548` (0 listeners before launch)
- Prisma reset: exit 0, `--skip-generate --skip-seed`
- Explicit Prisma generate: exit 0
- Applied migrations: 28/28, failed or rolled back: 0
- API listener: `[::]:50548`, PID `44060`, command `node --import tsx src/index.ts`
- API parent: PID `44388`, exact Vitest command for `test/staff/sessions.test.ts`
- Health: HTTP 200 with `{"ok":true}`
- Result: 1/1 file passed; 11/11 tests passed; 0 failed, 0 skipped, 0 todo, 0 flaky, 0 retried
- Backend TypeScript build: exit 0
- Raw output: `sessions-test-r2.stdout.log`; stderr: `sessions-test-r2.stderr.log` (empty)
- Identity evidence: `api-identity-r2.json`

## Cleanup

- Both run-owned databases were validated with zero active connections, dropped, and proven absent.
- Fault-injection triggers and functions were 0 before database cleanup.
- Ports `53862` and `50548` had 0 listeners after teardown.
- API PID `44060`, Vitest PID `44388`, and launcher PID `29404` were absent after teardown.
- The exact detached worktree was clean, matched the immutable commit, was removed with `git worktree remove`, and is no longer registered or present.

