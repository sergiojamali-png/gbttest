[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$B2Root = 'D:\conductor-worktrees\saboos-staff-b2-retention-20260825'
$B1Root = 'D:\conductor-worktrees\saboos-staff-b1-refresh-20260825'
$Backend = Join-Path $B2Root 'backend'
$B1Backend = Join-Path $B1Root 'backend'
$B2NodeModules = Join-Path $Backend 'node_modules'
$B1NodeModules = Join-Path $B1Backend 'node_modules'
$Deliverables = 'C:\Users\SJ\Documents\ChatGPT\Saboos\deliverables'
$Node = 'C:\Program Files\nodejs\node.exe'
$Npm = 'C:\Program Files\nodejs\npm.cmd'
$Psql = 'C:\Program Files\PostgreSQL\16\bin\psql.exe'
$CreateDb = 'C:\Program Files\PostgreSQL\16\bin\createdb.exe'
$DropDb = 'C:\Program Files\PostgreSQL\16\bin\dropdb.exe'

$ExpectedHead = 'B39CF9E28B4E33C9EFC34B402E6AEAB6995D2344'
$ExpectedTree = '85AD666D23290403DD0E974AA00BEE94A2141640'
$ExpectedLockHash = '951B66EC1DF8448E813A14B946EE69F22D94DCD7A54AFB8E087CFBF29553BAA8'
$ExpectedPackageHash = '71F51064059C80E4085C254A757AB64A677D5C5C49BAEED40974FDC73B0F68F9'
$ExpectedSchemaHash = '4FB786A5C2C1997D28A0D434452DDBBAE1E76B1C6E8B77B5DDC8BA05A5C59CB8'
$ExpectedFiles = @(
    'backend/src/staff/services/retention.ts'
    'backend/test/staff/dataRetention.test.ts'
    'backend/test/staff/hardening.test.ts'
)
$ExpectedSourceFileHashes = [ordered]@{
    'backend/src/staff/services/retention.ts' = 'DFE2F773B3A4A3FA29664D09D494FDAC2A82FADC1BEC25686C794229E1EF2494'
    'backend/test/staff/dataRetention.test.ts' = 'D6B5332C8B81B6FC646B203E65A81113491D2603FFDA7D2866DAFE28C870CAF3'
    'backend/test/staff/hardening.test.ts' = 'F2FC12C13FF2A667864D5BD884D8EB9F8B62B76C0B065A000C906272E9890305'
}
$ExpectedCommitBlobHashes = [ordered]@{
    'backend/src/staff/services/retention.ts' = 'D282C2E98DC5E99EA687AFA0E73FB35A7E92EFCC9514DE19D50E7EC0562AE113'
    'backend/test/staff/dataRetention.test.ts' = 'D6B5332C8B81B6FC646B203E65A81113491D2603FFDA7D2866DAFE28C870CAF3'
    'backend/test/staff/hardening.test.ts' = '64F8B4B7AF86D02A0A718E063BD62DEC7BB81D9848B5FC3220161D326AD93129'
}
$ExpectedConcurrencyTitles = @(
    'waits on a concurrent fanout insert, then preserves its fresh delivery and parent'
    'waits for a concurrent policy disable and observes it before any notification deletion'
)
$ExpectedIdempotenceTitle = 'enforces delivery age before parent deletion with exact counts and two-run idempotence'

$Stamp = (Get-Date).ToUniversalTime().ToString('yyyyMMddHHmmss')
$Nonce = [Guid]::NewGuid().ToString('N').Substring(0, 8)
$RunId = "${Stamp}_${Nonce}"
$DatabaseName = "saboos_ci_b2_${RunId}".ToLowerInvariant()
$Evidence = Join-Path (Join-Path $Deliverables 'evidence') "b2-$RunId"
$RunTemp = Join-Path $Evidence '_run-temp'
$BuildDist = Join-Path $Backend 'dist'

if ($DatabaseName -notmatch '^saboos_ci_b2_[0-9]{14}_[0-9a-f]{8}$') {
    throw "Unsafe generated database name: $DatabaseName"
}

New-Item -ItemType Directory -Path $Evidence, $RunTemp -Force | Out-Null

$Failure = $null
$CleanupFailures = [Collections.Generic.List[string]]::new()
$DatabaseCreated = $false
$JunctionCreated = $false
$VitestProcess = $null
$ApiPort = $null
$BuildDistExistedBefore = Test-Path -LiteralPath $BuildDist
$OriginalEnvironment = [ordered]@{
    TEST_DATABASE_URL = $env:TEST_DATABASE_URL
    DATABASE_URL = $env:DATABASE_URL
    TEST_API_PORT = $env:TEST_API_PORT
    PGPASSWORD = $env:PGPASSWORD
    PGCONNECT_TIMEOUT = $env:PGCONNECT_TIMEOUT
    TEMP = $env:TEMP
    TMP = $env:TMP
}

function Write-Utf8 {
    param(
        [Parameter(Mandatory)] [string] $Path,
        [Parameter(Mandatory)] [AllowEmptyCollection()] [object[]] $Value
    )
    $Value | Set-Content -LiteralPath $Path -Encoding utf8NoBOM
}

function Invoke-CapturedNative {
    param(
        [Parameter(Mandatory)] [string] $FilePath,
        [Parameter(Mandatory)] [AllowEmptyCollection()] [string[]] $Arguments,
        [Parameter(Mandatory)] [string] $Label,
        [string] $WorkingDirectory = $Backend,
        [switch] $AllowFailure
    )

    $Stdout = Join-Path $Evidence "$Label.stdout.log"
    $Stderr = Join-Path $Evidence "$Label.stderr.log"
    Push-Location $WorkingDirectory
    try {
        & $FilePath @Arguments 1> $Stdout 2> $Stderr
        $ExitCode = $LASTEXITCODE
    } finally {
        Pop-Location
    }
    Write-Utf8 -Path (Join-Path $Evidence "$Label.exit-code.txt") -Value @($ExitCode)
    if ($ExitCode -ne 0 -and -not $AllowFailure) {
        throw "$Label exited with $ExitCode"
    }
    return $ExitCode
}

function Get-TrackedDiffNames {
    return @(git -C $B2Root diff --name-only | Sort-Object)
}

function Assert-ExpectedTrackedDiff {
    param([Parameter(Mandatory)] [string] $Stage)
    $Status = @(git -C $B2Root status --porcelain=v1 --untracked-files=all)
    if ($Status.Count -ne 0) {
        throw "$Stage expected a clean worktree: $($Status -join ' | ')"
    }
}

function Get-FileSha256 {
    param([Parameter(Mandatory)] [string] $Path)
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToUpperInvariant()
}

function Get-CommitBlobProof {
    param([Parameter(Mandatory)] [string] $RelativePath)
    $JavaScript = @'
const fs = require("fs");
const crypto = require("crypto");
const childProcess = require("child_process");
const root = process.argv[1];
const head = process.argv[2];
const relative = process.argv[3];
const working = fs.readFileSync(root + "/" + relative);
const result = childProcess.spawnSync("git", ["-C", root, "show", head + ":" + relative], {
  encoding: null,
  maxBuffer: 20 * 1024 * 1024,
});
if (result.status !== 0) {
  process.stderr.write(result.stderr || Buffer.from("git show failed"));
  process.exit(result.status || 1);
}
const canonicalBytes = [];
let crlfCount = 0;
for (let index = 0; index < working.length; index += 1) {
  if (working[index] === 13 && working[index + 1] === 10) {
    canonicalBytes.push(10);
    crlfCount += 1;
    index += 1;
  } else {
    canonicalBytes.push(working[index]);
  }
}
const canonical = Buffer.from(canonicalBytes);
const sha256 = (bytes) => crypto.createHash("sha256").update(bytes).digest("hex").toUpperCase();
process.stdout.write(JSON.stringify({
  workingSha256: sha256(working),
  blobSha256: sha256(result.stdout),
  canonicalSha256: sha256(canonical),
  canonicalEqualsBlob: canonical.equals(result.stdout),
  crlfCount,
}));
'@
    $Output = @(& $Node -e $JavaScript $B2Root $ExpectedHead $RelativePath)
    $ExitCode = $LASTEXITCODE
    if ($ExitCode -ne 0) {
        throw "Raw commit-blob proof failed for ${RelativePath}: exit $ExitCode"
    }
    return (($Output -join "`n") | ConvertFrom-Json)
}

function Get-ProcessAncestry {
    param(
        [Parameter(Mandatory)] [int] $LeafPid,
        [Parameter(Mandatory)] [int] $ExpectedAncestorPid
    )
    $Rows = [Collections.Generic.List[string]]::new()
    $CursorPid = $LeafPid
    $Matched = $false
    for ($Depth = 0; $Depth -lt 16 -and $CursorPid -gt 0; $Depth++) {
        $Info = Get-CimInstance Win32_Process -Filter "ProcessId=$CursorPid" -ErrorAction SilentlyContinue
        if (-not $Info) { break }
        $Rows.Add("pid=$($Info.ProcessId)|parent=$($Info.ParentProcessId)|exe=$($Info.ExecutablePath)|command=$($Info.CommandLine)")
        if ([int]$Info.ProcessId -eq $ExpectedAncestorPid) {
            $Matched = $true
            break
        }
        $CursorPid = [int]$Info.ParentProcessId
    }
    return [pscustomobject]@{ Matched = $Matched; Rows = $Rows }
}

Write-Utf8 -Path (Join-Path $Evidence '00-prior-harness-attempt.txt') -Value @(
    'prior_attempt_evidence=C:\Users\SJ\Documents\ChatGPT\Saboos\deliverables\evidence\b2-20260825213528_a4987a57'
    'prior_runner_sha256=3c6b2cbef9a0d8d3c064dac7cb1250adb94511d028e24763e63b1730d29e6c93'
    'prior_result=HARNESS_FAIL_BEFORE_DATABASE_OR_TEST_PROCESS'
    'prior_failure=PowerShell strict-mode access to an absent npm-ls problems property'
    'prior_cleanup=database_not_created;junction_not_created;product_source_unchanged'
    'previous_diagnostic_evidence=C:\Users\SJ\Documents\ChatGPT\Saboos\deliverables\evidence\b2-20260825213654_02fbfe6f'
    'previous_diagnostic_manifest_sha256=49d57fdb8b292777f5e2d94e6384b4e2bf21039efdf04dec099b3b28b1e4a33b'
    'previous_diagnostic_result=31_of_31_passed_but_source_review_rejected_revision'
    'previous_failed_evidence=C:\Users\SJ\Documents\ChatGPT\Saboos\deliverables\evidence\b2-20260825215136_df308de0'
    'previous_failed_manifest_sha256=4a9a0f4c1f00e4ca0938b07f1855ecc90b99d071a64eaab0a8f8f4453b14d0a9'
    'previous_failed_result=43_of_44_passed_void_deserialization_in_race_harness'
    'previous_passing_evidence=C:\Users\SJ\Documents\ChatGPT\Saboos\deliverables\evidence\b2-20260825220908_da69739d'
    'previous_passing_manifest_sha256=4fb89d2afedcc2b465fa96b45a1a95c37aea0122eaf3a1ca2eed2f8323dfe21a'
    'previous_passing_result=53_of_53_passed_fourth_correction'
)

try {
    foreach ($RequiredPath in @($B2Root, $B1Root, $Backend, $B1Backend, $Node, $Npm, $Psql, $CreateDb, $DropDb)) {
        if (-not (Test-Path -LiteralPath $RequiredPath)) {
            throw "Required path is missing: $RequiredPath"
        }
    }

    $Head = (git -C $B2Root rev-parse HEAD).Trim()
    $Tree = (git -C $B2Root rev-parse 'HEAD^{tree}').Trim()
    $Branch = (git -C $B2Root branch --show-current).Trim()
    if ($Head -ne $ExpectedHead -or $Tree -ne $ExpectedTree) {
        throw "Unexpected B2 identity: HEAD=$Head tree=$Tree"
    }
    Assert-ExpectedTrackedDiff -Stage 'preflight'
    $Staged = @(git -C $B2Root diff --cached --name-only)
    if ($Staged.Count -ne 0) {
        throw "Unexpected staged paths: $($Staged -join ', ')"
    }

    $SourceHashRows = [Collections.Generic.List[string]]::new()
    $CommitBlobProofRows = [Collections.Generic.List[string]]::new()
    foreach ($RelativePath in $ExpectedSourceFileHashes.Keys) {
        $AbsolutePath = Join-Path $B2Root ($RelativePath -replace '/', '\')
        $ActualHash = Get-FileSha256 $AbsolutePath
        if ($ActualHash -ne $ExpectedSourceFileHashes[$RelativePath]) {
            throw "Source bytes changed for ${RelativePath}: $ActualHash"
        }
        $SourceHashRows.Add("$ActualHash *$RelativePath")
        $BlobProof = Get-CommitBlobProof -RelativePath $RelativePath
        if ($BlobProof.workingSha256 -ne $ActualHash -or
            $BlobProof.blobSha256 -ne $ExpectedCommitBlobHashes[$RelativePath] -or
            $BlobProof.canonicalSha256 -ne $ExpectedCommitBlobHashes[$RelativePath] -or
            -not $BlobProof.canonicalEqualsBlob) {
            throw "Working/blob canonical identity failed for $RelativePath"
        }
        $CommitBlobProofRows.Add(
            "path=$RelativePath|working_sha256=$ActualHash|commit_blob_sha256=$($BlobProof.blobSha256)|" +
            "working_lf_canonical_sha256=$($BlobProof.canonicalSha256)|canonical_equals_blob=$($BlobProof.canonicalEqualsBlob)|" +
            "crlf_count=$($BlobProof.crlfCount)"
        )
    }
    Write-Utf8 -Path (Join-Path $Evidence '00-commit-blob-and-eol-proof.txt') -Value @(
        "head=$Head"
        "tree=$Tree"
        $CommitBlobProofRows
    )

    $B2LockHash = Get-FileSha256 (Join-Path $Backend 'package-lock.json')
    $B1LockHash = Get-FileSha256 (Join-Path $B1Backend 'package-lock.json')
    $B2PackageHash = Get-FileSha256 (Join-Path $Backend 'package.json')
    $B1PackageHash = Get-FileSha256 (Join-Path $B1Backend 'package.json')
    $B2SchemaHash = Get-FileSha256 (Join-Path $Backend 'prisma\schema.prisma')
    $B1SchemaHash = Get-FileSha256 (Join-Path $B1Backend 'prisma\schema.prisma')
    if ($B2LockHash -ne $ExpectedLockHash -or $B1LockHash -ne $ExpectedLockHash -or
        $B2PackageHash -ne $ExpectedPackageHash -or $B1PackageHash -ne $ExpectedPackageHash -or
        $B2SchemaHash -ne $ExpectedSchemaHash -or $B1SchemaHash -ne $ExpectedSchemaHash) {
        throw 'B1/B2 package or schema identity mismatch.'
    }

    $MigrationDirectories = @(Get-ChildItem -LiteralPath (Join-Path $Backend 'prisma\migrations') -Directory)
    if ($MigrationDirectories.Count -ne 28) {
        throw "Expected 28 migration directories, found $($MigrationDirectories.Count)"
    }

    $DataRetentionSource = Get-Content -Raw -LiteralPath (Join-Path $Backend 'test\staff\dataRetention.test.ts')
    $HardeningSource = Get-Content -Raw -LiteralPath (Join-Path $Backend 'test\staff\hardening.test.ts')
    if (($DataRetentionSource | Select-String -AllMatches '(?m)^\s*(it|test)(\.\w+)?\(').Matches.Count -ne 18 -or
        ($HardeningSource | Select-String -AllMatches '(?m)^\s*(it|test)(\.\w+)?\(').Matches.Count -ne 12) {
        throw 'Focused test declarations changed unexpectedly.'
    }
    foreach ($ExpectedConcurrencyTitle in $ExpectedConcurrencyTitles) {
        if ([regex]::Matches($DataRetentionSource, [regex]::Escape($ExpectedConcurrencyTitle)).Count -ne 1) {
            throw "A reviewed concurrency test is absent or duplicated: $ExpectedConcurrencyTitle"
        }
    }
    if ([regex]::Matches($DataRetentionSource, [regex]::Escape($ExpectedIdempotenceTitle)).Count -ne 1) {
        throw 'The reviewed expanded idempotence test is absent or duplicated.'
    }

    Write-Utf8 -Path (Join-Path $Evidence '00-source-and-run-identity.txt') -Value @(
        "run_id=$RunId"
        "snapshot_utc=$((Get-Date).ToUniversalTime().ToString('o'))"
        "runner=$PSCommandPath"
        "runner_sha256=$(Get-FileSha256 $PSCommandPath)"
        "branch=$Branch"
        "head=$Head"
        "tree=$Tree"
        "task_files=$($ExpectedFiles -join ',')"
        "package_lock_sha256=$B2LockHash"
        "package_json_sha256=$B2PackageHash"
        "schema_sha256=$B2SchemaHash"
        "migration_directory_count=$($MigrationDirectories.Count)"
        'dataRetention_declarations=18'
        'dataRetention_single_tests_expected=14'
        'dataRetention_malformed_cases_expected=8'
        'dataRetention_provenance_cases_expected=7'
        'dataRetention_invalid_message_cases_expected=9'
        'dataRetention_authorization_lock_cases_expected=3'
        'dataRetention_expanded_tests_expected=41'
        'hardening_tests_expected=12'
        'selected_tests_expected=53'
        ($ExpectedConcurrencyTitles | ForEach-Object { "concurrency_test_expected=$_" })
        "idempotence_test_expected=$ExpectedIdempotenceTitle"
        $SourceHashRows
    )

    if (Test-Path -LiteralPath $B2NodeModules) {
        throw "B2 node_modules already exists: $B2NodeModules"
    }
    $B1ModulesItem = Get-Item -LiteralPath $B1NodeModules -Force
    if (-not $B1ModulesItem.PSIsContainer -or
        ($B1ModulesItem.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw 'B1 node_modules is not an ordinary directory.'
    }
    $ActiveB1B2 = @(Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object {
        $_.CommandLine -like '*saboos-staff-b1-refresh-20260825*' -or
        $_.CommandLine -like '*saboos-staff-b2-retention-20260825*'
    })
    if ($ActiveB1B2.Count -ne 0) {
        throw 'B1/B2 Node activity exists; dependency reuse is not serialized.'
    }

    Invoke-CapturedNative -FilePath $Npm -Arguments @('ls', '--all', '--json') -Label '01-npm-ls-b1' -WorkingDirectory $B1Backend | Out-Null
    $NpmTree = Get-Content -Raw -LiteralPath (Join-Path $Evidence '01-npm-ls-b1.stdout.log') | ConvertFrom-Json -Depth 100
    $NpmProblems = @()
    if ($NpmTree.PSObject.Properties.Name -contains 'problems') {
        $NpmProblems = @($NpmTree.problems)
    }
    if ($NpmProblems.Count -ne 0) {
        throw "B1 npm dependency problems: $($NpmProblems -join '; ')"
    }

    $GeneratedClientBefore = Join-Path $B1NodeModules '.prisma\client\schema.prisma'
    $GeneratedBeforeHash = Get-FileSha256 $GeneratedClientBefore
    New-Item -ItemType Junction -Path $B2NodeModules -Target $B1NodeModules | Out-Null
    $JunctionCreated = $true
    $Junction = Get-Item -LiteralPath $B2NodeModules -Force
    $JunctionTarget = [IO.Path]::GetFullPath([string]$Junction.Target)
    if ($Junction.LinkType -ne 'Junction' -or
        -not [string]::Equals($JunctionTarget, [IO.Path]::GetFullPath($B1NodeModules), [StringComparison]::OrdinalIgnoreCase)) {
        throw 'The dependency junction does not resolve to the exact B1 node_modules target.'
    }
    Write-Utf8 -Path (Join-Path $Evidence '02-dependency-junction-proof.txt') -Value @(
        "b1_node_modules=$B1NodeModules"
        "b2_junction=$B2NodeModules"
        "link_type=$($Junction.LinkType)"
        "resolved_target=$JunctionTarget"
        "lock_sha256=$B2LockHash"
        'npm_ls_exit=0'
        'npm_ls_problems=0'
        "generated_schema_before_sha256=$GeneratedBeforeHash"
    )

    $PostgresListeners = @(Get-NetTCPConnection -State Listen -LocalPort 54329)
    if ($PostgresListeners.Count -ne 1 -or $PostgresListeners[0].LocalAddress -ne '127.0.0.1') {
        throw 'Expected exactly one PostgreSQL listener on 127.0.0.1:54329.'
    }
    $PostgresPid = [int]$PostgresListeners[0].OwningProcess
    $PostgresProcess = Get-Process -Id $PostgresPid
    $ExpectedPostgresPath = $Psql -replace 'psql\.exe$', 'postgres.exe'
    if (-not [string]::Equals($PostgresProcess.Path, $ExpectedPostgresPath, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Unexpected port 54329 owner: $($PostgresProcess.Path)"
    }
    Invoke-CapturedNative -FilePath $Psql -Arguments @(
        '--no-password', '--host=127.0.0.1', '--port=54329', '--username=saboos_test', '--dbname=postgres',
        '--no-psqlrc', '--tuples-only', '--no-align', '--set=ON_ERROR_STOP=1', '--command=SELECT 1;'
    ) -Label '03-passwordless-loopback-probe' | Out-Null
    if ((Get-Content -Raw (Join-Path $Evidence '03-passwordless-loopback-probe.stdout.log')).Trim() -ne '1') {
        throw 'The passwordless loopback-only PostgreSQL probe did not return 1.'
    }
    Write-Utf8 -Path (Join-Path $Evidence '03-postgres-listener-proof.txt') -Value @(
        "snapshot_utc=$((Get-Date).ToUniversalTime().ToString('o'))"
        'address=127.0.0.1'
        'port=54329'
        "pid=$PostgresPid"
        "path=$($PostgresProcess.Path)"
        "binary_sha256=$(Get-FileSha256 $PostgresProcess.Path)"
        'password_source=none-loopback-test-listener-accepts-no-password'
    )

    $PortReservation = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, 0)
    try {
        $PortReservation.Start()
        $ApiPort = ([Net.IPEndPoint]$PortReservation.LocalEndpoint).Port
    } finally {
        $PortReservation.Stop()
    }
    if ($ApiPort -eq 4917 -or (Get-NetTCPConnection -State Listen -LocalPort $ApiPort -ErrorAction SilentlyContinue)) {
        throw "Invalid dynamically allocated API port: $ApiPort"
    }

    $TestDatabaseUser = 'saboos_test'
    # The disposable test contract uses the same value for user and password.
    # Construct it only in process memory; never write the credential-bearing URL.
    $DatabaseUrl = 'postgresql://' + [Uri]::EscapeDataString($TestDatabaseUser) + [char]58 +
        [Uri]::EscapeDataString($TestDatabaseUser) + [char]64 + '127.0.0.1:54329/' +
        [Uri]::EscapeDataString($DatabaseName) + '?schema=public'
    $DatabaseUrlHash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($DatabaseUrl)))
    $env:PGPASSWORD = $null
    $env:PGCONNECT_TIMEOUT = '5'
    $env:TEST_DATABASE_URL = $DatabaseUrl
    $env:DATABASE_URL = $DatabaseUrl
    $env:TEST_API_PORT = [string]$ApiPort
    $env:TEMP = $RunTemp
    $env:TMP = $RunTemp
    Write-Utf8 -Path (Join-Path $Evidence '04-environment-binding.txt') -Value @(
        "database_name=$DatabaseName"
        'database_host=127.0.0.1'
        'database_port=54329'
        'database_schema=public'
        "database_user=$TestDatabaseUser"
        "database_url_password_component_present=$($DatabaseUrl -match '^postgresql://[^:/]+:[^@]+@')"
        "database_url_sha256=$DatabaseUrlHash"
        "test_database_url_equals_database_url=$($env:TEST_DATABASE_URL -ceq $env:DATABASE_URL)"
        "api_port=$ApiPort"
        "api_port_is_not_4917=$($ApiPort -ne 4917)"
        "temp_root=$RunTemp"
    )

    Invoke-CapturedNative -FilePath $CreateDb -Arguments @(
        '--no-password', '--host=127.0.0.1', '--port=54329', '--username=saboos_test', '--owner=saboos_test', $DatabaseName
    ) -Label '05-createdb' | Out-Null
    $DatabaseCreated = $true

    Invoke-CapturedNative -FilePath $Psql -Arguments @(
        '--no-password', '--host=127.0.0.1', '--port=54329', '--username=saboos_test', "--dbname=$DatabaseName",
        '--no-psqlrc', '--tuples-only', '--no-align', '--field-separator=|', '--set=ON_ERROR_STOP=1',
        '--command=SELECT current_database(), inet_server_addr(), inet_server_port(), pg_backend_pid();'
    ) -Label '06-database-identity-before' | Out-Null
    $DatabaseIdentityBefore = (Get-Content -Raw (Join-Path $Evidence '06-database-identity-before.stdout.log')).Trim()
    if (-not $DatabaseIdentityBefore.StartsWith("$DatabaseName|127.0.0.1|54329|")) {
        throw "Unexpected database identity: $DatabaseIdentityBefore"
    }

    $PrismaCli = Join-Path $B2NodeModules 'prisma\build\index.js'
    Invoke-CapturedNative -FilePath $Node -Arguments @(
        $PrismaCli, 'migrate', 'reset', '--force', '--skip-generate', '--skip-seed', '--schema', (Join-Path $Backend 'prisma\schema.prisma')
    ) -Label '07-prisma-migrate-reset' | Out-Null
    Invoke-CapturedNative -FilePath $Node -Arguments @(
        $PrismaCli, 'generate', '--schema', (Join-Path $Backend 'prisma\schema.prisma')
    ) -Label '08-prisma-generate' | Out-Null

    Invoke-CapturedNative -FilePath $Psql -Arguments @(
        '--no-password', '--host=127.0.0.1', '--port=54329', '--username=saboos_test', "--dbname=$DatabaseName",
        '--no-psqlrc', '--tuples-only', '--no-align', '--field-separator=|', '--set=ON_ERROR_STOP=1',
        '--command=SELECT count(*) FILTER (WHERE finished_at IS NOT NULL AND rolled_back_at IS NULL), count(*) FILTER (WHERE finished_at IS NULL), count(*) FILTER (WHERE rolled_back_at IS NOT NULL) FROM _prisma_migrations;'
    ) -Label '09-migration-count-before-tests' | Out-Null
    $MigrationCountBefore = (Get-Content -Raw (Join-Path $Evidence '09-migration-count-before-tests.stdout.log')).Trim()
    if ($MigrationCountBefore -ne '28|0|0') {
        throw "Unexpected pre-test migration result: $MigrationCountBefore"
    }

    $VitestCli = Join-Path $B2NodeModules 'vitest\vitest.mjs'
    $VitestJson = Join-Path $Evidence '10-vitest-results.json'
    $VitestStdout = Join-Path $Evidence '10-vitest-verbose.stdout.log'
    $VitestStderr = Join-Path $Evidence '10-vitest-verbose.stderr.log'
    $VitestArguments = @(
        $VitestCli, 'run', 'test/staff/dataRetention.test.ts', 'test/staff/hardening.test.ts',
        '--reporter=verbose', '--reporter=json', "--outputFile.json=$VitestJson", '--no-file-parallelism', '--retry=0'
    )
    $VitestProcess = Start-Process -FilePath $Node -WorkingDirectory $Backend -ArgumentList $VitestArguments `
        -RedirectStandardOutput $VitestStdout -RedirectStandardError $VitestStderr -WindowStyle Hidden -PassThru
    Write-Utf8 -Path (Join-Path $Evidence '10-vitest-launch.txt') -Value @(
        "vitest_pid=$($VitestProcess.Id)"
        'selected_file_1=test/staff/dataRetention.test.ts'
        'selected_file_2=test/staff/hardening.test.ts'
        'reporters=verbose,json'
        'retry=0'
        'file_parallelism=false'
    )

    $ApiOwnerPid = $null
    $ListenerDeadline = [DateTime]::UtcNow.AddMinutes(5)
    while ([DateTime]::UtcNow -lt $ListenerDeadline -and -not $VitestProcess.HasExited) {
        $Owners = @(Get-NetTCPConnection -State Listen -LocalPort $ApiPort -ErrorAction SilentlyContinue |
            Select-Object -ExpandProperty OwningProcess -Unique)
        if ($Owners.Count -eq 1) {
            $ApiOwnerPid = [int]$Owners[0]
            break
        }
        Start-Sleep -Milliseconds 100
    }
    if (-not $ApiOwnerPid) {
        throw "The run-owned API did not bind port $ApiPort before Vitest exited."
    }
    $Ancestry = Get-ProcessAncestry -LeafPid $ApiOwnerPid -ExpectedAncestorPid $VitestProcess.Id
    if (-not $Ancestry.Matched) {
        throw 'The API listener is not a descendant of the run-owned Vitest process.'
    }
    $ApiProcess = Get-Process -Id $ApiOwnerPid
    $Health = Invoke-WebRequest -Uri "http://127.0.0.1:$ApiPort/api/health" -NoProxy -TimeoutSec 10
    $StaffHealth = Invoke-WebRequest -Uri "http://127.0.0.1:$ApiPort/api/staff/health" -NoProxy -TimeoutSec 10
    Write-Utf8 -Path (Join-Path $Evidence '11-api-process-and-health-proof.txt') -Value @(
        "api_port=$ApiPort"
        "api_owner_pid=$ApiOwnerPid"
        "api_process_path=$($ApiProcess.Path)"
        "vitest_pid=$($VitestProcess.Id)"
        "descends_from_vitest=$($Ancestry.Matched)"
        "api_health_status=$($Health.StatusCode)"
        "api_health_body=$($Health.Content)"
        "staff_health_status=$($StaffHealth.StatusCode)"
        "staff_health_body=$($StaffHealth.Content)"
        $Ancestry.Rows
    )
    if ($Health.StatusCode -ne 200 -or $Health.Content -notmatch '"ok"\s*:\s*true' -or
        $StaffHealth.StatusCode -ne 200 -or $StaffHealth.Content -notmatch '"db"\s*:\s*true') {
        throw 'The run-owned API did not prove both process and database health.'
    }

    $VitestProcess.WaitForExit()
    $VitestProcess.Refresh()
    $VitestExit = $VitestProcess.ExitCode
    Write-Utf8 -Path (Join-Path $Evidence '10-vitest.exit-code.txt') -Value @($VitestExit)
    if (-not (Test-Path -LiteralPath $VitestJson)) {
        throw 'Vitest did not produce its JSON result file.'
    }
    $Results = Get-Content -Raw -LiteralPath $VitestJson | ConvertFrom-Json -Depth 100
    $TestFileCount = @($Results.testResults).Count
    $Total = [int]$Results.numTotalTests
    $Passed = [int]$Results.numPassedTests
    $Failed = [int]$Results.numFailedTests
    $Skipped = [int]$Results.numPendingTests
    $Todo = if ($Results.PSObject.Properties.Name -contains 'numTodoTests') { [int]$Results.numTodoTests } else { 0 }
    $Assertions = @($Results.testResults | ForEach-Object { $_.assertionResults })
    $ConcurrencyRows = [Collections.Generic.List[string]]::new()
    $ConcurrencyFailures = [Collections.Generic.List[string]]::new()
    foreach ($ExpectedConcurrencyTitle in $ExpectedConcurrencyTitles) {
        $ConcurrencyResults = @($Assertions | Where-Object { $_.title -ceq $ExpectedConcurrencyTitle })
        $ConcurrencyStatus = if ($ConcurrencyResults.Count -eq 1) {
            [string]$ConcurrencyResults[0].status
        } else {
            'not-unique-or-missing'
        }
        $ConcurrencyRows.Add("test=$ExpectedConcurrencyTitle|matches=$($ConcurrencyResults.Count)|status=$ConcurrencyStatus")
        if ($ConcurrencyResults.Count -ne 1 -or $ConcurrencyStatus -ne 'passed') {
            $ConcurrencyFailures.Add("$ExpectedConcurrencyTitle|matches=$($ConcurrencyResults.Count)|status=$ConcurrencyStatus")
        }
    }
    $IdempotenceResults = @($Assertions | Where-Object { $_.title -ceq $ExpectedIdempotenceTitle })
    $IdempotenceStatus = if ($IdempotenceResults.Count -eq 1) {
        [string]$IdempotenceResults[0].status
    } else {
        'not-unique-or-missing'
    }
    Write-Utf8 -Path (Join-Path $Evidence '12-exact-test-counts.txt') -Value @(
        "test_files=$TestFileCount"
        "tests_total=$Total"
        "passed=$Passed"
        "failed=$Failed"
        "skipped=$Skipped"
        "todo=$Todo"
        'flaky=0'
        'retried=0'
        'retry_configuration=0'
        "process_exit=$VitestExit"
    )
    Write-Utf8 -Path (Join-Path $Evidence '12a-concurrency-test-results.txt') -Value $ConcurrencyRows
    Write-Utf8 -Path (Join-Path $Evidence '12b-idempotence-test-result.txt') -Value @(
        "test=$ExpectedIdempotenceTitle"
        "matches=$($IdempotenceResults.Count)"
        "status=$IdempotenceStatus"
    )
    if ($VitestExit -ne 0 -or $TestFileCount -ne 2 -or $Total -ne 53 -or $Passed -ne 53 -or
        $Failed -ne 0 -or $Skipped -ne 0 -or $Todo -ne 0) {
        throw "Focused oracle failed: files=$TestFileCount total=$Total passed=$Passed failed=$Failed skipped=$Skipped todo=$Todo exit=$VitestExit"
    }
    if ($ConcurrencyFailures.Count -ne 0) {
        throw "Concurrency oracles failed: $($ConcurrencyFailures -join '; ')"
    }
    if ($IdempotenceResults.Count -ne 1 -or $IdempotenceStatus -ne 'passed') {
        throw "Expanded idempotence oracle failed: matches=$($IdempotenceResults.Count) status=$IdempotenceStatus"
    }

    Invoke-CapturedNative -FilePath $Psql -Arguments @(
        '--no-password', '--host=127.0.0.1', '--port=54329', '--username=saboos_test', "--dbname=$DatabaseName",
        '--no-psqlrc', '--tuples-only', '--no-align', '--field-separator=|', '--set=ON_ERROR_STOP=1',
        '--command=SELECT current_database(), inet_server_addr(), inet_server_port(), count(*) FILTER (WHERE finished_at IS NOT NULL AND rolled_back_at IS NULL), count(*) FILTER (WHERE finished_at IS NULL), count(*) FILTER (WHERE rolled_back_at IS NOT NULL) FROM _prisma_migrations GROUP BY current_database(), inet_server_addr(), inet_server_port();'
    ) -Label '13-database-and-migrations-after-tests' | Out-Null
    $PostTestDb = (Get-Content -Raw (Join-Path $Evidence '13-database-and-migrations-after-tests.stdout.log')).Trim()
    if ($PostTestDb -ne "$DatabaseName|127.0.0.1|54329|28|0|0") {
        throw "Unexpected post-test DB/migration proof: $PostTestDb"
    }

    Invoke-CapturedNative -FilePath $Npm -Arguments @('--prefix', $Backend, 'run', 'build') -Label '14-backend-build' -WorkingDirectory $B2Root | Out-Null
    Assert-ExpectedTrackedDiff -Stage 'post-build'
    $FinalSourceHashRows = [Collections.Generic.List[string]]::new()
    foreach ($RelativePath in $ExpectedSourceFileHashes.Keys) {
        $AbsolutePath = Join-Path $B2Root ($RelativePath -replace '/', '\')
        $ActualHash = Get-FileSha256 $AbsolutePath
        if ($ActualHash -ne $ExpectedSourceFileHashes[$RelativePath]) {
            throw "Post-build source bytes changed for ${RelativePath}: $ActualHash"
        }
        $FinalSourceHashRows.Add("$ActualHash *$RelativePath")
    }
    $GeneratedAfterHash = Get-FileSha256 $GeneratedClientBefore
    Write-Utf8 -Path (Join-Path $Evidence '15-generated-client-and-source-final.txt') -Value @(
        "generated_schema_before_sha256=$GeneratedBeforeHash"
        "generated_schema_after_sha256=$GeneratedAfterHash"
        "tracked_files=$((Get-TrackedDiffNames) -join ',')"
        "git_status=$((git -C $B2Root status --short) -join ' | ')"
        $FinalSourceHashRows
    )
} catch {
    $Failure = $_
    Write-Utf8 -Path (Join-Path $Evidence 'FAILURE.txt') -Value @(
        "timestamp_utc=$((Get-Date).ToUniversalTime().ToString('o'))"
        "type=$($_.Exception.GetType().FullName)"
        "message=$($_.Exception.Message)"
        "position=$($_.InvocationInfo.PositionMessage)"
    )
} finally {
    if ($VitestProcess -and -not $VitestProcess.HasExited) {
        try {
            $VitestProcess.Kill($true)
            $VitestProcess.WaitForExit()
        } catch {
            $CleanupFailures.Add("vitest_tree_cleanup=$($_.Exception.Message)")
        }
    }

    if ($DatabaseCreated) {
        try {
            if ($DatabaseName -notmatch '^saboos_ci_b2_[0-9]{14}_[0-9a-f]{8}$') {
                throw "Refusing to drop unexpected DB name: $DatabaseName"
            }
            Invoke-CapturedNative -FilePath $DropDb -Arguments @(
                '--no-password', '--host=127.0.0.1', '--port=54329', '--username=saboos_test', '--if-exists', '--force', $DatabaseName
            ) -Label '16-dropdb' | Out-Null
        } catch {
            $CleanupFailures.Add("database_cleanup=$($_.Exception.Message)")
        }
    }

    if ($JunctionCreated -and (Test-Path -LiteralPath $B2NodeModules)) {
        try {
            $Link = Get-Item -LiteralPath $B2NodeModules -Force
            $ActualTarget = [IO.Path]::GetFullPath([string]$Link.Target)
            $ExpectedTarget = [IO.Path]::GetFullPath($B1NodeModules)
            if ($Link.LinkType -ne 'Junction' -or
                -not [string]::Equals($ActualTarget, $ExpectedTarget, [StringComparison]::OrdinalIgnoreCase)) {
                throw 'Refusing to delete an unverified node_modules target.'
            }
            [IO.Directory]::Delete($B2NodeModules, $false)
        } catch {
            $CleanupFailures.Add("junction_cleanup=$($_.Exception.Message)")
        }
    }

    if (-not $BuildDistExistedBefore -and (Test-Path -LiteralPath $BuildDist)) {
        try {
            $DistItem = Get-Item -LiteralPath $BuildDist -Force
            $DistPath = [IO.Path]::GetFullPath($DistItem.FullName)
            $BackendPrefix = [IO.Path]::GetFullPath($Backend) + [IO.Path]::DirectorySeparatorChar
            if (-not $DistPath.StartsWith($BackendPrefix, [StringComparison]::OrdinalIgnoreCase) -or
                ($DistItem.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
                throw "Refusing unsafe dist cleanup: $DistPath"
            }
            Remove-Item -LiteralPath $DistPath -Recurse -Force
        } catch {
            $CleanupFailures.Add("dist_cleanup=$($_.Exception.Message)")
        }
    }

    if (Test-Path -LiteralPath $RunTemp) {
        try {
            $TempItem = Get-Item -LiteralPath $RunTemp -Force
            $TempPath = [IO.Path]::GetFullPath($TempItem.FullName)
            $EvidencePrefix = [IO.Path]::GetFullPath($Evidence) + [IO.Path]::DirectorySeparatorChar
            if (-not $TempPath.StartsWith($EvidencePrefix, [StringComparison]::OrdinalIgnoreCase) -or
                ($TempItem.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
                throw "Refusing unsafe temp cleanup: $TempPath"
            }
            Remove-Item -LiteralPath $TempPath -Recurse -Force
        } catch {
            $CleanupFailures.Add("temp_cleanup=$($_.Exception.Message)")
        }
    }

    foreach ($Name in $OriginalEnvironment.Keys) {
        [Environment]::SetEnvironmentVariable($Name, $OriginalEnvironment[$Name], [EnvironmentVariableTarget]::Process)
    }
    Remove-Variable DatabaseUrl -ErrorAction SilentlyContinue
}

# Prove cleanup without using any credential-bearing URL.
$DatabaseResidue = 'unproven'
$CleanupProbeOriginalPgConnectTimeout = $env:PGCONNECT_TIMEOUT
try {
    $env:PGCONNECT_TIMEOUT = '5'
    $ResidueSql = "SELECT count(*) FROM pg_database WHERE datname='$DatabaseName';"
    Invoke-CapturedNative -FilePath $Psql -Arguments @(
        '--no-password', '--host=127.0.0.1', '--port=54329', '--username=saboos_test', '--dbname=postgres',
        '--no-psqlrc', '--tuples-only', '--no-align', '--set=ON_ERROR_STOP=1', "--command=$ResidueSql"
    ) -Label '17-database-residue' | Out-Null
    $DatabaseResidue = (Get-Content -Raw (Join-Path $Evidence '17-database-residue.stdout.log')).Trim()
} catch {
    $CleanupFailures.Add("database_residue_check=$($_.Exception.Message)")
} finally {
    [Environment]::SetEnvironmentVariable(
        'PGCONNECT_TIMEOUT',
        $CleanupProbeOriginalPgConnectTimeout,
        [EnvironmentVariableTarget]::Process
    )
}
$JunctionResidue = Test-Path -LiteralPath $B2NodeModules
$ApiResidue = @()
if ($null -ne $ApiPort) {
    $ApiResidue = @(Get-NetTCPConnection -State Listen -LocalPort $ApiPort -ErrorAction SilentlyContinue)
}
$NodeResidue = @(Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object {
    $_.CommandLine -like '*saboos-staff-b2-retention-20260825*'
})

try {
    Assert-ExpectedTrackedDiff -Stage 'post-cleanup'
} catch {
    $CleanupFailures.Add("source_cleanup_proof=$($_.Exception.Message)")
}

Write-Utf8 -Path (Join-Path $Evidence '18-cleanup-proof.txt') -Value @(
    "database_name=$DatabaseName"
    "database_residue_count=$DatabaseResidue"
    "junction_residue=$JunctionResidue"
    "api_listener_residue_count=$($ApiResidue.Count)"
    "b2_node_process_residue_count=$($NodeResidue.Count)"
    "dist_residue=$(Test-Path -LiteralPath $BuildDist)"
    "run_temp_residue=$(Test-Path -LiteralPath $RunTemp)"
    "tracked_files=$((Get-TrackedDiffNames) -join ',')"
    "cleanup_failure_count=$($CleanupFailures.Count)"
    $CleanupFailures
)

if ($DatabaseResidue -ne '0' -or $JunctionResidue -or $ApiResidue.Count -ne 0 -or
    $NodeResidue.Count -ne 0 -or $CleanupFailures.Count -ne 0) {
    if (-not $Failure) {
        $Failure = [Exception]::new('Cleanup proof failed; inspect 18-cleanup-proof.txt.')
    }
}

# Redact any accidentally emitted credential-bearing URL before hashing evidence.
$CredentialPattern = '(?i)postgres(?:ql)?://[^\s:/]+:[^\s@]+@'
$EnvironmentUrlPattern = '(?im)^(TEST_DATABASE_URL|DATABASE_URL)=.*$'
foreach ($File in Get-ChildItem -LiteralPath $Evidence -Recurse -File) {
    if ($File.Extension -notin @('.txt', '.log', '.json')) { continue }
    $Raw = Get-Content -Raw -LiteralPath $File.FullName -ErrorAction SilentlyContinue
    if ($null -eq $Raw) { continue }
    $Redacted = [regex]::Replace($Raw, $CredentialPattern, 'postgresql://[REDACTED]@')
    $Redacted = [regex]::Replace($Redacted, $EnvironmentUrlPattern, '$1=[REDACTED]')
    if ($Redacted -cne $Raw) {
        Set-Content -LiteralPath $File.FullName -Value $Redacted -NoNewline -Encoding utf8NoBOM
    }
}

$SecretMatches = [Collections.Generic.List[string]]::new()
foreach ($File in Get-ChildItem -LiteralPath $Evidence -Recurse -File) {
    if ($File.Extension -notin @('.txt', '.log', '.json')) { continue }
    $Text = Get-Content -Raw -LiteralPath $File.FullName -ErrorAction SilentlyContinue
    if ($Text -match $CredentialPattern -or $Text -match $EnvironmentUrlPattern) {
        $SecretMatches.Add([IO.Path]::GetRelativePath($Evidence, $File.FullName))
    }
}
Write-Utf8 -Path (Join-Path $Evidence '19-evidence-secret-scan.txt') -Value @(
    "credential_or_database_url_match_count=$($SecretMatches.Count)"
    $SecretMatches
)
if ($SecretMatches.Count -ne 0 -and -not $Failure) {
    $Failure = [Exception]::new('Evidence secret scan failed.')
}

$Manifest = Join-Path $Evidence 'SHA256SUMS.txt'
$ManifestRows = [Collections.Generic.List[string]]::new()
foreach ($File in Get-ChildItem -LiteralPath $Evidence -Recurse -File | Where-Object { $_.FullName -ne $Manifest } | Sort-Object FullName) {
    $Relative = [IO.Path]::GetRelativePath($Evidence, $File.FullName).Replace('\', '/')
    $Hash = (Get-FileHash -LiteralPath $File.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    $ManifestRows.Add("$Hash *$Relative")
}
Write-Utf8 -Path $Manifest -Value $ManifestRows
$ManifestHash = (Get-FileHash -LiteralPath $Manifest -Algorithm SHA256).Hash.ToLowerInvariant()

$Status = if ($Failure) { 'FAIL' } else { 'PASS' }
Write-Output "status=$Status"
Write-Output "evidence=$Evidence"
Write-Output "manifest=$Manifest"
Write-Output "manifest_sha256=$ManifestHash"

if ($Failure) {
    $FailureMessage = if ($Failure -is [Management.Automation.ErrorRecord]) {
        $Failure.Exception.Message
    } else {
        $Failure.Message
    }
    Write-Error $FailureMessage
    exit 1
}
exit 0
